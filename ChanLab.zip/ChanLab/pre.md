# ChanLab Presentation

A Quantitative Structure Model of Market Geometry Based on Chan Theory

Student: Yuchang Zhang (25678259)
Supervisor: Dr. Yining Hu

# 1 Research Aim & Paradigm

Aim: To examine whether market price geometry can be quantified, reconstructed, and used to generate stable trading signals.

Paradigm: Empirical Research

Methodology: Hybrid Quantitative Method — Structural Modeling + Empirical Comparison

| Stage                       | Description                                                                                 | Verification Logic                                                     |
| --------------------------- | ------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------- |
| **1 Structure Modeling**    | Multi-layer geometric decomposition (K-line → Fractal → Pen → Segment → Zhongshu → Beichi). | Compare counts & grades (A/B/C) across timeframes to test consistency. |
| **2 Signal Fusion**         | Generate Trend + Beichi signals → merge composite signals.                                  | Evaluate whether fusion improves win rate / drawdown.                  |
| **3 Empirical Validation**  | Run backtests for structure-based, traditional, and ML strategies.                          | Compare metrics (Win Rate, Sharpe, Max DD).                            |
| **4 Reproducibility Audit** | Hash and Jaccard consistency checks.                                                        | Verify determinism and replicability.                                  |

Research Questions:

| ID      | Question                                                     | Verification                                                 |
| ------- | ------------------------------------------------------------ | ------------------------------------------------------------ |
| **RQ1** | Can the system produce deterministic and reproducible outputs under identical inputs? | Run MD5 + Jaccard tests for reproducibility.                 |
| **RQ2** | Can each trading signal be structurally explained by its corresponding segment and Zhongshu? | Generate explainable signals and visualize structural mapping. |
| **RQ3** | Do structure-based signals show more stable trading performance than traditional or ML strategies? | Run unified backtests and compare metrics (Win%, Sharpe, MaxDD). |

# 2 Background

Chan Theory views market movement as non-random geometric structures built from self-similar layers.

Each structure (Fractal → Pen → Segment → Zhongshu) captures price geometry and market rhythm.



# 3 System Architecture

    ChanLab/
    ├─ pipeline.py                      # One-click 00–11 pipeline
    ├─ Note/                            
    │   ├─ 00_chan K Generation.ipynb
    │   ├─ 01_fractal.ipynb
    │   ├─ 02_bi.ipynb
    │   ├─ 03_segment.ipynb
    │   ├─ 04_zhongshu.ipynb
    │   ├─ 05_zhongshu hireachy.ipynb
    │   ├─ 06_trend.ipynb
    │   ├─ 07_trend signals.ipynb
    │   ├─ 08_Mapping.ipynb
    │   ├─ 09_Trend signal...ipynb
    │   ├─ 10_mmd.ipynb
    │   └─ 11_Signal browsing.ipynb
    ├─ chan/                         
    │   ├─ chan_kline.py
    │   ├─ chan_fractal.py
    │   ├─ chan_bi.py
    │   ├─ chan_segment.py
    │   ├─ chan_zhongshu.py
    │   ├─ zhongshu_hierarchy.py
    │   ├─ chan_trend.py
    │   ├─ signals/
    │      ├─ trend_signal.py
    │      ├─ beichi.py
    │      ├─ mmd.py
    │      └─ merge.py
    ├─ configs/                         
    │   ├─ zhongshu_fast_default.json
    │   ├─ zhongshu_slow_default.json
    ├─ DATA/                            
    │   ├─ BTCUSDT/5m.csv, 15m.csv, ...
    │   └─ ETHUSDT/5m.csv, 15m.csv, ...
    ├─ chan_data/                       
    │   ├─ segments/{fast,slow}/<SYM>/<tf>_segments.csv
    │   ├─ zhongshu_{fast,slow}/<SYM>/<tf>_zhongshu.csv
    │   ├─ zhongshu_hierarchy_fast/<SYM>/<tf>_L{1,2,3}.csv
    │   ├─ trend_practical/<SYM>/<tf>_trend.csv
    │   ├─ trend_signals/<SYM>/<tf>_trend_signal.csv
    │   ├─ mapped/segments_fast/<SYM>/<tf>_segments_mapped.csv
    │   └─ signals/
    │       ├─ beichi/<SYM>/{tf}_beichi_{trend,range,all}.csv
    │       ├─ merged/<SYM>/{tf}_merged_signals.csv
    │       ├─ mmd/<SYM>/{tf}_mmd123.csv
    │       ├─ trading/<SYM>/multi_tf_trading_signals.csv
    │       ├─ backtest/<SYM>/trades.csv
    │       └─ alerts/<SYM>/alerts.csv
    ├─ reports/
    │   ├─ trend_practical_best.csv     
    │   ├─ zhongshu_grid_summary.csv    
    │   └─ ...
    └─ scripts/                         
        ├─ baselines_traditional.py
        ├─ baselines_ml.py


Pipeline :

Raw Data → K-Line Normalization → Fractals → Pens → Segments → Zhongshu → Hierarchy → Signals → Backtest → Alerts

| Layer                     | Purpose                                                                  |
| ------------------------- | ------------------------------------------------------------------------ |
| 00–03 Data Preparation    | Normalize K-lines, detect fractal tops/bottoms, build Pens and Segments. |
| 04–05 Structure Hierarchy | Identify Zhongshu (L1–L2) and build multi-level relations.               |
| 06–09 Signal Generation   | Label trends, detect Beichi, and merge signals.                          |
| 10 Strategy Modeling      | Multi-timeframe fusion (MMD 1–3).                                        |
| 11 Evaluation & Backtest  | ATR-based risk model, Sharpe, Win Rate, Max DD.                          |

Design Principles: Reproducibility, Modularity, Transparency, Scalability.



Reflect over

    While the ChanLab pipeline proves that market structures can be systematically reconstructed,
    it also exposes the limitations of rule-based quantification.
    The boundary between “true geometry” and “pattern fitting” remains ambiguous —
    the system may reproduce structures that look correct mathematically but lack economic causality.

    Furthermore, although deterministic, ChanLab relies heavily on hand-crafted thresholds and heuristics,
    meaning that reproducibility does not necessarily imply generalizability.
    
    A deeper question emerges:
    Is the market truly geometric, or are we imposing geometry upon noise?
    This is the central philosophical challenge that future structure-aware ML research must confront.
# -*- coding: utf-8 -*-
# strategy/baselines_ml.py
from __future__ import annotations
import numpy as np
import pandas as pd
from typing import Dict, Any, List, Tuple
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

def _to_utc_series(s: pd.Series) -> pd.Series:
    s = pd.to_datetime(s)
    try:
        tz = s.dt.tz
    except Exception:
        tz = None
    if tz is None:
        return s.dt.tz_localize("UTC")
    return s.dt.tz_convert("UTC")

def _to_utc_scalar(ts) -> pd.Timestamp:
    ts = pd.to_datetime(ts)
    if ts.tzinfo is None:
        return ts.tz_localize("UTC")
    return ts.tz_convert("UTC")


def make_classifier(name: str, params: dict | None = None):
    p = (params or {}).copy()
    name = name.lower()

    if name == "rf":
        return RandomForestClassifier(
            n_estimators=p.get("n_estimators", 300),
            max_depth=p.get("max_depth", 8),
            random_state=42,
            n_jobs=-1
        )

    if name == "gb":
        return GradientBoostingClassifier(random_state=42)

    if name == "lr":
        clf = LogisticRegression(
            solver=p.get("solver", "lbfgs"),
            max_iter=p.get("max_iter", 2000),
            C=p.get("C", 1.0),
            n_jobs=None,
            class_weight=p.get("class_weight", "balanced")
        )
        return Pipeline([("scaler", StandardScaler(with_mean=True, with_std=True)),
                         ("clf", clf)])

    if name == "svm":
        clf = SVC(
            C=p.get("C", 1.0),
            kernel=p.get("kernel", "rbf"),
            gamma=p.get("gamma", "scale"),
            probability=True,
            class_weight=p.get("class_weight", "balanced"),
            random_state=42
        )
        return Pipeline([("scaler", StandardScaler(with_mean=True, with_std=True)),
                         ("clf", clf)])

    raise ValueError(f"unknown model: {name}")

def build_features(kline: pd.DataFrame) -> pd.DataFrame:
    k = kline.copy()
    k["ts"] = _to_utc_series(k["timestamp"])
    k = k.sort_values("ts").reset_index(drop=True)

    def ema(s, span): return s.ewm(span=span, adjust=False).mean()
    def rsi(s, n=14):
        diff = s.diff()
        up = diff.clip(lower=0).rolling(n).mean()
        dn = (-diff.clip(upper=0)).rolling(n).mean()
        rs = up / (dn.replace(0, np.nan))
        return 100 - 100/(1+rs)

    close = k["close"]
    high, low, vol = k["high"], k["low"], k["volume"]
    macd = ema(close,12) - ema(close,26)
    macd_sig = ema(macd,9)
    macd_hist = macd - macd_sig
    rsi14 = rsi(close,14)
    ma20 = close.rolling(20).mean()
    std20 = close.rolling(20).std(ddof=0)
    boll_up, boll_dn = ma20 + 2*std20, ma20 - 2*std20
    atr = (high-low).rolling(14).mean()
    ret1 = close.pct_change()
    ret5 = close.pct_change(5)
    v_ma20 = vol.rolling(20).mean()

    feats = pd.DataFrame({
        "ts": k["ts"], "close": close,
        "macd": macd, "macd_sig": macd_sig, "macd_hist": macd_hist,
        "rsi14": rsi14, "ma20": ma20, "std20": std20,
        "boll_up": boll_up, "boll_dn": boll_dn,
        "atr14": atr, "ret1": ret1, "ret5": ret5, "v_ma20": v_ma20
    })
    feats = feats.dropna().reset_index(drop=True)
    return feats

def make_labels(df: pd.DataFrame, horizon: int = 3, eps: float = 0.001):  # 0.1%
    future_ret = df["close"].pct_change(horizon).shift(-horizon)
    y = pd.Series(np.where(future_ret >  eps, 1,
                  np.where(future_ret < -eps, 0, np.nan)), index=df.index)
    return y.dropna().astype(int)

def walk_forward_predict(
        feats: pd.DataFrame,
        train_bars=2000, test_bars=500,
        min_train=1000,
        model_name: str = "rf",
        model_params: Dict[str, Any] | None = None,
        label_horizon: int = 3,
        label_eps: float = 0.001
    ) -> pd.DataFrame:
    X_cols = [c for c in feats.columns if c not in ("ts","close")]
    y = make_labels(feats, horizon=label_horizon, eps=label_eps)
    feats = feats.loc[y.index].copy()
    y = y.loc[feats.index]

    preds = []
    i = 0
    while True:
        tr_end = i + train_bars
        te_end = tr_end + test_bars
        if te_end > len(feats): break
        if tr_end - i < min_train: break

        X_tr, y_tr = feats.iloc[i:tr_end][X_cols], y.iloc[i:tr_end]
        X_te, ts_te = feats.iloc[tr_end:te_end][X_cols], feats.iloc[tr_end:te_end]["ts"]

        clf = make_classifier(model_name, model_params)
        clf.fit(X_tr, y_tr)
        prob_up = clf.predict_proba(X_te)[:, 1]
        preds.append(pd.DataFrame({"ts": ts_te.values, "prob_up": prob_up}))
        i += test_bars

    if not preds:
        return pd.DataFrame(columns=["ts","prob_up"])
    out = pd.concat(preds, ignore_index=True)
    return out.sort_values("ts").reset_index(drop=True)


def probs_to_signals(
        prob_df: pd.DataFrame, kline: pd.DataFrame,
        p_buy=0.60, p_sell=0.40,
        source_tag: str = "ml",
        min_gap_minutes: int = 60
    ) -> pd.DataFrame:
    if prob_df is None or prob_df.empty:
        return pd.DataFrame(columns=["ts","side","price","tag","source"])

    k = kline.copy()
    k["ts"] = _to_utc_series(k["timestamp"])
    px = k.set_index("ts")["close"]

    out = []
    last_ts = None
    last_side = None

    for _, r in prob_df.iterrows():
        ts = _to_utc_scalar(r["ts"])
        if ts not in px.index:
            ix = px.index.searchsorted(ts)
            if ix >= len(px):
                continue
            ts = px.index[ix]

        #
        if last_ts is not None and (ts - last_ts).total_seconds() < min_gap_minutes*60:
            continue

        p = float(r["prob_up"])
        side = None
        if p >= p_buy:
            side = "buy"
        elif p <= p_sell:
            side = "sell"

        if side is not None:
            out.append(dict(
                ts=ts, side=side, price=float(px.loc[ts]),
                tag=("ML+" if side == "buy" else "ML-"),
                source=source_tag
            ))

            last_ts, last_side = ts, side

    return pd.DataFrame(out).sort_values("ts").reset_index(drop=True)



def ml_signals_from_kline(
        kline: pd.DataFrame,
        model_name: str = "rf",
        model_params: Dict[str, Any] | None = None,
        p_buy=0.60, p_sell=0.40,
        train_bars=2000, test_bars=500,
        label_horizon: int = 3, label_eps: float = 0.001,
        min_gap_minutes: int = 60
    ) -> pd.DataFrame:
    feats = build_features(kline)
    probs = walk_forward_predict(
        feats, train_bars=train_bars, test_bars=test_bars,
        model_name=model_name, model_params=model_params,
        label_horizon=label_horizon, label_eps=label_eps
    )
    sigs = probs_to_signals(
        probs, kline, p_buy=p_buy, p_sell=p_sell,
        source_tag=model_name, min_gap_minutes=min_gap_minutes
    )
    return sigs


def simple_backtest(signals: pd.DataFrame, kline: pd.DataFrame,
                    fee=0.001, slippage=0.0):
    if signals is None or signals.empty:
        return dict(trades=0, win_rate=np.nan, ret=np.nan, sharpe=np.nan, mdd=np.nan, curve=pd.DataFrame())

    k = kline.copy()
    k["ts"] = _to_utc_series(k["timestamp"])   # ✅ 统一UTC
    px = k.set_index("ts")["close"]

    pos = 0; entry_px = 0.0; equity = 1.0
    curve, pnl = [], []

    sig = signals.copy()
    sig["ts"] = _to_utc_series(sig["ts"])
    sig = sig.sort_values("ts")

    for _, s in sig.iterrows():
        ts = _to_utc_scalar(s["ts"])
        if ts not in px.index:
            ix = px.index.searchsorted(ts)
            if ix >= len(px):
                continue
            ts = px.index[ix]

        price = float(px.loc[ts]) * (1 + slippage if s["side"]=="buy" else 1 - slippage)

        # 反手/平仓
        if pos != 0 and ((pos==1 and s["side"]=="sell") or (pos==-1 and s["side"]=="buy")):
            r = (price / entry_px - 1) * (1 if pos==1 else -1)
            r -= fee
            equity *= (1 + r)
            pnl.append(r)
            pos = 0
            entry_px = 0.0

        if pos == 0:
            pos = 1 if s["side"]=="buy" else -1
            entry_px = price * (1 + fee)

        curve.append(dict(ts=ts, equity=equity))

    curve_df = pd.DataFrame(curve).drop_duplicates(subset=["ts"]).set_index("ts").sort_index()
    if curve_df.empty:
        return dict(trades=0, win_rate=np.nan, ret=np.nan, sharpe=np.nan, mdd=np.nan, curve=pd.DataFrame())

    rets = pd.Series(pnl)
    win_rate = (rets > 0).mean() if len(rets)>0 else np.nan
    total_ret = curve_df["equity"].iloc[-1] - 1
    sharpe = (rets.mean() / (rets.std() + 1e-9)) * np.sqrt(max(1, len(rets))) if len(rets)>1 else np.nan
    peak = curve_df["equity"].cummax()
    mdd = ((curve_df["equity"]/peak) - 1).min()

    return dict(trades=int(len(rets)), win_rate=float(win_rate), ret=float(total_ret),
                sharpe=float(sharpe), mdd=float(mdd), curve=curve_df.reset_index())

# -*- coding: utf-8 -*-
# strategy/baselines_traditional.py
from __future__ import annotations
import numpy as np
import pandas as pd
from typing import List, Dict, Any

def ema(s: pd.Series, span: int) -> pd.Series:
    return s.ewm(span=span, adjust=False).mean()

def macd_core(close: pd.Series, fast=12, slow=26, sig=9):
    macd = ema(close, fast) - ema(close, slow)
    signal = ema(macd, sig)
    hist = macd - signal
    return macd, signal, hist

def rsi_core(close: pd.Series, n=14):
    diff = close.diff()
    up = diff.clip(lower=0).rolling(n).mean()
    dn = (-diff.clip(upper=0)).rolling(n).mean()
    rs = up / (dn.replace(0, np.nan))
    return 100 - 100 / (1 + rs)

def boll_core(close: pd.Series, n=20, k=2):
    ma = close.rolling(n).mean()
    sd = close.rolling(n).std(ddof=0)
    up, dn = ma + k*sd, ma - k*sd
    bw = (up - dn) / ma
    return ma, up, dn, bw

def moving_average_signals(kline: pd.DataFrame, fast=10, slow=30) -> pd.DataFrame:
    assert fast < slow, "fast 应小于 slow"
    k = kline.copy()
    k["ts"] = pd.to_datetime(k["timestamp"])
    ma_fast = k["close"].rolling(fast, min_periods=fast).mean()
    ma_slow = k["close"].rolling(slow, min_periods=slow).mean()

    valid = ma_fast.notna() & ma_slow.notna()
    diff = (ma_fast - ma_slow).where(valid)

    cross_up = (diff > 0) & (diff.shift(1) <= 0)
    cross_dn = (diff < 0) & (diff.shift(1) >= 0)

    buy  = k.loc[cross_up.fillna(False), ["ts","close"]].assign(side="buy",
                                                                tag=f"MA{fast}_{slow}+",
                                                                source="ma_crossover")
    sell = k.loc[cross_dn.fillna(False), ["ts","close"]].assign(side="sell",
                                                                tag=f"MA{fast}_{slow}-",
                                                                source="ma_crossover")
    out = pd.concat([buy, sell], ignore_index=True).rename(columns={"close":"price"})
    out = out.drop_duplicates(subset=["ts","side"], keep="first")
    return out.sort_values("ts").reset_index(drop=True)


def merge_traditional_signals(*dfs: pd.DataFrame) -> pd.DataFrame:

    pool = []
    for d in dfs:
        if d is None or d.empty:
            continue
        assert {"ts","side","price"}.issubset(d.columns), "输入信号缺列"
        x = d[["ts","side","price","tag","source"]].copy()
        x["ts"] = pd.to_datetime(x["ts"])
        pool.append(x)

    if not pool:
        return pd.DataFrame(columns=["ts","side","price","tag","source"])

    out = pd.concat(pool, ignore_index=True).sort_values("ts")
    out = out.drop_duplicates(subset=["ts","side"], keep="last")
    return out.reset_index(drop=True)


def macd_signals(kline: pd.DataFrame, fast=12, slow=26, sig=9) -> pd.DataFrame:
    k = kline.copy()
    k["ts"] = pd.to_datetime(k["timestamp"])
    macd, signal, _ = macd_core(k["close"], fast, slow, sig)
    diff = macd - signal
    cross_up = (diff > 0) & (diff.shift(1) <= 0)
    cross_dn = (diff < 0) & (diff.shift(1) >= 0)
    buy = k.loc[cross_up, ["ts","close"]].assign(side="buy", tag="MACD+", source="macd_xover")
    sell = k.loc[cross_dn, ["ts","close"]].assign(side="sell", tag="MACD-", source="macd_xover")
    out = pd.concat([buy, sell], ignore_index=True).rename(columns={"close":"price"})
    return out.sort_values("ts").reset_index(drop=True)

def rsi_signals(kline: pd.DataFrame, n=14, ob=70, os=30) -> pd.DataFrame:
    k = kline.copy()
    k["ts"] = pd.to_datetime(k["timestamp"])
    rsi = rsi_core(k["close"], n)
    buy = k.loc[(rsi.shift(1) < os) & (rsi >= os), ["ts","close"]].assign(side="buy", tag=f"RSI{n}_OS", source="rsi")
    sell = k.loc[(rsi.shift(1) > ob) & (rsi <= ob), ["ts","close"]].assign(side="sell", tag=f"RSI{n}_OB", source="rsi")
    out = pd.concat([buy, sell], ignore_index=True).rename(columns={"close":"price"})
    return out.sort_values("ts").reset_index(drop=True)

def boll_signals(kline: pd.DataFrame, n=20, k_band=2) -> pd.DataFrame:
    k = kline.copy()
    k["ts"] = pd.to_datetime(k["timestamp"])
    ma, up, dn, _ = boll_core(k["close"], n, k_band)
    buy = k.loc[(k["close"] > up) & (k["close"].shift(1) <= up.shift(1)), ["ts","close"]].assign(side="buy", tag="BOLL_UP", source="boll")
    sell = k.loc[(k["close"] < dn) & (k["close"].shift(1) >= dn.shift(1)), ["ts","close"]].assign(side="sell", tag="BOLL_DN", source="boll")
    out = pd.concat([buy, sell], ignore_index=True).rename(columns={"close":"price"})
    return out.sort_values("ts").reset_index(drop=True)

def simple_backtest(signals: pd.DataFrame, kline: pd.DataFrame,
                    fee=0.001, slippage=0.0) -> Dict[str, Any]:
    if signals is None or signals.empty:
        return dict(trades=0, win_rate=np.nan, ret=np.nan, sharpe=np.nan, mdd=np.nan, curve=pd.DataFrame())
    k = kline.copy()
    k["ts"] = pd.to_datetime(k["timestamp"])
    px = k.set_index("ts")["close"]

    pos = 0  # -1/0/1
    entry_px = 0.0
    equity = 1.0
    curve = []
    pnl_list = []

    sig = signals.sort_values("ts").copy()
    for _, s in sig.iterrows():
        ts = pd.to_datetime(s["ts"])
        if ts not in px.index:
            ix = px.index.searchsorted(ts)
            if ix >= len(px): continue
            ts = px.index[ix]
        price = float(px.loc[ts]) * (1 + slippage if s["side"]=="buy" else 1 - slippage)

        if pos != 0 and ((pos==1 and s["side"]=="sell") or (pos==-1 and s["side"]=="buy")):
            ret = (price / entry_px - 1) * (1 if pos==1 else -1)
            ret -= fee
            equity *= (1 + ret)
            pnl_list.append(ret)
            pos = 0
            entry_px = 0.0
        if pos == 0:
            pos = 1 if s["side"]=="buy" else -1
            entry_px = price * (1 + fee)

        curve.append(dict(ts=ts, equity=equity))

    curve_df = pd.DataFrame(curve).drop_duplicates(subset=["ts"]).set_index("ts").sort_index()
    if curve_df.empty:
        return dict(trades=0, win_rate=np.nan, ret=np.nan, sharpe=np.nan, mdd=np.nan, curve=pd.DataFrame())

    rets = pd.Series(pnl_list)
    win_rate = (rets > 0).mean() if len(rets)>0 else np.nan
    total_ret = curve_df["equity"].iloc[-1] - 1
    sharpe = (rets.mean()/ (rets.std()+1e-9)) * np.sqrt(max(1, len(rets))) if len(rets)>1 else np.nan
    peak = curve_df["equity"].cummax()
    mdd = ((curve_df["equity"]/peak)-1).min()

    return dict(trades=int(len(rets)), win_rate=float(win_rate), ret=float(total_ret),
                sharpe=float(sharpe), mdd=float(mdd), curve=curve_df.reset_index())

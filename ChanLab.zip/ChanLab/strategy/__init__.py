# strategy/__init__.py
# -*- coding: utf-8 -*-
from .baselines_traditional import (
    macd_signals, rsi_signals, boll_signals, moving_average_signals,
    merge_traditional_signals, simple_backtest as backtest_traditional,
)
from .baselines_ml import (
    ml_signals_from_kline,
    simple_backtest as backtest_ml,
)

__all__ = [
    # TA
    "macd_signals", "rsi_signals", "boll_signals", "moving_average_signals",
    "merge_traditional_signals", "backtest_traditional",
    # ML
    "ml_signals_from_kline", "backtest_ml",
]

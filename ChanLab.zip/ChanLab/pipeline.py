#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
pipeline.py
End-to-end pipeline (00–11) that reproduces the Note outputs.

- Steps 00–03 are executed by running the original notebooks to guarantee parity.
- Steps 04–11 are implemented in lightweight Python mirroring your curated Note code.
- Paths are resolved relative to this file, and also work if run from /scripts.

Usage:
  python pipeline.py --start 0 --end 11 --force
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, List, Tuple, Dict, Optional

import pandas as pd
import numpy as np

# --- Optional: use nbclient to execute 00–03 notebooks exactly like Note ---
# If nbclient is unavailable, we raise a friendly error when those steps are requested.
try:
    from nbclient import NotebookClient
    import nbformat
    _NB_OK = True
except Exception:
    _NB_OK = False

# --- Project layout detection ------------------------------------------------

def _detect_root() -> Path:
    here = Path(__file__).resolve()
    # project root if running from ./pipeline.py
    root = here.parent
    # if placed in ./scripts/pipeline.py, step one level up
    if root.name.lower() == "scripts":
        root = root.parent
    return root

ROOT = _detect_root()
DATA = ROOT / "DATA"
CHAN = ROOT / "chan_data"
REPORTS = ROOT / "reports"
NOTE = ROOT / "Note"   # where 00–11 notebooks live

# Canonical notebook sequence
NOTE_SEQ = [
    "00_chan K Generation.ipynb",
    "01_fractal.ipynb",
    "02_bi.ipynb",
    "03_segment.ipynb",
    "04_zhongshu.ipynb",
    "05_zhongshu hireachy.ipynb",
    "06_trend.ipynb",
    "07_trend signals.ipynb",
    "08_Mapping.ipynb",
    "09_Trend signal falling + back-speed skeleton.ipynb",
    "10_mmd.ipynb",
    "11_Signal browsing.ipynb",
]

# Default universe
DEFAULT_SYMBOLS = ["BTCUSDT", "ETHUSDT"]
DEFAULT_TFS = ["5m", "15m", "30m", "1h", "4h"]

# --------------------------------------------------------------------------------------
# Args / Config
# --------------------------------------------------------------------------------------

@dataclass
class Config:
    symbols: List[str]
    tfs: List[str]
    start: int
    end: int
    force: bool

def parse_args() -> Config:
    p = argparse.ArgumentParser(description="ChanLab pipeline (00–11)")
    p.add_argument("--symbols", nargs="+", default=DEFAULT_SYMBOLS, help="Symbols to run")
    p.add_argument("--tfs", nargs="+", default=DEFAULT_TFS, help="Timeframes to run")
    p.add_argument("--start", type=int, default=0, help="Start step (0..11)")
    p.add_argument("--end", type=int, default=11, help="End step (0..11)")
    p.add_argument("--force", action="store_true", help="Force regenerate outputs")
    args = p.parse_args()
    return Config(
        symbols=args.symbols,
        tfs=args.tfs,
        start=args.start,
        end=args.end,
        force=args.force,
    )

# --------------------------------------------------------------------------------------
# Utilities
# --------------------------------------------------------------------------------------

def info(msg: str) -> None:
    print(msg, flush=True)

def ensure_dirs() -> None:
    CHAN.mkdir(parents=True, exist_ok=True)
    REPORTS.mkdir(parents=True, exist_ok=True)

def _exists_any(paths: Iterable[Path]) -> bool:
    return any(p.exists() for p in paths)

# --------------------------------------------------------------------------------------
# Step 00–03: execute notebooks to guarantee parity with Note
# --------------------------------------------------------------------------------------

def _nb_run(notebook_name: str, timeout: int = 0) -> None:
    """
    Execute a notebook under ROOT/Note exactly, to reproduce 00–03 behavior.
    timeout=0 => no cell timeout (long cells OK).
    """
    if not _NB_OK:
        raise RuntimeError(
            "nbclient is not installed. Install it to execute 00–03 notebooks:\n"
            "  pip install nbclient nbformat"
        )
    nb_path = NOTE / notebook_name
    if not nb_path.exists():
        raise FileNotFoundError(f"Notebook not found: {nb_path}")

    nb = nbformat.read(nb_path, as_version=4)
    client = NotebookClient(
        nb, timeout=timeout or None, kernel_name="python3", allow_errors=True
    )
    client.execute()
    # We do not write back the notebook; we only execute cells for side effects (CSV outputs).


def step_00_to_03(force: bool) -> None:
    """
    Run 00–03 notebooks to generate fractals/bi/segments exactly like the Note.
    We detect if outputs exist and skip when not forcing.
    """
    # Quick presence check for the main artifacts created by 00–03
    need = []
    for s in DEFAULT_SYMBOLS:
        for tf in DEFAULT_TFS:
            need.append(CHAN / "segments" / "fast" / s / f"{tf}_segments.csv")
            need.append(CHAN / "segments" / "slow" / s / f"{tf}_segments.csv")

    if (not force) and _exists_any(need):
        info("[00–03][skip] segments already exist (use --force to rebuild).")
        return

    for nb in NOTE_SEQ[0:4]:
        t0 = time.time()
        info(f"[00–03] running notebook: {nb}")
        _nb_run(nb)
        info(f"[00–03] done {nb} in {time.time()-t0:.1f}s")

# --------------------------------------------------------------------------------------
# Step 04: zhongshu (slow/fast) using fixed JSON configs (your curated cell 2)
# --------------------------------------------------------------------------------------

def step_04_zhongshu(symbols: List[str], tfs: List[str], force: bool) -> None:
    from chan import detect_zhongshu, validate_chan_zhongshu

    cfg_slow = json.load(open(ROOT / "configs" / "zhongshu_slow_default.json", "r"))
    cfg_fast = json.load(open(ROOT / "configs" / "zhongshu_fast_default.json", "r"))
    SEG = {
        "slow": CHAN / "segments" / "slow",
        "fast": CHAN / "segments" / "fast",
    }
    OUT = {
        "slow": CHAN / "zhongshu_slow",
        "fast": CHAN / "zhongshu_fast",
    }
    for v in OUT.values():
        v.mkdir(parents=True, exist_ok=True)

    def _run_one(version: str, sym: str, tf: str) -> None:
        seg_path = SEG[version] / sym / f"{tf}_segments.csv"
        out_path = OUT[version] / sym / f"{tf}_zhongshu.csv"
        if out_path.exists() and (not force):
            return
        if not seg_path.exists():
            info(f"[04][skip] {version}/{sym}/{tf} segments missing")
            return
        df = pd.read_csv(seg_path, parse_dates=["timestamp_start", "timestamp_end"])
        if df.empty:
            info(f"[04][skip] {version}/{sym}/{tf} empty")
            return
        cfg = cfg_slow if version == "slow" else cfg_fast
        zs = detect_zhongshu(df, **cfg)
        rep = validate_chan_zhongshu(zs, f"{version}-{sym}-{tf}", verbose=False)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        zs.to_csv(out_path, index=False)
        grade = rep.get("grade_dist", {})
        rel = rep.get("relation_dist", {})
        info(f"[04][saved] {version}-{sym}-{tf}: zs={len(zs)} grade={grade} relation={rel}")

    t0 = time.time()
    info("=== [04] start ===")
    for version in ("slow", "fast"):
        for s in symbols:
            for tf in tfs:
                _run_one(version, s, tf)
    info(f"=== [04] done in {time.time()-t0:.1f}s ===")

# --------------------------------------------------------------------------------------
# Step 05: zhongshu hierarchy (fast) and a clean summary CSV
# --------------------------------------------------------------------------------------

def step_05_hierarchy(symbols: List[str], tfs: List[str], force: bool) -> None:
    from chan.zhongshu_hierarchy import build_zhongshu_hierarchy, summarize_hierarchy

    OUTDIR = CHAN / "zhongshu_hierarchy_fast"
    OUTDIR.mkdir(parents=True, exist_ok=True)

    # Part A: clean summary with fixed params (discovery, min_ratio=0.0005, etc.)
    records: List[Dict] = []
    for sym in symbols:
        for tf in tfs:
            p = CHAN / "zhongshu_fast" / sym / f"{tf}_zhongshu.csv"
            if not p.exists():
                info(f"[05][skip] {sym}-{tf}: missing zhongshu_fast")
                continue
            l1 = pd.read_csv(p, parse_dates=["timestamp_start", "timestamp_end"])
            if l1.empty:
                info(f"[05][skip] {sym}-{tf}: empty")
                continue

            try:
                levels, pmap = build_zhongshu_hierarchy(
                    l1, max_levels=3, mode="discovery",
                    min_ratio=0.0005, strict_alt=False,
                    allow_overlap_zs=True, enable_quality=True,
                )
            except Exception as e:
                info(f"[05][error] {sym}-{tf}: {e}")
                continue

            summ = summarize_hierarchy(levels, pmap)
            n1 = len(levels[0]) if len(levels) > 0 and levels[0] is not None else 0
            n2 = len(levels[1]) if len(levels) > 1 and levels[1] is not None else 0
            n3 = len(levels[2]) if len(levels) > 2 and levels[2] is not None else 0

            records.append(dict(
                symbol=sym, tf=tf, which="fast",
                n_L1=n1, n_L2=n2, n_L3=n3,
                width_median_L2=(summ["levels"][1].get("width_median")
                                 if len(summ["levels"]) > 1 else None),
                overlap_L2=(summ["levels"][1].get("time_overlap")
                            if len(summ["levels"]) > 1 else None),
            ))

    if records:
        df = pd.DataFrame(records).sort_values(["symbol", "tf"]).reset_index(drop=True)
        (ROOT / "reports").mkdir(parents=True, exist_ok=True)
        df.to_csv(ROOT / "reports" / "zhongshu_hierarchy_clean_fast.csv", index=False)
    else:
        info("[05][warn] no records for clean summary")

    # Part B: write L1..L3 CSVs
    records2: List[Dict] = []
    for sym in symbols:
        for tf in tfs:
            p = CHAN / "zhongshu_fast" / sym / f"{tf}_zhongshu.csv"
            if not p.exists():
                continue
            l1 = pd.read_csv(p, parse_dates=["timestamp_start", "timestamp_end"])
            if l1.empty:
                continue

            try:
                info(f"[05][run] {sym}-{tf} building hierarchy ...")
                levels, _ = build_zhongshu_hierarchy(
                    l1, max_levels=3, mode="discovery",
                    min_ratio=0.0005, strict_alt=False,
                    allow_overlap_zs=True, enable_quality=True,
                )
            except Exception as e:
                info(f"[05][error] {sym}-{tf}: {e}")
                continue

            out_dir = OUTDIR / sym
            out_dir.mkdir(parents=True, exist_ok=True)
            for i, lv in enumerate(levels, start=1):
                if lv is None or lv.empty:
                    continue
                (out_dir / f"{tf}_L{i}.csv").write_text(lv.to_csv(index=False))
                records2.append({
                    "symbol": sym, "tf": tf, "which": "fast",
                    "level": f"L{i}", "count": len(lv),
                    "width_median": (lv["zs_high"].sub(lv["zs_low"]).median()
                                     if "zs_high" in lv else None)
                })
                info(f"[05][saved] {sym}-{tf} {i}: n={len(lv)}")

    if not records2:
        info("[05][warn] no hierarchy levels saved")

# --------------------------------------------------------------------------------------
# Step 06: practical trend labeling using reports/trend_practical_best.csv
# --------------------------------------------------------------------------------------

def step_06_trend(symbols: List[str], tfs: List[str], force: bool) -> None:
    from chan.chan_trend import label_trend_practical

    best_csv = REPORTS / "trend_practical_best.csv"
    if not best_csv.exists():
        info(f"[06][skip] missing best params: {best_csv}")
        return
    best = pd.read_csv(best_csv)

    OUT = CHAN / "trend_practical"
    OUT.mkdir(parents=True, exist_ok=True)

    for _, row in best.iterrows():
        sym, tf = str(row["symbol"]), str(row["tf"])
        if sym not in symbols or tf not in tfs:
            continue
        seg_path = CHAN / "segments" / "fast" / sym / f"{tf}_segments.csv"
        out_path = OUT / sym / f"{tf}_trend.csv"
        if out_path.exists() and (not force):
            continue
        if not seg_path.exists():
            info(f"[06][skip] {sym}-{tf}: segments missing")
            continue
        seg = pd.read_csv(seg_path, parse_dates=["timestamp_start", "timestamp_end"])
        if seg.empty:
            info(f"[06][skip] {sym}-{tf}: empty segments")
            continue

        info(f"[06][run] {sym}-{tf} ...")
        tr = label_trend_practical(
            seg,
            gap_hours=float(row["gap_hours"]),
            price_change_threshold=float(row["price_thr"]),
            min_segments=int(row["min_segments"]),
            enable_quality=True,
        )
        out_dir = OUT / sym
        out_dir.mkdir(parents=True, exist_ok=True)
        tr.to_csv(out_dir / f"{tf}_trend.csv", index=False)
        info(f"[06][saved] {sym}-{tf}: n={len(tr)}")

# --------------------------------------------------------------------------------------
# Step 07: trend signals from trends + fast segments
# --------------------------------------------------------------------------------------

def step_07_trend_signals(symbols: List[str], tfs: List[str], force: bool) -> None:
    from chan.signals.trend_signal import batch_generate_trend_signals

    out_dir = CHAN / "trend_signals"
    out_dir.mkdir(parents=True, exist_ok=True)

    # We let the function overwrite; force flag is informational here.
    batch_generate_trend_signals(
        base_path=str(CHAN),
        symbols=symbols,
        tfs=tfs,
        trend_subdir="trend_practical",
        seg_subdir="segments/fast",
        out_subdir="trend_signals",
    )
    info("[07] trend signals generated")

# --------------------------------------------------------------------------------------
# Step 08: map fast segments to raw candles and QC
# --------------------------------------------------------------------------------------

def step_08_mapping(symbols: List[str], tfs: List[str], force: bool) -> None:
    def _read_candles(p: Path) -> pd.DataFrame:
        df = pd.read_csv(p)
        if "timestamp" not in df.columns:
            for c in ["time", "datetime", "ts"]:
                if c in df.columns:
                    df = df.rename(columns={c: "timestamp"})
                    break
        need = {"timestamp", "open", "high", "low", "close"}
        miss = need - set(df.columns)
        if miss:
            raise ValueError(f"candles missing columns: {sorted(miss)} @ {p}")
        df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True, errors="coerce")
        df = (df.dropna(subset=["timestamp"])
                .sort_values("timestamp")
                .drop_duplicates(subset=["timestamp"], keep="last")
                .reset_index(drop=True))
        df["bar_index"] = np.arange(len(df), dtype=int)
        return df

    def _read_segments(p: Path) -> pd.DataFrame:
        df = pd.read_csv(p, parse_dates=["timestamp_start", "timestamp_end"])
        need = {"segment_index", "timestamp_start", "timestamp_end"}
        miss = need - set(df.columns)
        if miss:
            raise ValueError(f"segments missing columns: {sorted(miss)} @ {p}")
        df["timestamp_start"] = pd.to_datetime(df["timestamp_start"], utc=True)
        df["timestamp_end"] = pd.to_datetime(df["timestamp_end"], utc=True)
        return df.sort_values(["timestamp_start", "timestamp_end"]).reset_index(drop=True)

    def map_segments_to_candles(segments: pd.DataFrame, candles: pd.DataFrame) -> pd.DataFrame:
        if segments is None or segments.empty:
            return pd.DataFrame(columns=list(segments.columns) + ["start_bar_index", "end_bar_index"])
        if candles is None or candles.empty:
            raise ValueError("empty candles")
        seg = segments.copy().reset_index(drop=True)
        c = candles.copy().reset_index(drop=True)
        ts = c["timestamp"].to_numpy()
        svals = seg["timestamp_start"].to_numpy()
        evals = seg["timestamp_end"].to_numpy()
        start_idx = np.searchsorted(ts, svals, side="left")
        end_idx = np.searchsorted(ts, evals, side="right") - 1
        start_idx = np.clip(start_idx, 0, len(ts) - 1)
        end_idx = np.clip(end_idx, 0, len(ts) - 1)
        bad = start_idx > end_idx
        end_idx[bad] = start_idx[bad]
        out = seg.copy()
        out["start_bar_index"] = start_idx.astype("int64")
        out["end_bar_index"] = end_idx.astype("int64")
        end_ts = c.loc[out["end_bar_index"].astype(int), "timestamp"].to_numpy()
        too_late = end_ts > evals
        if np.any(too_late):
            fix_idx = out.loc[too_late, "end_bar_index"].astype(int).to_numpy()
            fix_idx -= 1
            fix_idx = np.clip(fix_idx, 0, len(ts) - 1)
            out.loc[too_late, "end_bar_index"] = fix_idx.astype("int64")
        bad2 = out["start_bar_index"] > out["end_bar_index"]
        if bad2.any():
            out.loc[bad2, "end_bar_index"] = out.loc[bad2, "start_bar_index"]
        return out

    OUT_BASE = CHAN / "mapped" / "segments_fast"
    OUT_BASE.mkdir(parents=True, exist_ok=True)

    logs = []
    for sym in symbols:
        for tf in tfs:
            p_candles = DATA / sym / f"{tf}.csv"
            p_seg = CHAN / "segments" / "fast" / sym / f"{tf}_segments.csv"
            out_path = OUT_BASE / sym / f"{tf}_segments_mapped.csv"
            if out_path.exists() and (not force):
                continue
            if not p_candles.exists():
                info(f"[08][skip] {sym}-{tf}: candles missing -> {p_candles}")
                continue
            if not p_seg.exists():
                info(f"[08][skip] {sym}-{tf}: segments missing -> {p_seg}")
                continue
            candles = _read_candles(p_candles)
            seg = _read_segments(p_seg)
            mapped = map_segments_to_candles(seg, candles)
            out_path.parent.mkdir(parents=True, exist_ok=True)
            mapped.to_csv(out_path, index=False)
            bad = int((mapped["start_bar_index"] > mapped["end_bar_index"]).sum())
            info(f"[08][saved] {sym}-{tf}: n={len(mapped)}, bad={bad}")

    # quick QC
    rows = []
    for sym in symbols:
        for tf in tfs:
            p_c = DATA / sym / f"{tf}.csv"
            p_m = OUT_BASE / sym / f"{tf}_segments_mapped.csv"
            if not (p_c.exists() and p_m.exists()):
                continue
            c = pd.read_csv(p_c)
            if "timestamp" not in c.columns:
                for col in ("time", "datetime", "ts"):
                    if col in c.columns:
                        c = c.rename(columns={col: "timestamp"})
                        break
            c["timestamp"] = pd.to_datetime(c["timestamp"], utc=True, errors="coerce")
            c = c.dropna(subset=["timestamp"]).reset_index(drop=True)
            m = pd.read_csv(p_m)
            if c.empty or m.empty:
                continue
            bad_range = ((m["start_bar_index"] < 0) | (m["end_bar_index"] >= len(c))).sum()
            bad_order = (m["start_bar_index"] > m["end_bar_index"]).sum()
            end_ts = c.loc[m["end_bar_index"].astype(int), "timestamp"].to_numpy()
            seg_end = pd.to_datetime(m["timestamp_end"], utc=True).to_numpy()
            bad_future = (end_ts > seg_end).sum()
            seg_len = (m["end_bar_index"] - m["start_bar_index"] + 1).clip(lower=1)
            rows.append(dict(
                symbol=sym, tf=tf,
                bad_range=int(bad_range), bad_order=int(bad_order), bad_future=int(bad_future),
                n_segments=int(len(m)), n_candles=int(len(c)),
                avg_span=float(seg_len.mean())
            ))
    if rows:
        qc = pd.DataFrame(rows).sort_values(["symbol", "tf"]).reset_index(drop=True)
        info(qc.to_string(index=False))

# --------------------------------------------------------------------------------------
# Step 09: beichi signals and merged signals (trend + beichi)
# --------------------------------------------------------------------------------------

def step_09_beichi_and_merge(symbols: List[str], tfs: List[str], force: bool) -> None:
    from chan.signals.beichi import (
        detect_beichi_over_segments,
        detect_beichi_over_ranges,
    )

    TREND_DIR = CHAN / "trend_signals"
    BEICHI_DIR = CHAN / "signals" / "beichi"
    MERGED_DIR = CHAN / "signals" / "merged"
    BEICHI_DIR.mkdir(parents=True, exist_ok=True)
    MERGED_DIR.mkdir(parents=True, exist_ok=True)

    def _read_kline(sym: str, tf: str) -> pd.DataFrame:
        p = DATA / sym / f"{tf}.csv"
        df = pd.read_csv(p)
        if "timestamp" not in df.columns:
            for c in ("time", "datetime", "ts"):
                if c in df.columns:
                    df = df.rename(columns={c: "timestamp"})
                    break
        df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True, errors="coerce")
        df = (df.dropna(subset=["timestamp"])
                .sort_values("timestamp")
                .reset_index(drop=True))
        for col in ("open", "high", "low", "close"):
            if col not in df.columns:
                raise ValueError(f"missing column {col} in {p}")
        if "volume" not in df.columns:
            df["volume"] = 0.0
        return df

    def _read_segments(sym: str, tf: str) -> pd.DataFrame:
        p = CHAN / "segments" / "fast" / sym / f"{tf}_segments.csv"
        if not p.exists():
            return pd.DataFrame()
        df = pd.read_csv(p, parse_dates=["timestamp_start", "timestamp_end"])
        df["timestamp_start"] = pd.to_datetime(df["timestamp_start"], utc=True)
        df["timestamp_end"] = pd.to_datetime(df["timestamp_end"], utc=True)
        return df

    def _read_zs_l1(sym: str, tf: str) -> pd.DataFrame:
        p = CHAN / "zhongshu_hierarchy_fast" / sym / f"{tf}_L1.csv"
        if not p.exists():
            return pd.DataFrame()
        df = pd.read_csv(p, parse_dates=["timestamp_start", "timestamp_end"])
        return df

    def _events_to_df(evts: List[Dict]) -> pd.DataFrame:
        if not evts:
            return pd.DataFrame(columns=["ts", "etype", "price", "score", "payload"])
        rows = []
        for e in evts:
            rows.append(dict(
                ts=pd.to_datetime(e.get("ts"), utc=True),
                etype=e.get("etype", ""),
                price=float(e.get("price", float("nan"))),
                score=float(e.get("payload", {}).get("score", float("nan"))),
                payload=json.dumps(e.get("payload", {}), ensure_ascii=False),
            ))
        return pd.DataFrame(rows).sort_values("ts").reset_index(drop=True)

    # 09A/09B: generate beichi
    for sym in symbols:
        for tf in tfs:
            k = _read_kline(sym, tf)
            seg = _read_segments(sym, tf)
            zs = _read_zs_l1(sym, tf)
            out_dir = BEICHI_DIR / sym
            out_dir.mkdir(parents=True, exist_ok=True)

            # over segments
            trend_evts = []
            if not seg.empty:
                trend_evts = detect_beichi_over_segments(kline=k, segments=seg, enable_macd=True)
            df_trend = _events_to_df(trend_evts)
            df_trend.to_csv(out_dir / f"{tf}_beichi_trend.csv", index=False)

            # over ranges (L1)
            range_evts = []
            if not zs.empty:
                range_evts = detect_beichi_over_ranges(
                    kline=k, zs_l1=zs, enable_macd=True, band_ratio=0.002
                )
            df_range = _events_to_df(range_evts)
            df_range.to_csv(out_dir / f"{tf}_beichi_range.csv", index=False)

            df_all = pd.concat([df_trend, df_range], ignore_index=True).sort_values("ts").reset_index(drop=True)
            df_all.to_csv(out_dir / f"{tf}_beichi_all.csv", index=False)
            info(f"[09][beichi] {sym}-{tf}: trend={len(df_trend)}, range={len(df_range)}, all={len(df_all)}")

    # 09C: merge trend_signals + beichi_all into merged_signals
    for sym in symbols:
        for tf in tfs:
            p_tr = TREND_DIR / sym / f"{tf}_trend_signal.csv"
            p_bc = BEICHI_DIR / sym / f"{tf}_beichi_all.csv"
            if not p_tr.exists() or not p_bc.exists():
                info(f"[09][merge][skip] {sym}-{tf}: missing inputs")
                continue
            tr = pd.read_csv(p_tr, parse_dates=["ts"])
            bc = pd.read_csv(p_bc, parse_dates=["ts"])
            tr["src"] = "trend"
            tr = tr.rename(columns={"signal": "label"}).assign(etype="SIG.TREND")
            bc["src"] = "beichi"
            if "price" in bc.columns:
                bc = bc.rename(columns={"price": "px"})
            bc = bc.assign(label="beichi")
            left = tr[["ts", "etype", "label", "direction", "src"]].assign(px=np.nan, score=np.nan)
            right = bc[["ts", "etype", "label", "px", "score", "src"]].assign(direction=np.nan)
            out = pd.concat([left, right], ignore_index=True).sort_values("ts").reset_index(drop=True)
            out_dir = MERGED_DIR / sym
            out_dir.mkdir(parents=True, exist_ok=True)
            out.to_csv(out_dir / f"{tf}_merged_signals.csv", index=False)
            info(f"[09][merged] {sym}-{tf}: trend={int((out['src']=='trend').sum())}, beichi={int((out['src']=='beichi').sum())}, total={len(out)}")

# --------------------------------------------------------------------------------------
# Step 10: MMD and trading signals + manifest
# --------------------------------------------------------------------------------------

def step_10_mmd_and_trading(symbols: List[str], tfs: List[str], force: bool) -> None:
    from chan.signals.mmd import (
        DEFAULT_POLICY, _map_beichi_to_1st,
        generate_mmd2_from_mmd1, generate_mmd3_from_zs,
        merge_mmd_signals
    )
    from chan.signals.merge import generate_trading_signals

    def _read_k(sym, tf):
        df = pd.read_csv(DATA / sym / f"{tf}.csv")
        if "timestamp" not in df.columns:
            for c in ("time", "datetime", "ts"):
                if c in df.columns:
                    df = df.rename(columns={c: "timestamp"})
                    break
        df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True, errors="coerce")
        return (df.dropna(subset=["timestamp"])
                  .sort_values("timestamp")
                  .reset_index(drop=True))

    def _read_beichi(sym, tf):
        p = CHAN / "signals" / "beichi" / sym / f"{tf}_beichi_all.csv"
        return pd.read_csv(p, parse_dates=["ts"])

    def _read_segments(sym, tf):
        p = CHAN / "segments" / "fast" / sym / f"{tf}_segments.csv"
        df = pd.read_csv(p, parse_dates=["timestamp_start", "timestamp_end"])
        df["timestamp_start"] = pd.to_datetime(df["timestamp_start"], utc=True, errors="coerce")
        df["timestamp_end"] = pd.to_datetime(df["timestamp_end"], utc=True, errors="coerce")
        return df

    def _read_zs(sym, tf):
        p = CHAN / "zhongshu_hierarchy_fast" / sym / f"{tf}_L1.csv"
        if not p.exists():
            return pd.DataFrame()
        df = pd.read_csv(p, parse_dates=["timestamp_start", "timestamp_end"])
        df["timestamp_start"] = pd.to_datetime(df["timestamp_start"], utc=True, errors="coerce")
        df["timestamp_end"] = pd.to_datetime(df["timestamp_end"], utc=True, errors="coerce")
        return df

    for sym in symbols:
        mmd_by_tf = {}
        zs_by_tf = {}
        for tf in tfs:
            k = _read_k(sym, tf)
            bc = _read_beichi(sym, tf)
            seg = _read_segments(sym, tf)
            zs = _read_zs(sym, tf)
            zs_by_tf[tf] = zs

            mmd1 = _map_beichi_to_1st(bc, k, dict(DEFAULT_POLICY))
            mmd2 = generate_mmd2_from_mmd1(k, mmd1, dict(DEFAULT_POLICY))
            mmd3 = generate_mmd3_from_zs(k, seg, zs, dict(DEFAULT_POLICY))
            mmd = merge_mmd_signals(mmd1, mmd2, mmd3)
            mmd_by_tf[tf] = mmd

            out_dir = CHAN / "signals" / "mmd" / sym
            out_dir.mkdir(parents=True, exist_ok=True)
            mmd.to_csv(out_dir / f"{tf}_mmd123.csv", index=False)
            info(f"[10][MMD] {sym}-{tf}: 1={len(mmd1)}, 2={len(mmd2)}, 3={len(mmd3)}, all={len(mmd)}")

        merged = generate_trading_signals(mmd_by_tf, zs_by_tf)
        out2 = CHAN / "signals" / "trading" / sym
        out2.mkdir(parents=True, exist_ok=True)
        merged.to_csv(out2 / "multi_tf_trading_signals.csv", index=False)
        info(f"[10][TRD] {sym}: {len(merged)} -> {out2/'multi_tf_trading_signals.csv'}")

    # manifest
    rows = []
    for p in CHAN.rglob("*.csv"):
        try:
            rel = p.relative_to(CHAN)
        except Exception:
            rel = p.name
        rows.append(dict(
            rel=str(rel),
            bytes=p.stat().st_size,
            mtime=pd.Timestamp(p.stat().st_mtime, unit="s", tz="UTC"),
        ))
    mf = pd.DataFrame(rows).sort_values("rel").reset_index(drop=True)
    outp = CHAN / "_manifest.csv"
    mf.to_csv(outp, index=False)
    info(f"[10][MANIFEST] {len(mf)} files -> {outp}")

# --------------------------------------------------------------------------------------
# Step 11: summaries + alerts
# --------------------------------------------------------------------------------------

def step_11_summaries_and_alerts(symbols: List[str], tfs: List[str], force: bool) -> None:
    def load_trading(sym: str) -> pd.DataFrame:
        p = CHAN / "signals" / "trading" / sym / "multi_tf_trading_signals.csv"
        return pd.read_csv(p, parse_dates=["ts"])

    def summary_trading(sym: str, thr: float = 1.6, top_n: int = 5):
        df = load_trading(sym)
        info(f"[11][{sym}] total={len(df)}  score_final>= {thr}: {(df['score_final']>=thr).sum()}")
        grp = df.groupby(["tf", "side", "tag"]).size().sort_values(ascending=False).head(12)
        info(grp.to_string())
        top = (df.sort_values("score_final", ascending=False)
                 .head(top_n)[["ts", "tf", "side", "tag", "price", "score_final"]])
        info(top.to_string(index=False))

    def export_alerts(sym: str, min_score=1.8, lookback_hours=72, outfile="alerts.csv"):
        df = load_trading(sym)
        tmax = pd.to_datetime(df["ts"]).max()
        t0 = tmax - pd.Timedelta(hours=lookback_hours)
        pick = df[(pd.to_datetime(df["ts"]) >= t0) & (df["score_final"] >= min_score)].copy()
        pick = pick.sort_values(["ts", "score_final"], ascending=[True, False])
        outdir = CHAN / "signals" / "alerts" / sym
        outdir.mkdir(parents=True, exist_ok=True)
        p = outdir / outfile
        pick.to_csv(p, index=False)
        info(f"[11][ALERTS] {sym}: {len(pick)} -> {p}")

    for sym in symbols:
        try:
            summary_trading(sym, thr=1.6, top_n=8)
            export_alerts(sym, min_score=1.8, lookback_hours=72)
        except FileNotFoundError:
            info(f"[11][skip] {sym}: trading file missing")

# --------------------------------------------------------------------------------------
# Orchestrator
# --------------------------------------------------------------------------------------

def run_pipeline(cfg: Config) -> None:
    ensure_dirs()
    info(f"[info] ROOT={ROOT}")
    info(f"[info] DATA={DATA}")
    info(f"[info] CHAN={CHAN}")
    info(f"[info] REPORTS={REPORTS}")
    info(f"[info] symbols={cfg.symbols}  tfs={cfg.tfs}")
    info(f"[info] steps={cfg.start}..{cfg.end}  force={cfg.force}")

    # step dispatch
    for step in range(cfg.start, cfg.end + 1):
        t0 = time.time()
        if step == 0:
            info("=== [00] start ===")
            step_00_to_03(cfg.force)  # runs 00–03
            info(f"=== [00–03] done in {time.time()-t0:.1f}s ===")
        elif step == 1 or step == 2 or step == 3:
            # 00–03 are executed together; ignore direct calls
            info(f"[{step:02d}] already handled by step 00.")
        elif step == 4:
            info("=== [04] start ===")
            step_04_zhongshu(cfg.symbols, cfg.tfs, force=cfg.force)
            info(f"=== [04] done in {time.time()-t0:.1f}s ===")
        elif step == 5:
            info("=== [05] start ===")
            step_05_hierarchy(cfg.symbols, cfg.tfs, force=cfg.force)
            info(f"=== [05] done in {time.time()-t0:.1f}s ===")
        elif step == 6:
            info("=== [06] start ===")
            step_06_trend(cfg.symbols, cfg.tfs, force=cfg.force)
            info(f"=== [06] done in {time.time()-t0:.1f}s ===")
        elif step == 7:
            info("=== [07] start ===")
            step_07_trend_signals(cfg.symbols, cfg.tfs, force=cfg.force)
            info(f"=== [07] done in {time.time()-t0:.1f}s ===")
        elif step == 8:
            info("=== [08] start ===")
            step_08_mapping(cfg.symbols, cfg.tfs, force=cfg.force)
            info(f"=== [08] done in {time.time()-t0:.1f}s ===")
        elif step == 9:
            info("=== [09] start ===")
            step_09_beichi_and_merge(cfg.symbols, cfg.tfs, force=cfg.force)
            info(f"=== [09] done in {time.time()-t0:.1f}s ===")
        elif step == 10:
            info("=== [10] start ===")
            step_10_mmd_and_trading(cfg.symbols, cfg.tfs, force=cfg.force)
            info(f"=== [10] done in {time.time()-t0:.1f}s ===")
        elif step == 11:
            info("=== [11] start ===")
            step_11_summaries_and_alerts(cfg.symbols, cfg.tfs, force=cfg.force)
            info(f"=== [11] done in {time.time()-t0:.1f}s ===")
        else:
            info(f"[skip] unknown step {step}")

# --------------------------------------------------------------------------------------

if __name__ == "__main__":
    cfg = parse_args()
    run_pipeline(cfg)

# -*- coding: utf-8 -*-
"""

Fetch_short5_binance.py — 5m/15m/30m/1h/4h Original K Line (UTC)

- Five-level unified window: --uniform_days (default 180; set to -1, the default is graded)

- The end time is uniformly aligned to the last closed of each cycle.

- Multiple symbols, default BTCUSDT, ETHUSDT, SOLUSDT

"""
from __future__ import annotations
import os, time, argparse, requests
from typing import Optional, Dict, List
import pandas as pd

COLS = ["timestamp","open","high","low","close","volume"]
PLAN = ["5m","15m","30m","1h","4h"]
BINANCE_SUPPORTED = {"1m","3m","5m","15m","30m","1h","2h","4h","6h","8h","12h","1d","3d","1w","1M"}

def _ms(ts) -> Optional[int]:
    if ts is None: return None
    if isinstance(ts, (int, float)): return int(ts)
    if isinstance(ts, pd.Timestamp):
        ts = ts.tz_convert("UTC") if ts.tzinfo else ts.tz_localize("UTC")
        return int(ts.value // 10**6)
    return int(pd.Timestamp(ts, tz="UTC").value // 10**6)

def _pandas_rule(interval: str) -> str:
    return {"5m":"5min","15m":"15min","30m":"30min","1h":"1h","4h":"4h"}[interval]

def binance_server_now() -> pd.Timestamp:
    try:
        r = requests.get("https://api.binance.com/api/v3/time", timeout=5)
        r.raise_for_status()
        ms = int(r.json()["serverTime"])
        return pd.to_datetime(ms, unit="ms", utc=True)
    except Exception:
        return pd.Timestamp.now(tz="UTC")

def last_closed_end(interval: str, now_ts: pd.Timestamp) -> pd.Timestamp:
    return now_ts.floor(_pandas_rule(interval))

def fetch_binance_klines(symbol: str, interval: str, start=None, end=None,
                         limit=1000, max_rows=1_000_000,
                         base_url="https://api.binance.com/api/v3/klines",
                         sleep_sec=0.3, max_retries=5) -> pd.DataFrame:
    assert interval in BINANCE_SUPPORTED
    rows: List[List[float]] = []
    start_ms, end_ms = _ms(start), _ms(end)
    cur, retries = start_ms, 0
    while True:
        params: Dict[str, object] = {"symbol":symbol, "interval":interval, "limit":limit}
        if cur is not None:    params["startTime"] = cur
        if end_ms is not None: params["endTime"]  = end_ms
        try:
            r = requests.get(base_url, params=params, timeout=12)
            r.raise_for_status()
            data = r.json()
            if isinstance(data, dict) and data.get("code"):
                raise RuntimeError(f"Binance error: {data}")
            retries = 0
        except Exception:
            if retries < max_retries:
                retries += 1; time.sleep(min(1.2, 0.3*(retries+1))); continue
            raise
        if not data: break
        for otime,o,h,l,c,v,ctime,*_ in data:
            rows.append([pd.to_datetime(otime, unit="ms", utc=True),
                         float(o),float(h),float(l),float(c),float(v)])
        last_open = data[-1][0]
        if len(data) < limit: break
        cur = last_open + 1
        if end_ms is not None and cur > end_ms: break
        if len(rows) >= max_rows: break
        time.sleep(sleep_sec)
    df = pd.DataFrame(rows, columns=COLS)
    if not df.empty:
        df = df.sort_values("timestamp").drop_duplicates("timestamp", keep="last").reset_index(drop=True)
    return df

def run(symbol: str, *, out_root: str = "./data",
        uniform_days: int | None = 180,
        days_5m: int | None = None,
        days_15m: int | None = None,
        days_30m: int | None = None,
        years_1h: int | None = None,
        years_4h: int | None = None,
        global_now: pd.Timestamp | None = None):
    os.makedirs(f"{out_root}/{symbol}", exist_ok=True)
    base_now = (global_now or binance_server_now()).floor("min")
    ends = {iv: last_closed_end(iv, base_now) for iv in PLAN}
    starts: Dict[str, pd.Timestamp] = {}
    if uniform_days is not None:
        start_all = base_now - pd.Timedelta(days=int(uniform_days))
        for iv in PLAN: starts[iv] = start_all
    else:
        def def_start(iv: str) -> pd.Timestamp:
            if iv == "5m":   return base_now - pd.Timedelta(days=120)
            if iv == "15m":  return base_now - pd.Timedelta(days=180)
            if iv == "30m":  return base_now - pd.Timedelta(days=360)
            if iv == "1h":   return base_now - pd.DateOffset(years=3)
            if iv == "4h":   return base_now - pd.DateOffset(years=5)
            raise ValueError(iv)
        starts["5m"]  = base_now - pd.Timedelta(days=int(days_5m))   if days_5m  else def_start("5m")
        starts["15m"] = base_now - pd.Timedelta(days=int(days_15m))  if days_15m else def_start("15m")
        starts["30m"] = base_now - pd.Timedelta(days=int(days_30m))  if days_30m else def_start("30m")
        starts["1h"]  = base_now - pd.DateOffset(years=int(years_1h)) if years_1h else def_start("1h")
        starts["4h"]  = base_now - pd.DateOffset(years=int(years_4h)) if years_4h else def_start("4h")
    for iv in PLAN:
        start, end = starts[iv], ends[iv]
        print(f"\n[fetch] {symbol} {iv}  {start} → {end}")
        df = fetch_binance_klines(symbol, iv, start=start, end=end, limit=1000, max_rows=1_000_000)
        out_path = f"{out_root}/{symbol}/{iv}.csv"
        if df.empty: print(f"[warn] empty df: {out_path}")
        else:
            df.to_csv(out_path, index=False); print(f"[saved] {out_path} rows={len(df)}")

if __name__ == "__main__":
    p = argparse.ArgumentParser(description="Fetch Binance OHLCV for 5m/15m/30m/1h/4h (raw)")
    p.add_argument("--symbols", type=str, default="BTCUSDT,ETHUSDT,SOLUSDT",
                   help="Comma separated symbols, e.g. BTCUSDT,ETHUSDT,SOLUSDT")
    p.add_argument("--out_root", default="./data")
    # Unified window (the highest priority; set to -1 close)
    p.add_argument("--uniform_days", type=int, default=180)
    # Graded customization (only effective when uniform_days<0)
    p.add_argument("--days_5m", type=int)
    p.add_argument("--days_15m", type=int)
    p.add_argument("--days_30m", type=int)
    p.add_argument("--years_1h", type=int)
    p.add_argument("--years_4h", type=int)
    args = p.parse_args()

    symbols = [s.strip() for s in args.symbols.split(",") if s.strip()]
    GLOBAL_NOW = binance_server_now().floor("min")
    uniform_days = None if (args.uniform_days is not None and int(args.uniform_days) < 0) else args.uniform_days

    for s in symbols:
        print(f"\n=== {s} ===")
        run(s, out_root=args.out_root,
            uniform_days=uniform_days,
            days_5m=args.days_5m, days_15m=args.days_15m, days_30m=args.days_30m,
            years_1h=args.years_1h, years_4h=args.years_4h,
            global_now=GLOBAL_NOW)

"""
python fetch_short5_binance.py --symbols BTCUSDT,ETHUSDT --uniform_days 200
"""
# -*- coding: utf-8 -*-
"""
chan_fractal.py
"""

from __future__ import annotations
from typing import Literal, Optional, Dict, Any
import numpy as np
import pandas as pd

FractalType = Literal["top", "bottom"]
REQ = ['timestamp', 'open', 'high', 'low', 'close', 'volume']

DEFAULT_K = 2
DEFAULT_EPS = 1e-6
DEFAULT_MIN_AMPL = 0.0
DEFAULT_ATR_WIN = 14

def detect_fractals(
    df_k: pd.DataFrame,
    *,
    k: int = DEFAULT_K,
    eps: float = DEFAULT_EPS,
    min_amplitude: float = DEFAULT_MIN_AMPL,
    use_atr_normalize: bool = False,
    atr_window: int = DEFAULT_ATR_WIN,
    enable_validation: bool = True,
    enable_dedup_run: bool = True,
    strict: bool = True,
) -> pd.DataFrame:

    _assert_schema(df_k)
    n = len(df_k)
    if n < 2 * k + 1:
        return _empty_fractals_df()

    highs, lows = df_k['high'].to_numpy(), df_k['low'].to_numpy()
    ts = df_k['timestamp'].to_numpy()
    atr = _calc_atr(df_k, atr_window) if use_atr_normalize else None
    has_orig = ('orig_start' in df_k.columns) and ('orig_end' in df_k.columns)

    fr_rows = []

    for i in range(k, n - k):
        L, R = i - k, i + k
        win_h = highs[L:R + 1]
        win_l = lows[L:R + 1]
        c_hi, c_lo = highs[i], lows[i]

        if strict:
            if _is_top_window(win_h, win_l, k, eps):
                strength = _fr_strength(highs, lows, i, k, 'top', atr, eps)
                if strength >= min_amplitude:
                    fr_rows.append(_mk_row(df_k, i, 'top', c_hi, strength, L, R, has_orig))
                continue

            if _is_bottom_window(win_h, win_l, k, eps):
                strength = _fr_strength(highs, lows, i, k, 'bottom', atr, eps)
                if strength >= min_amplitude:
                    fr_rows.append(_mk_row(df_k, i, 'bottom', c_lo, strength, L, R, has_orig))
                continue

        else:
            if c_hi >= win_h.max() - eps:
                strength = _fr_strength(highs, lows, i, k, 'top', atr, eps)
                fr_rows.append(_mk_row(df_k, i, 'top', c_hi, strength, L, R, has_orig))
                continue

            if c_lo <= win_l.min() + eps:
                strength = _fr_strength(highs, lows, i, k, 'bottom', atr, eps)
                fr_rows.append(_mk_row(df_k, i, 'bottom', c_lo, strength, L, R, has_orig))
                continue

    fr = pd.DataFrame(fr_rows) if fr_rows else _empty_fractals_df()

    if strict and enable_dedup_run and not fr.empty:
        fr = _dedup_same_type_run(fr)
    if strict and enable_validation and not fr.empty:
        fr = _validate_fractals(fr)

    return fr.reset_index(drop=True)

def _is_top_window(win_h, win_l, k, eps):
    c_hi = win_h[k]; c_lo = win_l[k]
    max_h, max_l = win_h.max(), win_l.max()
    if not (c_hi >= max_h - eps): return False
    if not (c_lo >= max_l - eps): return False
    hi_pos = np.where(win_h >= max_h - eps)[0]
    lo_pos = np.where(win_l >= max_l - eps)[0]
    return (k in hi_pos) and (k in lo_pos)


def _is_bottom_window(win_h, win_l, k, eps):
    c_hi = win_h[k]; c_lo = win_l[k]
    min_h, min_l = win_h.min(), win_l.min()
    if not (c_lo <= min_l + eps): return False
    if not (c_hi <= min_h + eps): return False
    hi_pos = np.where(win_h <= min_h + eps)[0]
    lo_pos = np.where(win_l <= min_l + eps)[0]
    return (k in hi_pos) and (k in lo_pos)


def _fr_strength(highs, lows, i, k, kind, atr=None, eps=1e-9):
    if kind == 'top':
        ref = float(np.min(lows[i - k:i + k + 1]))
        amp = highs[i] - ref
    else:
        ref = float(np.max(highs[i - k:i + k + 1]))
        amp = ref - lows[i]

    if atr is not None and not np.isnan(atr[i]) and atr[i] > eps:
        strength = amp / float(atr[i])
    else:
        strength = amp / max(ref, eps)
    return float(strength)


def _mk_row(df_k, i, kind, price, strength, L, R, has_orig):
    if has_orig:
        o_s = df_k.iloc[i]['orig_start']
        o_e = df_k.iloc[i]['orig_end']
    else:
        o_s = None; o_e = None

    return {
        'idx': int(i),
        'type': kind,
        'price': float(price),
        'timestamp': df_k.iloc[i]['timestamp'],
        'strength': float(strength),
        'is_valid': True,
        'center_high': float(df_k.iloc[i]['high']),
        'center_low':  float(df_k.iloc[i]['low']),
        'left_idx': int(L),
        'right_idx': int(R),
        'orig_start': o_s,
        'orig_end': o_e,
    }


def _dedup_same_type_run(fr):
    if fr.empty: return fr
    keep_idx = []
    i = 0
    while i < len(fr):
        j = i + 1
        t = fr.iloc[i]['type']
        while j < len(fr) and fr.iloc[j]['type'] == t:
            j += 1
        block = fr.iloc[i:j]
        if t == 'top':
            kpos = block['center_high'].values.argmax()
        else:
            kpos = block['center_low'].values.argmin()
        keep_idx.append(block.index[kpos])
        i = j
    return fr.loc[keep_idx].sort_index().reset_index(drop=True)


def _validate_fractals(fr):
    if len(fr) < 2:
        return fr
    fr = fr.sort_values('idx').reset_index(drop=True).copy()
    valid = np.ones(len(fr), dtype=bool)
    for i, j in zip(range(len(fr) - 1), range(1, len(fr))):
        a, b = fr.iloc[i], fr.iloc[j]
        if a['type'] == 'top' and b['type'] == 'bottom' and not (a['price'] > b['price']):
            valid[i] = valid[j] = False
        elif a['type'] == 'bottom' and b['type'] == 'top' and not (a['price'] < b['price']):
            valid[i] = valid[j] = False
    fr['is_valid'] = valid
    return fr


def _calc_atr(df, n):
    h, l, c = df['high'].to_numpy(), df['low'].to_numpy(), df['close'].to_numpy()
    prev_c = np.r_[c[0], c[:-1]]
    tr = np.maximum.reduce([h - l, np.abs(h - prev_c), np.abs(l - prev_c)])
    return pd.Series(tr).rolling(n, min_periods=1).mean().to_numpy()


def _assert_schema(df):
    miss = [c for c in REQ if c not in df.columns]
    if miss:
        raise ValueError(f"missing columns: {miss}")


def _empty_fractals_df():
    return pd.DataFrame(columns=[
        'idx','type','price','timestamp','strength','is_valid',
        'center_high','center_low','left_idx','right_idx','orig_start','orig_end'
    ])
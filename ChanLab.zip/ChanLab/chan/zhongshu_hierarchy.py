# chan/zhongshu_hierarchy.py
from __future__ import annotations
from typing import List, Dict, Optional, Any
import math
from typing import List, Dict, Optional, Tuple
import numpy as np
import pandas as pd


import chan.chan_zhongshu as cz



# A)
UP_PARAMS_DISCOVERY = dict(
    level="segment",
    require_alt_dir=False,
    leave_confirm=0,
    allow_overlap_zs=True,
    enable_quality=False,
)
UP_ENH_DISCOVERY = dict(
    strict_alternating_direction=False,
    min_zs_width_ratio=0.0005,   # 0.05%
    max_extension_units=80,
    confirm_third_point=False,
    tp_pullback_max_units=3, tp_continuation_max_units=3,
    tp_buffer_ratio=0.15, tp_use_atr_band=False, tp_atr_k=0.0,
    zs_adj_abs_tol=1e-6, zs_adj_rel_tol=5e-4, zs_adj_k_atr=0.25,
)

# B)
UP_PARAMS_CLEAN = dict(
    level="segment",
    require_alt_dir=False,
    leave_confirm=0,
    allow_overlap_zs=False,
    enable_quality=True,
)
UP_ENH_CLEAN = dict(
    strict_alternating_direction=False,
    min_zs_width_ratio=0.0010,   # 0.10%
    max_extension_units=50,
    confirm_third_point=False,
    tp_pullback_max_units=3, tp_continuation_max_units=3,
    tp_buffer_ratio=0.15, tp_use_atr_band=False, tp_atr_k=0.0,
    zs_adj_abs_tol=1e-6, zs_adj_rel_tol=5e-4, zs_adj_k_atr=0.25,
)



def _normalize_tz(df: pd.DataFrame,
                  cols: Tuple[str, str] = ("timestamp_start", "timestamp_end")) -> pd.DataFrame:
    for c in cols:
        df[c] = pd.to_datetime(df[c], errors="coerce", utc=True).dt.tz_convert("UTC").dt.tz_localize(None)
    return df

def _infer_direction_from_mid(z: pd.DataFrame) -> np.ndarray:
    mids = 0.5 * (z["zs_low"].astype(float).values + z["zs_high"].astype(float).values)
    d = z.get("leave_dir", pd.Series([0] * len(z))).fillna(0).astype(int).values
    n = len(z)
    for i in range(n):
        if d[i] != 0:
            continue
        prev_mid = mids[i - 1] if i > 0 else np.nan
        next_mid = mids[i + 1] if i < n - 1 else np.nan
        if not np.isnan(next_mid) and next_mid != mids[i]:
            d[i] = 1 if next_mid > mids[i] else -1
        elif not np.isnan(prev_mid) and prev_mid != mids[i]:
            d[i] = 1 if mids[i] > prev_mid else -1
        else:
            d[i] = 0
    return d

def _zs_to_pseudo_segments(zs_df: pd.DataFrame, merge_same_dir: bool = True) -> pd.DataFrame:
    cols = ["segment_index", "low", "high", "direction",
            "start_idx", "end_idx", "timestamp_start", "timestamp_end"]
    if zs_df is None or zs_df.empty:
        return pd.DataFrame(columns=cols)

    z = zs_df.sort_values("timestamp_start").reset_index(drop=True).copy()
    d = _infer_direction_from_mid(z)
    z["__dir"] = d
    z = z[z["__dir"] != 0].reset_index(drop=True)
    if z.empty:
        return pd.DataFrame(columns=cols)

    if merge_same_dir:
        comp, cur = [], None
        for _, r in z.iterrows():
            if cur is None or r["__dir"] != cur["__dir"]:
                if cur is not None:
                    comp.append(cur)
                cur = r.copy()
            else:
                cur["timestamp_end"] = max(cur["timestamp_end"], r["timestamp_end"])
                cur["zs_low"] = min(float(cur["zs_low"]), float(r["zs_low"]))
                cur["zs_high"] = max(float(cur["zs_high"]), float(r["zs_high"]))
        if cur is not None:
            comp.append(cur)
        C = pd.DataFrame(comp).reset_index(drop=True)
    else:
        C = z.reset_index(drop=True)

    C["segment_index"] = np.arange(len(C), dtype=int)
    C["direction"] = np.where(C["__dir"] > 0, "up", "down")

    return pd.DataFrame(dict(
        segment_index=C["segment_index"],
        low=C["zs_low"].astype(float).values,
        high=C["zs_high"].astype(float).values,
        direction=C["direction"].values,
        start_idx=C.get("start_unit_index", pd.Series([0] * len(C))).fillna(0).astype(int).values,
        end_idx=C.get("end_unit_index", pd.Series([0] * len(C))).fillna(0).astype(int).values,
        timestamp_start=C["timestamp_start"],
        timestamp_end=C["timestamp_end"],
    ))

def _select_non_overlap(df: pd.DataFrame,
                        ts: str = "timestamp_start",
                        te: str = "timestamp_end") -> pd.DataFrame:
    if df is None or df.empty:
        return df.copy()
    z = df.sort_values(te).reset_index(drop=True)
    keep, last_end = [], pd.Timestamp.min
    for _, r in z.iterrows():
        st, ed = r[ts], r[te]
        if st >= last_end:
            keep.append(r)
            last_end = ed
    out = pd.DataFrame(keep).reset_index(drop=True)
    if "zs_index" not in out.columns:
        out["zs_index"] = np.arange(len(out), dtype=int)
    return out

def _time_iou(a0: pd.Timestamp, a1: pd.Timestamp,
              b0: pd.Timestamp, b1: pd.Timestamp) -> float:
    inter = max(0.0, (min(a1, b1) - max(a0, b0)).total_seconds())
    union = max(0.0, (max(a1, b1) - min(a0, b0)).total_seconds())
    return inter / union if union > 0 else 0.0


def _elevate(prev_level: pd.DataFrame,
             up_params: dict,
             up_enh: dict,
             non_overlap: bool,
             merge_same_dir: bool,
             parent_map: str,
             iou_thresh: float) -> Tuple[pd.DataFrame, Dict[int, Optional[int]]]:
    prev = prev_level.sort_values("timestamp_start").reset_index(drop=True).copy()

    pseudo_seg = _zs_to_pseudo_segments(prev, merge_same_dir=merge_same_dir)
    if pseudo_seg.empty or len(pseudo_seg) < 3:
        return pd.DataFrame(columns=prev.columns), {}

    Z = cz.detect_zhongshu(pseudo_seg, **up_params, enhancements=up_enh) \
        .sort_values("timestamp_start").reset_index(drop=True)
    if Z.empty:
        return Z, {}

    if "zs_index" not in Z.columns:
        Z["zs_index"] = np.arange(len(Z), dtype=int)

    if non_overlap:
        Z = _select_non_overlap(Z)

    pmap: Dict[int, Optional[int]] = {}
    if parent_map == "contain":
        for _, c in prev.iterrows():
            ct0, ct1 = c["timestamp_start"], c["timestamp_end"]
            pid = None
            for _, p in Z.iterrows():
                pt0, pt1 = p["timestamp_start"], p["timestamp_end"]
                if (pt0 <= ct0) and (ct1 <= pt1):
                    pid = int(p["zs_index"])
                    break
            pmap[int(c.get("zs_index", _))] = pid
    else:  # IoU
        for _, c in prev.iterrows():
            ct0, ct1 = c["timestamp_start"], c["timestamp_end"]
            best_iou, best_pid = 0.0, None
            for _, p in Z.iterrows():
                pt0, pt1 = p["timestamp_start"], p["timestamp_end"]
                i = _time_iou(ct0, ct1, pt0, pt1)
                if i > best_iou:
                    best_iou, best_pid = i, int(p["zs_index"])
            pmap[int(c.get("zs_index", _))] = best_pid if best_iou >= iou_thresh else None

    return Z, pmap

def build_zhongshu_hierarchy(
    l1_df: pd.DataFrame,
    max_levels: int = 3,
    mode: str = "discovery",         # "discovery" | "clean"
    min_ratio: Optional[float] = None,
    allow_overlap_zs: Optional[bool] = None,
    enable_quality: Optional[bool] = None,
    strict_alt: Optional[bool] = None,
    non_overlap: Optional[bool] = None,
    merge_same_dir: Optional[bool] = None,
    parent_map: Optional[str] = None,  # "contain" | "iou"
    iou_thresh: float = 0.5,
    normalize_time: bool = True,
) -> Tuple[List[pd.DataFrame], List[Dict[int, Optional[int]]]]:

    assert mode in ("discovery", "clean")
    if mode == "clean":
        up_params = UP_PARAMS_CLEAN.copy()
        up_enh = UP_ENH_CLEAN.copy()
        _non_overlap = True
        _merge = True
        _pmap = "iou"
    else:
        up_params = UP_PARAMS_DISCOVERY.copy()
        up_enh = UP_ENH_DISCOVERY.copy()
        _non_overlap = False
        _merge = True
        _pmap = "contain"

    if min_ratio is not None:
        up_enh["min_zs_width_ratio"] = float(min_ratio)
    if allow_overlap_zs is not None:
        up_params["allow_overlap_zs"] = bool(allow_overlap_zs)
    if enable_quality is not None:
        up_params["enable_quality"] = bool(enable_quality)
    if strict_alt is not None:
        up_params["require_alt_dir"] = bool(strict_alt)
        up_enh["strict_alternating_direction"] = bool(strict_alt)
    if non_overlap is not None:
        _non_overlap = bool(non_overlap)
    if merge_same_dir is not None:
        _merge = bool(merge_same_dir)
    if parent_map is not None:
        assert parent_map in ("contain", "iou")
        _pmap = parent_map


    L1 = l1_df.copy()
    if normalize_time:
        L1 = _normalize_tz(L1)
    L1 = L1.sort_values("timestamp_start").reset_index(drop=True)
    if "zs_index" not in L1.columns:
        L1["zs_index"] = np.arange(len(L1), dtype=int)
    if _non_overlap and not L1.empty:
        L1 = _select_non_overlap(L1)

    levels: List[pd.DataFrame] = [L1]
    parent_maps: List[Dict[int, Optional[int]]] = []

    cur = L1
    for lev in range(2, max_levels + 1):
        Z, pmap = _elevate(cur, up_params, up_enh, _non_overlap, _merge, _pmap, iou_thresh)
        if Z.empty:
            break
        levels.append(Z)
        parent_maps.append(pmap)
        cur = Z

    return levels, parent_maps



def _overlap_ratio(df: pd.DataFrame) -> float:
    if df is None or df.empty:
        return 0.0
    t = df.sort_values("timestamp_start").reset_index(drop=True)
    cnt = sum(t.loc[i + 1, "timestamp_start"] < t.loc[i, "timestamp_end"] for i in range(len(t) - 1))
    return cnt / max(1, len(t) - 1)

def summarize_hierarchy(
    levels: List[pd.DataFrame],
    parent_maps: List[Dict[int, Optional[int]]],
    title: str = "Zhongshu Hierarchy Summary",
    verbose: bool = False,
) -> Dict[str, Any]:

    summary: Dict[str, Any] = {
        "title": title,
        "levels": [],
        "links": [],
    }

    for k, df in enumerate(levels, 1):
        layer_info: Dict[str, Any] = {
            "level_index": k,
            "count": 0,
            "width_median": None,
            "time_overlap": None,
            "grade_dist": {},
        }
        if df is None or df.empty:
            summary["levels"].append(layer_info)
            if verbose:
                print(f"L{k}: 0")
            continue

        layer_info["count"] = int(len(df))

        if {"zs_high", "zs_low"}.issubset(df.columns) and len(df) > 0:
            width = (df["zs_high"] - df["zs_low"]).div(
                (df["zs_high"] + df["zs_low"]) / 2
            ).median()
            layer_info["width_median"] = float(width)


        try:
            ovlp = _overlap_ratio(df)
            layer_info["time_overlap"] = float(ovlp)
        except Exception:
            layer_info["time_overlap"] = None


        if "chan_grade" in df.columns:
            layer_info["grade_dist"] = df["chan_grade"].value_counts().to_dict()
        elif "quality_grade" in df.columns:
            layer_info["grade_dist"] = df["quality_grade"].value_counts().to_dict()

        summary["levels"].append(layer_info)

        if verbose:
            gm = layer_info["width_median"]
            ov = layer_info["time_overlap"]
            gdict = layer_info["grade_dist"]
            gm_str = f"{gm:.4%}" if gm is not None else "NA"
            ov_str = f"{ov:.1%}" if ov is not None else "NA"
            print(f"L{k}: n={layer_info['count']} | width_median={gm_str} | time_overlap={ov_str} | grades={gdict}")

    for i, p in enumerate(parent_maps, 1):
        link_info: Dict[str, Any] = {
            "from_level": i,
            "to_level": i + 1,
            "parents_count": 0,
            "orphans_count": 0,
            "empty": True,
        }
        if not p:
            summary["links"].append(link_info)
            if verbose:
                print(f"L{i}→L{i+1}: (empty)")
            continue

        parents = {v for v in p.values() if v is not None}
        orphans = list(p.values()).count(None)

        link_info["parents_count"] = int(len(parents))
        link_info["orphans_count"] = int(orphans)
        link_info["empty"] = False

        summary["links"].append(link_info)

        if verbose:
            print(f"L{i}→L{i+1}: parents={link_info['parents_count']}, orphans={link_info['orphans_count']}")

    if verbose:
        print(f"\n=== {summary['title']} ===")

    return summary


def score_combo(L1: pd.DataFrame,
                L2: pd.DataFrame,
                parents_map: Optional[Dict[int, Optional[int]]] = None,
                w_overlap: float = 0.6,
                w_orphan: float = 0.4,
                w_width: float = 0.2) -> float:

    n2 = len(L2)
    if n2 == 0:
        return -1.0
    overlap = _overlap_ratio(L2)
    width = ((L2["zs_high"] - L2["zs_low"]) / ((L2["zs_high"] + L2["zs_low"]) / 2)).median()
    attach = 0.0
    if parents_map:
        attached = sum(1 for v in parents_map.values() if v is not None)
        attach = attached / max(1, len(parents_map))
    orphan = 1 - attach
    width_norm = math.log1p(max(width, 0.0))
    return (n2
            - w_overlap * overlap * n2
            - w_orphan * orphan * n2
            + w_width * width_norm)

# -*- coding: utf-8 -*-
"""
chan_zhongshu.py — Zhongshu Detection · Final Version
- Multi-level: support base_level × K to automatically aggregate to the target level; or directly use a higher cycle segment
- Departure confirmation: the third type of buying and selling point style (configurable), including dynamic buffer & class ATR band
- Relationship classification: adjacent/extended/independent (adaptive threshold)
"""

from __future__ import annotations
from typing import Dict, Any, List, Optional, Tuple, Literal
import numpy as np
import pandas as pd

Level = Literal["bi", "segment"]
EPS = 1e-12


def detect_zhongshu(
    df: pd.DataFrame,
    *,
    level: Level = "segment",
    require_alt_dir: Optional[bool] = None,   # None=enhancements['strict_alternating_direction']
    min_hits: int = 3,
    leave_confirm: int = 1,
    allow_overlap_zs: bool = True,
    enable_quality: bool = True,
    enhancements: Optional[Dict[str, Any]] = None,
) -> pd.DataFrame:

    enh = _default_enhancements()
    if enhancements:
        enh.update(enhancements)

    use_alt = require_alt_dir if (require_alt_dir is not None) else bool(enh["strict_alternating_direction"])

    units = _normalize_units(df, level)
    if len(units) < 3:
        return _format_cols(_empty_zs_df())

    zs_list: List[Dict[str, Any]] = []
    i = 0
    n = len(units)

    while i <= n - 3:
        u0, u1, u2 = units[i], units[i + 1], units[i + 2]

        if use_alt:
            if not (_alt(u0["dir"], u1["dir"]) and _alt(u1["dir"], u2["dir"])):
                i += 1
                continue

        low0 = max(u0["low"], u1["low"], u2["low"])
        high0 = min(u0["high"], u1["high"], u2["high"])
        if high0 <= low0 + EPS:
            i += 1
            continue

        zs = _init_zs(level, [u0, u1, u2], low0, high0)
        zs["_w_init"] = float(high0 - low0)
        pos_start = i
        pos_end = i + 2
        j = i + 3
        ext_cnt = 0

        while j < n:
            uj = units[j]

            if enh["max_extension_units"] is not None and ext_cnt >= int(enh["max_extension_units"]):
                break

            if _intersects((zs["zs_low"], zs["zs_high"]), (uj["low"], uj["high"])):
                zs["zs_low"] = max(zs["zs_low"], uj["low"])
                zs["zs_high"] = min(zs["zs_high"], uj["high"])
                zs["zs_mid"] = 0.5 * (zs["zs_low"] + zs["zs_high"])
                zs["hits"] += 1
                zs["end_unit_index"] = uj["idx"]
                zs["end_idx"] = uj["end_idx"]
                zs["timestamp_end"] = uj["t_end"]
                pos_end = j
                ext_cnt += 1
                j += 1
            else:
                leave_dir = 1 if uj["low"] > zs["zs_high"] else -1
                if _confirm_leave_direction(zs, units, j, leave_dir, leave_confirm, enh):
                    zs["leave_dir"] = leave_dir
                    zs["leave_unit_index"] = uj["idx"]
                    zs["leave_timestamp"] = uj["t_start"]
                    if leave_dir == 1:
                        zs["leave_distance"] = (uj["low"] - zs["zs_high"]) / max(EPS, zs["zs_mid"])
                    else:
                        zs["leave_distance"] = (zs["zs_low"] - uj["high"]) / max(EPS, zs["zs_mid"])
                    break
                else:
                    j += 1

        _finalize_zs(zs)
        zs["unit_pos_start"] = pos_start
        zs["unit_pos_end"] = pos_end

        if zs["zs_width_rel"] < float(enh["min_zs_width_ratio"]):
            i += 1
            continue

        if zs["hits"] >= max(3, int(min_hits)):
            zs_list.append(zs)

        i = (j - 2) if allow_overlap_zs else max(i + 1, j - 1)

    res = pd.DataFrame(zs_list) if zs_list else _empty_zs_df()
    if res.empty:
        return _format_cols(res)

    unit_rng_med = np.median([u["high"] - u["low"] for u in units]) if len(units) else 0.0
    rel = []
    for k in range(len(res)):
        if k == 0:
            rel.append("root")
        else:
            prev = res.iloc[k - 1]
            curr = res.iloc[k]
            rel.append(_classify_zs_relationship(
                (prev["zs_low"], prev["zs_high"]),
                (curr["zs_low"], curr["zs_high"]),
                enh=enh,
                unit_range_median=unit_rng_med
            ))
    res["relation_to_prev"] = rel

    if enable_quality:
        res = _score_zs(res)
        res = _score_zs_enhanced(res, units)

    return _format_cols(res)


def detect_zhongshu_by_level(
    dfs_by_interval: Dict[str, pd.DataFrame],
    *,
    base_level: str,              # '5m' / '15m' / '30m' / '1h' / '4h' ...
    level_relation: int = 3,
    level: Level = "segment",
    prefer_target_interval: bool = True,
    detect_kwargs: Optional[Dict[str, Any]] = None,
) -> Tuple[str, pd.DataFrame]:

    detect_kwargs = detect_kwargs or {}
    tgt = _infer_target_tf(base_level, level_relation)
    if prefer_target_interval and tgt in dfs_by_interval:
        df_tgt = dfs_by_interval[tgt]
        zs = detect_zhongshu(df_tgt, level=level, **detect_kwargs)
        return tgt, zs

    if base_level not in dfs_by_interval:
        raise ValueError(f"base_level '{base_level}' not in dfs_by_interval")

    df_base = dfs_by_interval[base_level]
    agg = _aggregate_units_by_relation(df_base, level=level, K=level_relation)
    zs = detect_zhongshu(agg, level=level, **detect_kwargs)
    return f"{base_level}x{level_relation}", zs


def _default_enhancements() -> Dict[str, Any]:
    return dict(
        strict_alternating_direction=True,
        min_zs_width_ratio=0.005,
        max_extension_units=20,


        confirm_third_point=True,
        tp_pullback_max_units=3,
        tp_continuation_max_units=3,
        tp_buffer_ratio=0.15,
        tp_use_atr_band=True,
        tp_atr_k=0.5,

        zs_adj_abs_tol=1e-6,
        zs_adj_rel_tol=5e-4,
        zs_adj_k_atr=0.25,
    )


def _normalize_units(df: pd.DataFrame, level: Level) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    if level == "bi":
        need = ["bi_index", "low", "high", "dir", "start_idx", "end_idx", "timestamp_start", "timestamp_end"]
        _check_cols(df, need)
        it = df.sort_values("bi_index").itertuples(index=False)
        for r in it:
            out.append({
                "idx": int(getattr(r, "bi_index")),
                "low": float(getattr(r, "low")),
                "high": float(getattr(r, "high")),
                "dir": int(getattr(r, "dir")),  # 1/-1
                "start_idx": int(getattr(r, "start_idx")),
                "end_idx": int(getattr(r, "end_idx")),
                "t_start": getattr(r, "timestamp_start"),
                "t_end": getattr(r, "timestamp_end"),
            })
    else:  # segment
        need = ["segment_index", "low", "high", "direction", "start_idx", "end_idx", "timestamp_start", "timestamp_end"]
        _check_cols(df, need)
        it = df.sort_values("segment_index").itertuples(index=False)
        for r in it:
            d = getattr(r, "direction")
            dnum = 1 if str(d).lower() == "up" else -1
            out.append({
                "idx": int(getattr(r, "segment_index")),
                "low": float(getattr(r, "low")),
                "high": float(getattr(r, "high")),
                "dir": dnum,
                "start_idx": int(getattr(r, "start_idx")),
                "end_idx": int(getattr(r, "end_idx")),
                "t_start": getattr(r, "timestamp_start"),
                "t_end": getattr(r, "timestamp_end"),
            })
    return out


def _alt(a: int, b: int) -> bool:
    return a * b < 0


def _intersects(a: Tuple[float, float], b: Tuple[float, float]) -> bool:
    low = max(a[0], b[0])
    high = min(a[1], b[1])
    return high > low + EPS


def _init_zs(level: str, first3: List[Dict[str, Any]], low0: float, high0: float) -> Dict[str, Any]:
    s = first3[0]; e = first3[-1]
    return {
        "zs_index": -1,
        "level": level,
        "start_unit_index": s["idx"],
        "end_unit_index": e["idx"],
        "start_idx": s["start_idx"],
        "end_idx": e["end_idx"],
        "timestamp_start": s["t_start"],
        "timestamp_end": e["t_end"],
        "zs_low": float(low0),
        "zs_high": float(high0),
        "zs_mid": 0.5 * (low0 + high0),
        "hits": 3,
        "leave_dir": 0,
        "leave_unit_index": np.nan,
        "leave_timestamp": pd.NaT,
        "leave_distance": 0.0,
        "duration_hours": np.nan,
        "zs_width": float(high0 - low0),
        "zs_width_rel": float(high0 - low0) / max(EPS, 0.5 * (low0 + high0)),
    }


def _finalize_zs(zs: Dict[str, Any]) -> None:
    t0 = pd.to_datetime(zs["timestamp_start"])
    t1 = pd.to_datetime(zs["timestamp_end"])
    zs["duration_hours"] = float((t1 - t0).total_seconds() / 3600.0)
    zs["zs_width"] = float(zs["zs_high"] - zs["zs_low"])
    zs["zs_width_rel"] = zs["zs_width"] / max(EPS, zs["zs_mid"])


def _confirm_leave_direction(
    zs: Dict[str, Any],
    units: List[Dict[str, Any]],
    j: int,
    leave_dir: int,
    confirm_bars: int,
    enh: Dict[str, Any],
) -> bool:

    n = len(units)
    if not enh.get("confirm_third_point", False):
        if confirm_bars <= 0:
            return True
        k_end = min(n, j + confirm_bars)
        for k in range(j, k_end):
            if _intersects((zs["zs_low"], zs["zs_high"]), (units[k]["low"], units[k]["high"])):
                return False
        return True

    zs_width = float(zs["zs_high"] - zs["zs_low"])
    buffer = float(enh.get("tp_buffer_ratio", 0.15)) * zs_width
    if enh.get("tp_use_atr_band", True):
        med_rng = np.median([u["high"] - u["low"] for u in units[max(0, j - 10):j + 1]]) if n else 0.0
        buffer += float(enh.get("tp_atr_k", 0.5)) * med_rng

    pb_win = int(enh.get("tp_pullback_max_units", 3))
    ct_win = int(enh.get("tp_continuation_max_units", 3))

    leave_pivot_high = units[j]["high"]
    leave_pivot_low = units[j]["low"]

    pb_start = None
    for k in range(j + 1, min(n, j + 1 + pb_win)):
        uk = units[k]

        if _intersects((zs["zs_low"], zs["zs_high"]), (uk["low"], uk["high"])):
            return False
        if leave_dir == 1:
            if uk["low"] <= zs["zs_high"] - buffer:
                pb_start = k
                break
        else:
            if uk["high"] >= zs["zs_low"] + buffer:
                pb_start = k
                break

    if pb_start is None:
        return False

    for k in range(pb_start + 1, min(n, pb_start + 1 + ct_win)):
        uk = units[k]
        if _intersects((zs["zs_low"], zs["zs_high"]), (uk["low"], uk["high"])):
            return False
        if leave_dir == 1:
            if uk["high"] > leave_pivot_high:
                seq = [units[t]["low"] for t in range(pb_start, k + 1)]
                if all(seq[t] >= seq[t - 1] - 1e-12 for t in range(1, len(seq))):
                    return True
        else:
            if uk["low"] < leave_pivot_low:
                seq = [units[t]["high"] for t in range(pb_start, k + 1)]
                if all(seq[t] <= seq[t - 1] + 1e-12 for t in range(1, len(seq))):
                    return True
    return False


def _classify_zs_relationship(
    prev: Tuple[float, float],
    curr: Tuple[float, float],
    *,
    enh: Dict[str, Any],
    unit_range_median: float
) -> str:

    a_low, a_high = prev; b_low, b_high = curr
    if _intersects((a_low, a_high), (b_low, b_high)):
        return "expansion"


    mid_a = 0.5 * (a_low + a_high)
    mid_b = 0.5 * (b_low + b_high)
    mid = 0.5 * (mid_a + mid_b)

    abs_tol = float(enh.get("zs_adj_abs_tol", 1e-6))
    rel_tol = float(enh.get("zs_adj_rel_tol", 5e-4)) * max(mid, 1e-12)
    atr_tol = float(enh.get("zs_adj_k_atr", 0.25)) * float(unit_range_median)
    tol = max(abs_tol, rel_tol, atr_tol)

    gap = min(abs(a_high - b_low), abs(b_high - a_low))
    if gap <= tol:
        return "adjacent"
    return "separate"



def _score_zs(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return df
    res = df.copy()
    w = {"tightness": 0.45, "duration": 0.30, "hits": 0.25}

    tight = 1.0 / res["zs_width_rel"].replace(0, np.nan)
    tight = tight / tight.max() if np.isfinite(getattr(tight, "max")()) else 0.0

    dur_max = res["duration_hours"].max() if "duration_hours" in res else 0
    dur = res["duration_hours"] / dur_max if dur_max else 0.0

    hits_max = res["hits"].max() if "hits" in res else 0
    hts = res["hits"] / hits_max if hits_max else 0.0

    res["tightness_strength"] = tight
    res["duration_strength"] = dur
    res["hits_strength"] = hts
    res["overall_strength"] = (w["tightness"] * tight + w["duration"] * dur + w["hits"] * hts).astype(float)

    res["quality_grade"] = "C"
    res.loc[res["overall_strength"] >= 0.6, "quality_grade"] = "B"
    res.loc[res["overall_strength"] >= 0.8, "quality_grade"] = "A"
    return res


def _score_zs_enhanced(df: pd.DataFrame, units: List[Dict[str, Any]]) -> pd.DataFrame:

    if df.empty:
        return df
    res = df.copy()

    alt_ratio, density, ext_quality = [], [], []

    for _, z in res.iterrows():
        s = int(z.get("unit_pos_start", -1))
        e = int(z.get("unit_pos_end", -1))
        if 0 <= s < len(units) and 0 <= e < len(units) and e > s:
            dirs = [units[k]["dir"] for k in range(s, e + 1)]
            pairs = len(dirs) - 1
            alt = sum(1 for t in range(1, len(dirs)) if dirs[t] * dirs[t - 1] < 0)
            alt_ratio.append(alt / pairs if pairs > 0 else 1.0)
        else:
            alt_ratio.append(np.nan)

        dur = float(z.get("duration_hours", np.nan))
        hts = float(z.get("hits", np.nan))
        density.append((hts / dur) if (dur and dur > 0) else np.nan)

        w0 = float(z.get("_w_init", np.nan))
        wf = float(z.get("zs_width", np.nan))
        ext_quality.append((w0 - wf) / w0 if (w0 and w0 > 0) else np.nan)

    res["direction_alternation"] = pd.Series(alt_ratio).fillna(0.0)
    res["overlap_density"] = pd.Series(density).fillna(0.0)
    res["extension_quality"] = pd.Series(ext_quality).fillna(0.0)

    def _norm(s: pd.Series):
        s = s.copy()
        mx = np.nanmax(s.values) if len(s) else np.nan
        return (s / mx).fillna(0.0) if (mx and mx > 0) else 0.0

    res["direction_alternation_n"] = _norm(res["direction_alternation"])
    res["overlap_density_n"] = _norm(res["overlap_density"])
    res["extension_quality_n"] = _norm(res["extension_quality"])

    res["chan_quality"] = (
        0.40 * res["tightness_strength"].fillna(0.0) +
        0.30 * res["overlap_density_n"].fillna(0.0) +
        0.20 * res["direction_alternation_n"].fillna(0.0) +
        0.10 * res["extension_quality_n"].fillna(0.0)
    )

    res["chan_grade"] = "C"
    res.loc[res["chan_quality"] >= 0.6, "chan_grade"] = "B"
    res.loc[res["chan_quality"] >= 0.8, "chan_grade"] = "A"
    return res



def _aggregate_units_by_relation(df: pd.DataFrame, *, level: Level, K: int) -> pd.DataFrame:

    if level == "bi":
        need = ["bi_index", "low", "high", "dir", "start_idx", "end_idx", "timestamp_start", "timestamp_end"]
        _check_cols(df, need)
        rows = []
        bi = df.sort_values("bi_index").reset_index(drop=True)
        for g, chunk in enumerate([bi.iloc[i:i + K] for i in range(0, len(bi), K)]):
            if chunk.empty:
                continue
            rng = (chunk["high"] - chunk["low"]).clip(lower=0)
            score = int(np.sign((chunk["dir"] * rng).sum()))  # >0 ↑，<0 ↓，=0 -
            d_last = int(chunk.iloc[-1]["dir"])
            d_major = score if score != 0 else d_last

            rows.append(dict(
                bi_index=g,
                low=float(chunk["low"].min()),
                high=float(chunk["high"].max()),
                dir=d_major,
                start_idx=int(chunk.iloc[0]["start_idx"]),
                end_idx=int(chunk.iloc[-1]["end_idx"]),
                timestamp_start=chunk.iloc[0]["timestamp_start"],
                timestamp_end=chunk.iloc[-1]["timestamp_end"],
            ))
        return pd.DataFrame(rows)

    else:  # segment
        need = ["segment_index", "low", "high", "direction", "start_idx", "end_idx", "timestamp_start", "timestamp_end"]
        _check_cols(df, need)
        rows = []
        seg = df.sort_values("segment_index").reset_index(drop=True)
        for g, chunk in enumerate([seg.iloc[i:i + K] for i in range(0, len(seg), K)]):
            if chunk.empty:
                continue
            dnum = chunk["direction"].map(lambda s: 1 if str(s).lower() == "up" else -1)
            rng = (chunk["high"] - chunk["low"]).clip(lower=0)
            score = int(np.sign((dnum * rng).sum()))
            d_last = 1 if str(chunk.iloc[-1]["direction"]).lower() == "up" else -1
            d_major = score if score != 0 else d_last
            d_str = "up" if d_major == 1 else "down"

            rows.append(dict(
                segment_index=g,
                low=float(chunk["low"].min()),
                high=float(chunk["high"].max()),
                direction=d_str,
                start_idx=int(chunk.iloc[0]["start_idx"]),
                end_idx=int(chunk.iloc[-1]["end_idx"]),
                timestamp_start=chunk.iloc[0]["timestamp_start"],
                timestamp_end=chunk.iloc[-1]["timestamp_end"],
            ))
        return pd.DataFrame(rows)


def _tf_to_minutes(tf: str) -> int:
    tf = tf.strip().lower()
    if tf.endswith("m"):
        return int(tf[:-1])
    if tf.endswith("h"):
        return int(tf[:-1]) * 60
    if tf.endswith("d"):
        return int(tf[:-1]) * 60 * 24
    raise ValueError(f"unsupported timeframe: {tf}")


def _minutes_to_tf(mins: int) -> str:
    if mins % (60 * 24) == 0:
        return f"{mins // (60 * 24)}d"
    if mins % 60 == 0:
        return f"{mins // 60}h"
    return f"{mins}m"


def _infer_target_tf(base: str, K: int) -> str:
    mins = _tf_to_minutes(base)
    return _minutes_to_tf(mins * int(K))


def _check_cols(df: pd.DataFrame, need: List[str]) -> None:
    miss = [c for c in need if c not in df.columns]
    if miss:
        raise ValueError(f"Lack of necessary columns: {miss}")


def _empty_zs_df() -> pd.DataFrame:
    cols = [
        "zs_index", "level",
        "start_unit_index", "end_unit_index",
        "start_idx", "end_idx",
        "timestamp_start", "timestamp_end", "duration_hours",
        "zs_low", "zs_high", "zs_mid", "zs_width", "zs_width_rel",
        "hits",
        "leave_dir", "leave_unit_index", "leave_timestamp", "leave_distance",
        "tightness_strength", "duration_strength", "hits_strength", "overall_strength", "quality_grade",
        "direction_alternation", "overlap_density", "extension_quality",
        "direction_alternation_n", "overlap_density_n", "extension_quality_n",
        "chan_quality", "chan_grade", "relation_to_prev",
        "unit_pos_start", "unit_pos_end", "_w_init",
    ]
    return pd.DataFrame(columns=cols)


def _format_cols(df: pd.DataFrame) -> pd.DataFrame:
    cols = [
        "zs_index", "level",
        "start_unit_index", "end_unit_index",
        "start_idx", "end_idx",
        "timestamp_start", "timestamp_end", "duration_hours",
        "zs_low", "zs_high", "zs_mid", "zs_width", "zs_width_rel",
        "hits",
        "leave_dir", "leave_unit_index", "leave_timestamp", "leave_distance",
        "tightness_strength", "duration_strength", "hits_strength", "overall_strength", "quality_grade",
        "direction_alternation", "overlap_density", "extension_quality",
        "direction_alternation_n", "overlap_density_n", "extension_quality_n",
        "chan_quality", "chan_grade", "relation_to_prev",
        "unit_pos_start", "unit_pos_end", "_w_init",
    ]
    out = df.copy()
    for c in cols:
        if c not in out.columns:
            out[c] = np.nan
    out = out.reset_index(drop=True)
    out["zs_index"] = out.index.astype(int)
    return out[cols]


def analyze_zhongshu(df: pd.DataFrame) -> Dict[str, Any]:
    """中枢总体特征摘要。"""
    if df.empty:
        return {}
    stats = {
        "total_zs": int(len(df)),
        "avg_hits": float(df["hits"].mean()),
        "median_width_rel": float(df["zs_width_rel"].median()),
        "median_duration_h": float(df["duration_hours"].median()),
        "grade_counts": df["quality_grade"].value_counts().to_dict(),
    }
    if "leave_dir" in df.columns:
        stats["leave_up"] = int((df["leave_dir"] == 1).sum())
        stats["leave_down"] = int((df["leave_dir"] == -1).sum())
    return stats


def find_active_zhongshu(df: pd.DataFrame, ts) -> Optional[pd.Series]:
    if df.empty:
        return None
    t = pd.to_datetime(ts)
    hit = df[(pd.to_datetime(df["timestamp_start"]) <= t) & (t <= pd.to_datetime(df["timestamp_end"]))]
    return None if hit.empty else hit.iloc[-1]


def validate_chan_zhongshu(
    zhongshu_df: pd.DataFrame,
    level_name: str = "",
    verbose: bool = False,
) -> Dict[str, Any]:

    summary: Dict[str, Any] = {
        "level": level_name,
        "count": 0,
        "width_mean": None,
        "duration_median_hours": None,
        "grade_dist": {},
        "relation_dist": {},
    }

    if zhongshu_df is None or len(zhongshu_df) == 0:
        if verbose:
            print(f"[{level_name}] 无中枢识别")
        return summary

    summary["count"] = int(len(zhongshu_df))

    if "zs_width_rel" in zhongshu_df.columns and len(zhongshu_df["zs_width_rel"]) > 0:
        summary["width_mean"] = float(zhongshu_df["zs_width_rel"].mean())

    if "duration_hours" in zhongshu_df.columns and len(zhongshu_df["duration_hours"]) > 0:
        summary["duration_median_hours"] = float(zhongshu_df["duration_hours"].median())

    if "chan_grade" in zhongshu_df.columns:
        summary["grade_dist"] = zhongshu_df["chan_grade"].value_counts().to_dict()

    if "relation_to_prev" in zhongshu_df.columns:
        summary["relation_dist"] = zhongshu_df["relation_to_prev"].value_counts().to_dict()

    if verbose:
        print(f"\n[{level_name}] zhongshu Quality Report:")
        print(f"Quantity: {summary['count']}")
        if summary["width_mean"] is not None:
            print(f"Average width: {summary['width_mean']:.4f}")
        if summary["duration_median_hours"] is not None:
            print(f"Medin duration: {summary['duration_median_hours']:.1f}h")
        if summary["grade_dist"]:
            print(f"chan distribution: {summary['grade_dist']}")
        if summary["relation_dist"]:
            print(f"zhongshu relationship: {summary['relation_dist']}")

    return summary

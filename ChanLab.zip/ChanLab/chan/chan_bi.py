# -*- coding: utf-8 -*-
"""
chan_bi.py — Entanglement Pen Identification
Key points of characteristics
- Adjacent heterogeneous types are divided into pens, supporting the minimum span (min_bars) and the minimum amplitude (min_dp, supporting relative/absolute)
- Breakthrough verification (enable_breakthrough=True): The same direction needs to reach a new high/new low, and the opposite direction needs to break through the starting point of the previous pen.
- ATR filtering (optional): eliminate "too small pens" with fluctuation adaptation
- Linear O(n), pure function and type annotation are complete
- Quality marking (optional): simple A/B/C grading, does not interfere with core logic
- Align the output field with the columns of upstream fractal.detect_fractals (including orig_* pass-through)
Dependent on input
- fractals_df (from detect_fractals): at least include
['Idx','type','price','timestamp','is_valid'], if there is 'orig_start', 'orig_end' will also be transmitted
- df_k: remove the K line after inclusion, at least include
['Timestamp','open','high','low','close','volume']
"""

from __future__ import annotations
from typing import Dict, Any, Optional, List, Tuple
import numpy as np
import pandas as pd

REQ_FRACTAL = ['idx', 'type', 'price', 'timestamp', 'is_valid']
REQ_K = ['timestamp', 'open', 'high', 'low', 'close', 'volume']

DEFAULT_MIN_BARS = 4
DEFAULT_MIN_DP = 0.01
DEFAULT_USE_RELATIVE_DP = True
DEFAULT_ENABLE_BREAKTHROUGH = True
DEFAULT_USE_ATR_FILTER = True
DEFAULT_ATR_WINDOW = 14
DEFAULT_MIN_ATR_RATIO = 0.8
DEFAULT_ENABLE_VALIDATION = True
DEFAULT_ENABLE_QUALITY = False

def detect_bi(
    fractals_df: pd.DataFrame,
    df_k: pd.DataFrame,
    *,
    min_bars: int = DEFAULT_MIN_BARS,
    min_dp: float = DEFAULT_MIN_DP,
    use_relative_dp: bool = DEFAULT_USE_RELATIVE_DP,
    enable_breakthrough: bool = DEFAULT_ENABLE_BREAKTHROUGH,
    use_atr_filter: bool = DEFAULT_USE_ATR_FILTER,
    atr_window: int = DEFAULT_ATR_WINDOW,
    min_atr_ratio: float = DEFAULT_MIN_ATR_RATIO,
    enable_validation: bool = DEFAULT_ENABLE_VALIDATION,
    enable_quality_markers: bool = DEFAULT_ENABLE_QUALITY
) -> pd.DataFrame:

    _validate_inputs(fractals_df, df_k)

    fr = _preprocess_fractals(fractals_df)
    kdf = df_k.sort_values('timestamp').reset_index(drop=True)

    if len(fr) < 2:
        return _create_empty_bi_df()

    atr = _calculate_atr(kdf, atr_window) if use_atr_filter else None

    bi_list = _build_bi_sequence(
        fr, kdf,
        min_bars=min_bars,
        min_dp=min_dp,
        use_relative_dp=use_relative_dp,
        enable_breakthrough=enable_breakthrough,
        atr=atr,
        min_atr_ratio=min_atr_ratio
    )

    if not bi_list:
        return _create_empty_bi_df()

    result = pd.DataFrame(bi_list)
    result['bi_index'] = range(len(result))

    if enable_validation:
        result = _validate_bi_sequence(result)

    if enable_quality_markers:
        result = _add_quality_markers(result)

    return _format_output(result)


def analyze_bi_characteristics(bi_df: pd.DataFrame) -> Dict[str, Any]:
    if bi_df.empty:
        return {}
    up_bi = bi_df[bi_df['dir'] == 1]
    down_bi = bi_df[bi_df['dir'] == -1]

    stats: Dict[str, Any] = {
        'total_bi': len(bi_df),
        'up_bi': len(up_bi),
        'down_bi': len(down_bi),
        'up_down_ratio': len(up_bi) / max(1, len(down_bi)),
        'avg_strength': float(bi_df['strength'].mean()),
        'avg_span': float(bi_df['k_bars_span'].mean()),
        'max_strength': float(bi_df['strength'].max()),
        'min_strength': float(bi_df['strength'].min()),
    }
    if 'quality_grade' in bi_df.columns:
        q = bi_df['quality_grade'].value_counts().to_dict()
        stats.update({
            'quality_a': q.get('A', 0),
            'quality_b': q.get('B', 0),
            'quality_c': q.get('C', 0),
            'avg_quality_score': float(bi_df.get('quality_score', 0).mean())
        })
    return stats


def filter_quality_bi(bi_df: pd.DataFrame, min_quality: str = 'B') -> pd.DataFrame:
    """Filter bi by quality level (A/B/C), keep B and above by default"""
    if bi_df.empty or 'quality_grade' not in bi_df.columns:
        return bi_df
    order = {'A': 3, 'B': 2, 'C': 1}
    threshold = order.get(min_quality, 2)
    mask = bi_df['quality_grade'].map(order) >= threshold
    return bi_df[mask].reset_index(drop=True)


def find_bi_at_time(bi_df: pd.DataFrame, timestamp: pd.Timestamp) -> Optional[pd.Series]:
    """Find the active bi at the specified time"""
    if bi_df.empty:
        return None
    ts = pd.to_datetime(timestamp)
    for _, bi in bi_df.iterrows():
        if pd.to_datetime(bi['timestamp_start']) <= ts <= pd.to_datetime(bi['timestamp_end']):
            return bi
    return None


def _build_bi_sequence(
    fr: pd.DataFrame,
    kdf: pd.DataFrame,
    *,
    min_bars: int,
    min_dp: float,
    use_relative_dp: bool,
    enable_breakthrough: bool,
    atr: Optional[np.ndarray],
    min_atr_ratio: float
) -> List[Dict[str, Any]]:
    bi_list: List[Dict[str, Any]] = []
    i, n = 0, len(fr)

    while i < n - 1:
        a = fr.iloc[i]
        j = i + 1
        while j < n and fr.iloc[j]['type'] == a['type']:
            j += 1
        if j >= n:
            break
        b = fr.iloc[j]
        ok_pair, _ = _check_fractal_pair(a, b)
        if not ok_pair:
            i = j
            continue
        candidate = _create_bi_candidate(a, b, kdf)

        if not _validate_bi_candidate(candidate, min_bars, min_dp, use_relative_dp, atr, min_atr_ratio):
            i = j
            continue

        if enable_breakthrough and bi_list:
            if not _check_breakthrough(bi_list[-1], candidate):
                i = j
                continue

        bi_list.append(candidate)
        i = j

    return bi_list


def _check_fractal_pair(a: pd.Series, b: pd.Series) -> Tuple[bool, int]:
    """Check whether the two types can be written; return (whether it is valid, direction 1/-1/0)"""
    if a['type'] == b['type']:
        return False, 0
    if a['type'] == 'bottom' and b['type'] == 'top':
        return (b['price'] > a['price']), 1
    if a['type'] == 'top' and b['type'] == 'bottom':
        return (b['price'] < a['price']), -1
    return False, 0


def _create_bi_candidate(a: pd.Series, b: pd.Series, kdf: pd.DataFrame) -> Dict[str, Any]:
    start_idx, end_idx = int(a['idx']), int(b['idx'])
    direction = 1 if (a['type'] == 'bottom' and b['type'] == 'top') else -1
    low = float(min(a['price'], b['price']))
    high = float(max(a['price'], b['price']))

    k_span = abs(end_idx - start_idx) + 1
    strength = abs(b['price'] - a['price']) / max(1e-12, a['price'])

    orig_start_range = f"{a.get('orig_start', '')}-{a.get('orig_end', '')}"
    orig_end_range   = f"{b.get('orig_start', '')}-{b.get('orig_end', '')}"

    return {
        'start_idx': start_idx,
        'end_idx': end_idx,
        'start_type': a['type'],
        'end_type': b['type'],
        'start_price': float(a['price']),
        'end_price': float(b['price']),
        'low': low,
        'high': high,
        'dir': direction,
        'strength': float(strength),
        'k_bars_span': int(k_span),
        'timestamp_start': a['timestamp'],
        'timestamp_end': b['timestamp'],
        'orig_start_range': orig_start_range,
        'orig_end_range': orig_end_range,
        'atr_norm_delta': np.nan
    }


def _validate_bi_candidate(
    bi: Dict[str, Any],
    min_bars: int,
    min_dp: float,
    use_relative_dp: bool,
    atr: Optional[np.ndarray],
    min_atr_ratio: float
) -> bool:
    if bi['k_bars_span'] < min_bars:
        return False

    if use_relative_dp:
        if bi['strength'] < min_dp:
            return False
    else:
        if abs(bi['end_price'] - bi['start_price']) < min_dp:
            return False

    if atr is not None and min_atr_ratio > 0:
        s, e = bi['start_idx'], bi['end_idx']
        atr_mean = float(pd.Series(atr[s:e+1]).mean())
        if atr_mean > 1e-12:
            atr_ratio = abs(bi['end_price'] - bi['start_price']) / atr_mean
            bi['atr_norm_delta'] = float(atr_ratio)
            if atr_ratio < min_atr_ratio:
                return False

    return True

def _check_breakthrough(last_bi: Dict[str, Any], new_bi: Dict[str, Any], tol: float = 0.003) -> bool:
    """
    Breakthrough verification:
    - Same direction: allow a small overlap (tolerance tol), and it needs to be slightly new high/new low.
    - Reverse: Just break through near the "midpoint" of the front pen
    """

    # Tolerance threshold (e.g. 0.003 = 0.3%)
    tol_factor = 1 + tol

    if last_bi['dir'] == 1 and new_bi['dir'] == 1:
        return new_bi['end_price'] > last_bi['end_price'] / tol_factor  # 允许0.3%重叠
    if last_bi['dir'] == -1 and new_bi['dir'] == -1:
        return new_bi['end_price'] < last_bi['end_price'] * tol_factor

    mid = (last_bi['start_price'] + last_bi['end_price']) / 2  # 中点参考
    if last_bi['dir'] == 1 and new_bi['dir'] == -1:
        return new_bi['end_price'] < mid
    if last_bi['dir'] == -1 and new_bi['dir'] == 1:
        return new_bi['end_price'] > mid
    return True

def _validate_bi_sequence(bi_df: pd.DataFrame) -> pd.DataFrame:
    if len(bi_df) < 2:
        return bi_df
    keep = [True] * len(bi_df)
    for i in range(1, len(bi_df)):
        prev, curr = bi_df.iloc[i-1], bi_df.iloc[i]
        if prev['dir'] == curr['dir']:
            if curr['dir'] == 1:
                if not (curr['high'] > prev['high'] and curr['low'] >= prev['low']):
                    keep[i] = False
            else:
                if not (curr['low'] < prev['low'] and curr['high'] <= prev['high']):
                    keep[i] = False
    return bi_df[keep].reset_index(drop=True)


def _add_quality_markers(bi_df: pd.DataFrame) -> pd.DataFrame:
    if bi_df.empty:
        return bi_df
    out = bi_df.copy()
    out['quality_score'] = 0.0

    rank_strength = out['strength'].rank(pct=True)
    out['quality_score'] += rank_strength.fillna(0) * 40

    span = out['k_bars_span'].astype(float)
    ideal = span.median()
    denom = float(span.max() - span.min()) if span.max() != span.min() else 1.0
    span_score = 1.0 - (span.sub(ideal).abs() / denom)
    out['quality_score'] += span_score.fillna(0) * 30

    if 'atr_norm_delta' in out.columns and not out['atr_norm_delta'].isna().all():
        rank_atr = out['atr_norm_delta'].rank(pct=True)
        out['quality_score'] += rank_atr.fillna(0) * 30

    out['quality_grade'] = 'C'
    out.loc[out['quality_score'] >= 60, 'quality_grade'] = 'B'
    out.loc[out['quality_score'] >= 80, 'quality_grade'] = 'A'
    return out

def _validate_inputs(fractals_df: pd.DataFrame, df_k: pd.DataFrame) -> None:
    miss_f = [c for c in REQ_FRACTAL if c not in fractals_df.columns]
    miss_k = [c for c in REQ_K if c not in df_k.columns]
    if miss_f:
        raise ValueError(f"The classification data is missing columns.: {miss_f}")
    if miss_k:
        raise ValueError(f"K-line data is missing columns: {miss_k}")
    if len(fractals_df) == 0:
        raise ValueError("The classification data is empty.")
    if len(df_k) == 0:
        raise ValueError("The K-line data is empty.")

def _preprocess_fractals(fractals_df: pd.DataFrame) -> pd.DataFrame:
    fr = fractals_df[fractals_df['is_valid']].copy()
    fr = fr.sort_values('idx').reset_index(drop=True)
    return fr


def _calculate_atr(df: pd.DataFrame, window: int) -> np.ndarray:
    h = df['high'].to_numpy()
    l = df['low'].to_numpy()
    c = df['close'].to_numpy()
    prev_c = np.roll(c, 1); prev_c[0] = c[0]
    tr = np.maximum.reduce([h - l, np.abs(h - prev_c), np.abs(l - prev_c)])
    return pd.Series(tr).rolling(window, min_periods=1).mean().to_numpy()

def _format_output(bi_df: pd.DataFrame) -> pd.DataFrame:
    base = [
        'bi_index', 'start_idx', 'end_idx', 'start_type', 'end_type',
        'start_price', 'end_price', 'low', 'high', 'dir', 'strength',
        'k_bars_span', 'timestamp_start', 'timestamp_end',
        'orig_start_range', 'orig_end_range', 'atr_norm_delta'
    ]
    if 'quality_score' in bi_df.columns:
        base += ['quality_score', 'quality_grade']
    for c in base:
        if c not in bi_df.columns:
            bi_df[c] = np.nan
    return bi_df[base]

def _create_empty_bi_df() -> pd.DataFrame:
    cols = [
        'bi_index', 'start_idx', 'end_idx', 'start_type', 'end_type',
        'start_price', 'end_price', 'low', 'high', 'dir', 'strength',
        'k_bars_span', 'timestamp_start', 'timestamp_end',
        'orig_start_range', 'orig_end_range', 'atr_norm_delta',
        'quality_score', 'quality_grade'
    ]
    return pd.DataFrame(columns=cols)

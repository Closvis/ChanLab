# -*- coding: utf-8 -*-
# chan/signals/merge.py
from __future__ import annotations
from typing import Dict, Any, List, Optional, Tuple
import numpy as np
import pandas as pd


DEFAULT_MERGE_CONFIG: Dict[str, Any] = dict(

    resonance_window_minutes=2,
    zs_band_ratio=0.002,
    # 分数权重
    w_base=1.0,
    w_resonance=0.6,
    w_nesting=0.4,
    w_beichi=0.2,
    base_score_by_tag={"1B": 1.0, "1S": 1.0, "2B": 0.8, "2S": 0.8, "3B": 0.9, "3S": 0.9},
    dedup_same_ts=True,
)

def _tf_to_minutes(tf: str) -> int:
    tf = tf.strip().lower()
    if tf.endswith("m"):
        return int(tf[:-1])
    if tf.endswith("h"):
        return int(tf[:-1]) * 60
    if tf.endswith("d"):
        return int(tf[:-1]) * 60 * 24
    raise ValueError(f"Unrecognized timeframe: {tf}")

def _nearest_upper_tf(base_tf: str, candidates: List[str]) -> Optional[str]:
    bm = _tf_to_minutes(base_tf)
    c = [(tf, _tf_to_minutes(tf)) for tf in candidates if _tf_to_minutes(tf) > bm]
    if not c: return None
    return sorted(c, key=lambda x: x[1])[0][0]

def _nearest_lower_tf(base_tf: str, candidates: List[str]) -> Optional[str]:
    bm = _tf_to_minutes(base_tf)
    c = [(tf, _tf_to_minutes(tf)) for tf in candidates if _tf_to_minutes(tf) < bm]
    if not c: return None
    return sorted(c, key=lambda x: x[1], reverse=True)[0][0]

def _time_window(ts: pd.Timestamp, tf_minutes: int, k: int) -> Tuple[pd.Timestamp, pd.Timestamp]:
    delta = pd.Timedelta(minutes=tf_minutes * k)
    return ts - delta, ts + delta

def _find_upper_zs_context(ts: pd.Timestamp, price: float, upper_zs: pd.DataFrame,
                           band_ratio: float) -> Dict[str, Any]:

    if upper_zs is None or upper_zs.empty:
        return dict(state="none", dist=np.nan, zs_index=None)

    z = upper_zs.copy()
    z["t0"] = pd.to_datetime(z["timestamp_start"])
    z["t1"] = pd.to_datetime(z["timestamp_end"])
    z = z[(z["t0"] <= ts) & (ts <= z["t1"])].sort_values("t0")
    if z.empty:
        return dict(state="none", dist=np.nan, zs_index=None)

    row = z.iloc[-1]
    low, high = float(row["zs_low"]), float(row["zs_high"])
    mid = 0.5 * (low + high)
    band = band_ratio * mid
    if price > high + band:
        return dict(state="above", dist=(price - high)/max(1e-9, mid), zs_index=int(row.get("zs_index", -1)))
    elif price < low - band:
        return dict(state="below", dist=(low - price)/max(1e-9, mid), zs_index=int(row.get("zs_index", -1)))
    else:
        dist = min(high - price, price - low) / max(1e-9, mid)
        return dict(state="inside", dist=float(dist), zs_index=int(row.get("zs_index", -1)))

def _count_resonance(ts: pd.Timestamp, side: str, tag: str, base_tf: str,
                     mmd_by_tf: Dict[str, pd.DataFrame],
                     use_tfs: Optional[List[str]],
                     window_k: int) -> Tuple[int, List[Tuple[str, pd.Timestamp]]]:

    base_mins = _tf_to_minutes(base_tf)
    t0, t1 = _time_window(ts, base_mins, window_k)
    tfs = list(mmd_by_tf.keys()) if use_tfs is None else use_tfs

    hits: List[Tuple[str, pd.Timestamp]] = []
    for tf in tfs:
        df = mmd_by_tf.get(tf)
        if df is None or df.empty:
            continue
        d = df[(df["side"] == side)]
        if d.empty:
            continue
        ds = d[(pd.to_datetime(d["ts"]) >= t0) & (pd.to_datetime(d["ts"]) <= t1)]
        if not ds.empty:
            same = (tf == base_tf) & (pd.to_datetime(ds["ts"]) == ts)
            if same.all():
                continue

            hits.append((tf, pd.to_datetime(ds.iloc[0]["ts"])))
    return len(hits), hits

def generate_trading_signals(
    mmd_by_tf: Dict[str, pd.DataFrame],
    zs_by_tf: Optional[Dict[str, pd.DataFrame]] = None,
    config: Optional[Dict[str, Any]] = None,
) -> pd.DataFrame:

    cfg = dict(DEFAULT_MERGE_CONFIG)
    if config:
        cfg.update(config)

    tfs = sorted(mmd_by_tf.keys(), key=_tf_to_minutes)
    out_rows: List[Dict[str, Any]] = []

    for tf in tfs:
        df = mmd_by_tf.get(tf)
        if df is None or df.empty:
            continue
        tf_minutes = _tf_to_minutes(tf)

        d = df.copy()
        d["ts"] = pd.to_datetime(d["ts"])
        d["score_raw"] = d.get("score", np.nan)

        upper_tf = _nearest_upper_tf(tf, tfs)
        upper_zs = None if zs_by_tf is None else zs_by_tf.get(upper_tf)
        for _, r in d.iterrows():
            ts = pd.to_datetime(r["ts"])
            side = str(r["side"])
            tag  = str(r["tag"])
            price = float(r["price"])

            nesting = _find_upper_zs_context(ts, price, upper_zs, cfg["zs_band_ratio"]) \
                      if upper_tf else dict(state="none", dist=np.nan, zs_index=None)

            resonance_n, resonance_hits = _count_resonance(
                ts, side, tag, tf, mmd_by_tf, use_tfs=tfs, window_k=cfg["resonance_window_minutes"]
            )

            # 打分
            base = cfg["base_score_by_tag"].get(tag, 0.8) * cfg["w_base"]
            resv = float(resonance_n) * cfg["w_resonance"]
            nest = (0.0 if nesting["state"] in ("none",) else (0.5 if nesting["state"]=="inside" else 1.0)) * cfg["w_nesting"]
            braw = float(r.get("score_raw", r.get("score", np.nan)))
            bfac = (0.0 if np.isnan(braw) else (braw - 2.0)) * cfg["w_beichi"]  # 以2.0为基线

            score_final = base + resv + nest + max(0.0, bfac)

            notes = []
            if upper_tf:
                notes.append(f"nest:{nesting['state']}@{upper_tf}")
            if resonance_n > 0:
                notes.append(f"resv:{resonance_n}")
            if not np.isnan(braw):
                notes.append(f"beichi:{braw:.2f}")

            out_rows.append(dict(
                ts=ts, tf=tf, side=side, tag=tag, price=price,
                score_raw=braw, resonance_n=int(resonance_n),
                nested_state=nesting["state"], nested_dist=nesting["dist"],
                upper_tf=(upper_tf or ""),
                upper_zs_index=nesting.get("zs_index"),
                score_final=float(score_final),
                notes=";".join(notes),
            ))

    out = pd.DataFrame(out_rows)
    if out.empty:
        return pd.DataFrame(columns=[
            "ts","tf","side","tag","price","score_raw","resonance_n",
            "nested_state","nested_dist","upper_tf","upper_zs_index","score_final","notes"
        ]).astype({"resonance_n":"int64"})

    if cfg.get("dedup_same_ts", True):
        out = out.sort_values(["ts","side","score_final"], ascending=[True, True, False])\
                 .drop_duplicates(subset=["ts","side"], keep="first")
    return out.sort_values(["ts","tf"]).reset_index(drop=True)

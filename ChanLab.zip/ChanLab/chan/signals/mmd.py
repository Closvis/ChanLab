# -*- coding: utf-8 -*-
# chan/signals/mmd.py
from __future__ import annotations
from typing import Dict, Any, List, Optional, Tuple
import numpy as np
import pandas as pd

DEFAULT_POLICY: Dict[str, Any] = dict(
    thr_1_entry_strong=3.0,
    thr_1_entry_mid=2.5,
    thr_1_min_keep=2.2,

    trend_confirm_bars=5,
    trend_confirm_body_ratio=0.5,


    n2_lookahead=12,
    n2_tolerance_atr_k=0.6,
    atr_lookback=14,


    n3_lookahead=20,
    zs_band_k=0.0,
    min_gap_minutes=15,


    range_confirm_mode="lookahead",
)


def _atr_like(win: pd.DataFrame, lookback: int = 14) -> float:
    if {"high","low","close"}.issubset(win.columns):
        h,l,c_prev = win["high"], win["low"], win["close"].shift(1)
        tr = pd.concat([(h-l).abs(), (h-c_prev).abs(), (l-c_prev).abs()], axis=1).max(axis=1)
        return float(tr.rolling(lookback, min_periods=1).mean().iloc[-1])
    return float(win["close"].diff().abs().rolling(lookback, min_periods=1).mean().iloc[-1])

def _throttle(rows: List[Dict[str, Any]], min_gap_minutes: int) -> List[Dict[str, Any]]:
    if not rows: return rows
    rows = sorted(rows, key=lambda r: r["ts"])
    delta = pd.Timedelta(minutes=min_gap_minutes)
    kept, last_side_ts = [], {}
    for r in rows:
        t, s = r["ts"], r["side"]
        if s not in last_side_ts or t - last_side_ts[s] >= delta:
            kept.append(r); last_side_ts[s] = t
        else:
            if kept and kept[-1]["ts"]==t and kept[-1]["side"]==s and r.get("score",0)>kept[-1].get("score",0):
                kept[-1]=r
    return kept


def _map_beichi_to_1st(events_df: pd.DataFrame,
                       kline: pd.DataFrame,
                       policy: Dict[str, Any]) -> pd.DataFrame:

    df = events_df.copy()
    df["ts"] = pd.to_datetime(df["ts"])
    out: List[Dict[str, Any]] = []

    def _etype_to_side_tag(etype: str) -> Tuple[str,str,str]:
        if "TREND" in etype:
            if etype.endswith(".UP"):
                return "sell","1S","trend"
            else:
                return "buy","1B","trend"
        elif "RANGE" in etype:
            if etype.endswith(".UP"):
                return "sell","1S","range"
            else:
                return "buy","1B","range"
        return "hold","NA","other"

    k = kline.sort_values("timestamp").reset_index(drop=True)
    ts_series = pd.to_datetime(k["timestamp"], utc=True, errors="coerce")

    for _, r in df.iterrows():
        side, tag, src = _etype_to_side_tag(str(r["etype"]))
        if tag not in ("1B","1S"):
            continue
        score = float(r["score"])
        if score < policy["thr_1_min_keep"]:
            continue

        if src == "trend" and score >= policy["thr_1_entry_mid"]:
            out.append(dict(ts=pd.to_datetime(r["ts"]), side=side, tag=tag,
                            price=float(r["price"]), score=score, etype=str(r["etype"]),
                            source="trend_div"))

        if src == "range":
            t0 = pd.to_datetime(r["ts"])
            idx = ts_series.searchsorted(t0)

            mode = policy.get("range_confirm_mode", "lookahead")
            if mode == "lookback":
                i0 = max(0, idx - policy["trend_confirm_bars"])
                win = k.iloc[i0:idx + 1].copy()
                if len(win) >= 1:
                    body = (win["close"] - win["open"]).astype(float)
                    rng = (win["high"] - win["low"]).astype(float).replace(0, np.nan)
                    body_ratio = (body.abs() / rng).fillna(0.0)
                    if side == "buy":
                        ok = ((body > 0) & (body_ratio >= policy["trend_confirm_body_ratio"])).any()
                    else:
                        ok = ((body < 0) & (body_ratio >= policy["trend_confirm_body_ratio"])).any()
                    if ok and score >= policy["thr_1_entry_mid"]:
                        out.append(dict(
                            ts=t0, side=side, tag=tag,
                            price=float(r.get("price", r.get("px", np.nan))),
                            score=score, etype=str(r["etype"]),
                            source="range_div+trend_confirm(lb)"
                        ))
            else:
                j = min(len(k) - 1, idx + policy["trend_confirm_bars"])
                win = k.iloc[idx:j + 1].copy()
                if len(win) >= 1:
                    body = (win["close"] - win["open"]).astype(float)
                    rng = (win["high"] - win["low"]).astype(float).replace(0, np.nan)
                    body_ratio = (body.abs() / rng).fillna(0.0)
                    if side == "buy":
                        mask = ((body > 0) & (body_ratio >= policy["trend_confirm_body_ratio"]))
                    else:
                        mask = ((body < 0) & (body_ratio >= policy["trend_confirm_body_ratio"]))

                    if mask.any() and score >= policy["thr_1_entry_mid"]:
                        ts_confirm = pd.to_datetime(win.loc[mask, "timestamp"].iloc[-1])
                        out.append(dict(
                            ts=ts_confirm, side=side, tag=tag,
                            price=float(r.get("price", r.get("px", np.nan))),
                            score=score, etype=str(r["etype"]),
                            source="range_div+trend_confirm(la)"
                        ))

    out = _throttle(out, policy["min_gap_minutes"])
    return pd.DataFrame(out).sort_values("ts").reset_index(drop=True)

def generate_mmd2_from_mmd1(kline: pd.DataFrame,
                            mmd1_df: pd.DataFrame,
                            policy: Dict[str, Any]) -> pd.DataFrame:
    if mmd1_df is None or mmd1_df.empty:
        return pd.DataFrame(columns=["ts","side","tag","price","ref_ts","ref_price"])

    k = kline.sort_values("timestamp").reset_index(drop=True)
    tss = pd.to_datetime(k["timestamp"])
    out: List[Dict[str, Any]] = []

    for _, s in mmd1_df.iterrows():
        ts1 = pd.to_datetime(s["ts"])
        side = s["side"]
        i = tss.searchsorted(ts1)
        j = min(len(k)-1, i + policy["n2_lookahead"])
        win = k.iloc[i:j+1].copy()
        if len(win) < 3:
            continue

        atrv = _atr_like(win, policy["atr_lookback"])
        tol = policy["n2_tolerance_atr_k"] * max(1e-9, atrv)
        px1 = float(s["price"])

        if side == "buy":
            lowmin = float(win["low"].min()) if "low" in win.columns else float(win["close"].min())
            if lowmin >= (px1 - tol):
                body = (win["close"] - win["open"]).astype(float)
                rng  = (win["high"] - win["low"]).astype(float).replace(0, np.nan)
                ok = ((body > 0) & ((body.abs()/rng)>=0.4)).any()
                if ok:
                    ts2 = pd.to_datetime(win["timestamp"].iloc[-1])
                    out.append(dict(ts=ts2, side="buy", tag="2B",
                                    price=float(win["close"].iloc[-1]),
                                    ref_ts=ts1, ref_price=px1))
        else:
            highmax = float(win["high"].max()) if "high" in win.columns else float(win["close"].max())
            if highmax <= (px1 + tol):
                body = (win["close"] - win["open"]).astype(float)
                rng  = (win["high"] - win["low"]).astype(float).replace(0, np.nan)
                ok = ((body < 0) & ((body.abs()/rng)>=0.4)).any()
                if ok:
                    ts2 = pd.to_datetime(win["timestamp"].iloc[-1])
                    out.append(dict(ts=ts2, side="sell", tag="2S",
                                    price=float(win["close"].iloc[-1]),
                                    ref_ts=ts1, ref_price=px1))

    out = _throttle(out, policy["min_gap_minutes"])
    return pd.DataFrame(out).sort_values("ts").reset_index(drop=True)

def generate_mmd3_from_zs(kline: pd.DataFrame,
                          segments: pd.DataFrame,
                          zs_l1: pd.DataFrame,
                          policy: Dict[str, Any]) -> pd.DataFrame:
    if zs_l1 is None or zs_l1.empty:
        return pd.DataFrame(columns=["ts","side","tag","price","zs_index"])

    k = kline.sort_values("timestamp").reset_index(drop=True).copy()
    k["timestamp"] = pd.to_datetime(k["timestamp"], utc=True, errors="coerce")
    ts = pd.to_datetime(k["timestamp"], utc=True, errors="coerce")

    out = []

    for _, z in zs_l1.sort_values("timestamp_start").iterrows():
        t0 = pd.to_datetime(z["timestamp_start"], utc=True, errors="coerce")
        t1 = pd.to_datetime(z["timestamp_end"], utc=True, errors="coerce")
        low, high = float(z["zs_low"]), float(z["zs_high"])
        mid = 0.5 * (low + high);
        band = policy["zs_band_k"] * mid

        win = k[(ts >= t0) & (ts <= t1)].copy()
        if win.empty:
            continue

        after = k[ts > t1].copy()
        if after.empty:
            continue

        idx_up = after.index[(after["close"] > (high + band))].tolist()
        if idx_up:
            i = idx_up[0]
            j = min(len(k)-1, i + policy["n3_lookahead"])
            pull = k.iloc[i:j+1].copy()
            if (pull["close"] > (low - band)).all():
                ts3 = pd.to_datetime(pull["timestamp"].iloc[-1])
                out.append(dict(ts=ts3, side="buy", tag="3B",
                                price=float(pull["close"].iloc[-1]),
                                zs_index=int(z.get("zs_index", _))))

        idx_dn = after.index[(after["close"] < (low - band))].tolist()
        if idx_dn:
            i = idx_dn[0]
            j = min(len(k)-1, i + policy["n3_lookahead"])
            pull = k.iloc[i:j+1].copy()
            if (pull["close"] < (high + band)).all():
                ts3 = pd.to_datetime(pull["timestamp"].iloc[-1])
                out.append(dict(ts=ts3, side="sell", tag="3S",
                                price=float(pull["close"].iloc[-1]),
                                zs_index=int(z.get("zs_index", _))))

    out = _throttle(out, policy["min_gap_minutes"])
    return pd.DataFrame(out).sort_values("ts").reset_index(drop=True)

def merge_mmd_signals(*dfs: pd.DataFrame) -> pd.DataFrame:
    std_cols = ["ts","side","tag","price","score","etype","source","ref_ts","ref_price","zs_index"]
    core_cols = ["side","tag","price"]
    pool = []

    for d in dfs:
        if d is None or d.empty or "ts" not in d.columns:
            continue

        x = d.copy()
        x["ts"] = pd.to_datetime(x["ts"], utc=True, errors="coerce")
        for c in std_cols:
            if c not in x.columns:
                x[c] = pd.NA
        x = x[std_cols]

        x = x.dropna(subset=["ts"])
        if x.empty:
            continue
        if x[core_cols].isna().all(axis=1).all():
            continue

        pool.append(x)

    if not pool:
        return pd.DataFrame(columns=std_cols)

    rows = []
    for x in pool:
        rows.extend(x.to_dict("records"))
    out = pd.DataFrame.from_records(rows, columns=std_cols)

    return out.sort_values("ts").reset_index(drop=True)



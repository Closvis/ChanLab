# -*- coding: utf-8 -*-

"""

Trend_signal.py — trend signal generation module

---------------------------------

Input:

- segments_df: Entanglement line segment file (fast)

- trend_df: trend identification results (label_trend_practical output)

Output:

- trend_signal_df: Trend status and signals at each moment

Function:

- The beginning, continuation, reversal and end of the detection trend;

- Output structured signals, which can be used by backtesting and strategy layers.

"""

from __future__ import annotations
from typing import Optional, List, Dict, Any, Union
from pathlib import Path
import pandas as pd
import numpy as np


def generate_trend_signals(
    trend_df: pd.DataFrame,
    segments_df: Optional[pd.DataFrame] = None,
    *,
    use_midpoint: bool = True,
    min_duration_days: int = 1
) -> pd.DataFrame:
    """
    根据走势标注结果（trend_practical）生成走势信号。
    每一条趋势（type="trend"） -> 生成 start/continue/reverse/end 信号。

    参数
    ----
    trend_df : pd.DataFrame
        由 label_trend_practical 生成的走势表。
    segments_df : pd.DataFrame, optional
        对齐时间轴用的线段表（可选）。若提供，将信号对齐到最近一根线段的结束时间。
    use_midpoint : bool
        是否使用每个走势段的中点作为信号时间（否则用起点）。
    min_duration_days : int
        过滤过短的趋势段（例如仅 1 根 segment 的假趋势）。

    返回
    ----
    pd.DataFrame
        列: ts, type, direction, signal, src_index
    """
    if trend_df is None or trend_df.empty:
        return pd.DataFrame(columns=["ts", "type", "direction", "signal", "src_index"])

    td = trend_df.copy().reset_index(drop=True)
    td = td[td["type"] == "trend"].copy()
    if td.empty:
        return pd.DataFrame(columns=["ts", "type", "direction", "signal", "src_index"])

    td["timestamp_start"] = pd.to_datetime(td["timestamp_start"])
    td["timestamp_end"] = pd.to_datetime(td["timestamp_end"])
    td["duration_days"] = (td["timestamp_end"] - td["timestamp_start"]).dt.days

    # 过滤过短趋势
    td = td[td["duration_days"] >= int(min_duration_days)].reset_index(drop=True)
    if td.empty:
        return pd.DataFrame(columns=["ts", "type", "direction", "signal", "src_index"])

    rows: List[Dict[str, Any]] = []
    prev_dir = 0

    for i, r in td.iterrows():
        dir_now = int(r["dir"])
        ts_start = r["timestamp_start"]
        ts_end = r["timestamp_end"]
        ts_signal = ts_start + (ts_end - ts_start) / 2 if use_midpoint else ts_start

        if prev_dir == 0:
            sig = "start_up" if dir_now > 0 else "start_down"
        elif dir_now == prev_dir:
            sig = "continue_up" if dir_now > 0 else "continue_down"
        else:
            sig = "reverse_up" if dir_now > 0 else "reverse_down"

        rows.append(dict(
            ts=ts_signal,
            type="trend",
            direction=dir_now,
            signal=sig,
            src_index=int(i),
        ))
        prev_dir = dir_now

    df = pd.DataFrame(rows)

    # 结束信号（最后趋势结束）
    if not df.empty:
        end_ts = pd.to_datetime(td.iloc[-1]["timestamp_end"])
        df = pd.concat([
            df,
            pd.DataFrame([dict(
                ts=end_ts,
                type="trend",
                direction=0,
                signal="end_trend",
                src_index=int(td.index[-1])
            )])
        ], ignore_index=True)

    # 对齐到线段结束时间，避免未来函数（可选）
    if segments_df is not None and not segments_df.empty:
        seg_t = pd.to_datetime(segments_df["timestamp_end"])
        df = _align_to_segments(df, seg_t)

    return df.sort_values("ts").reset_index(drop=True)


def _align_to_segments(signals: pd.DataFrame, seg_t: pd.Series) -> pd.DataFrame:
    """
    把信号 ts 对齐到<=ts 的最近一根线段结束时间；若不存在，则对齐到最早的线段结束时间。
    """
    if signals is None or signals.empty:
        return signals
    out_rows: List[Dict[str, Any]] = []
    seg_t = pd.to_datetime(seg_t).sort_values().reset_index(drop=True)
    for _, s in signals.iterrows():
        ts = pd.to_datetime(s["ts"])
        idx = seg_t.searchsorted(ts, side="right") - 1
        if idx < 0:
            near = seg_t.iloc[0]
        else:
            near = seg_t.iloc[int(idx)]
        s = s.copy()
        s["ts"] = near
        out_rows.append(s.to_dict())
    return pd.DataFrame(out_rows)


def batch_generate_trend_signals(
    base_path: Union[str, Path],
    symbols: List[str],
    tfs: List[str],
    *,
    trend_subdir: str = "trend_practical",
    seg_subdir: str = "segments/fast",
    out_subdir: str = "trend_signals"
) -> None:
    """
    从落盘文件批量生成走势信号。
    读取:
        chan_data/<trend_subdir>/<sym>/<tf>_trend.csv
        chan_data/<seg_subdir>/<sym>/<tf>_segments.csv
    写出:
        chan_data/<out_subdir>/<sym>/<tf>_trend_signal.csv
    """
    base = Path(base_path).resolve()
    outdir = base / out_subdir
    outdir.mkdir(parents=True, exist_ok=True)

    for sym in symbols:
        for tf in tfs:
            p_tr = base / trend_subdir / sym / f"{tf}_trend.csv"
            p_seg = base / seg_subdir / sym / f"{tf}_segments.csv"
            if not p_tr.exists() or not p_seg.exists():
                print(f"[skip] {sym}-{tf}: missing trend/segment file")
                continue
            trend_df = pd.read_csv(p_tr, parse_dates=["timestamp_start", "timestamp_end"])
            seg_df = pd.read_csv(p_seg, parse_dates=["timestamp_start", "timestamp_end"])
            sig_df = generate_trend_signals(trend_df, seg_df)
            outp = outdir / sym
            outp.mkdir(parents=True, exist_ok=True)
            sig_df.to_csv(outp / f"{tf}_trend_signal.csv", index=False)
            print(f"[saved] {sym}-{tf}: n={len(sig_df)}")

    print("[done] all trend_signals saved.")


if __name__ == "__main__":
    # 示例：本地调试（按需修改根路径）
    ROOT = Path(__file__).resolve().parents[2]
    CHAN = ROOT / "chan_data"
    p_trend = CHAN / "trend_practical" / "BTCUSDT" / "15m_trend.csv"
    p_seg = CHAN / "segments" / "fast" / "BTCUSDT" / "15m_segments.csv"

    if p_trend.exists() and p_seg.exists():
        tr = pd.read_csv(p_trend, parse_dates=["timestamp_start", "timestamp_end"])
        sg = pd.read_csv(p_seg, parse_dates=["timestamp_start", "timestamp_end"])
        df = generate_trend_signals(tr, sg)
        print(df.head())
    else:
        print("[info] sample files not found, skip demo.")

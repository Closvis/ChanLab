# chan/signals/__init__.py
from .beichi import (
    detect_beichi_over_ranges,
    detect_beichi_over_segments,
)

from .mmd import (
    DEFAULT_POLICY,
    _map_beichi_to_1st, generate_mmd2_from_mmd1, generate_mmd3_from_zs,
    merge_mmd_signals,
)
from .merge import (
    DEFAULT_MERGE_CONFIG,
    generate_trading_signals,
)
__all__ = [
    "DEFAULT_POLICY",
    "_map_beichi_to_1st", "generate_mmd2_from_mmd1", "generate_mmd3_from_zs", "merge_mmd_signals",
    "DEFAULT_MERGE_CONFIG", "generate_trading_signals", "detect_beichi_over_ranges", "detect_beichi_over_segments"
]

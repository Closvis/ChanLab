# -*- coding: utf-8 -*-
# chan/signals/beichi.py
from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any, Tuple, Literal, Optional, List
import math
import numpy as np
import pandas as pd

Mode = Literal["up", "down"]


def _to_utc(ts: pd.Timestamp) -> pd.Timestamp:
    t = pd.to_datetime(ts, errors="coerce")
    if getattr(t, "tzinfo", None) is None:
        return t.tz_localize("UTC")
    return t.tz_convert("UTC")


def _ema(s: pd.Series, span: int) -> pd.Series:
    return pd.to_numeric(s, errors="coerce").ewm(span=span, adjust=False).mean()

def macd(df: pd.DataFrame,
         close_col: str = "close",
         fast: int = 12, slow: int = 26, signal: int = 9) -> pd.DataFrame:
    close = pd.to_numeric(df[close_col], errors="coerce")
    ema_fast = _ema(close, fast)
    ema_slow = _ema(close, slow)
    dif = ema_fast - ema_slow
    dea = _ema(dif, signal)
    hist = dif - dea
    out = pd.DataFrame(index=df.index)
    out["macd_dif"] = dif
    out["macd_dea"] = dea
    out["macd_hist"] = hist
    return out

def atr(df: pd.DataFrame, period: int = 14) -> pd.Series:

    h = pd.to_numeric(df["high"], errors="coerce")
    l = pd.to_numeric(df["low"], errors="coerce")
    c = pd.to_numeric(df["close"], errors="coerce").shift(1)
    tr = pd.concat([(h - l).abs(), (h - c).abs(), (l - c).abs()], axis=1).max(axis=1)
    return tr.rolling(period, min_periods=1).mean()

@dataclass
class SwingFeats:
    high: float
    low: float
    mean_vol: float
    length: int
    atr: float
    speed: float
    roc: float          # rate of change
    strength: float

def _feats_of_window(df: pd.DataFrame,
                     price_col: str = "close",
                     vol_col: str = "volume") -> SwingFeats:
    px = pd.to_numeric(df[price_col], errors="coerce")
    hh, ll = float(px.max()), float(px.min())
    length = int(len(df))
    mean_vol = float(df[vol_col].mean()) if vol_col in df.columns else float("nan")
    atr_val = float(atr(df).mean()) if {"high","low","close"}.issubset(df.columns) else float(px.diff().abs().mean())
    speed = float(px.diff().abs().mean())
    roc = float((px.iloc[-1] - px.iloc[0]) / max(1e-12, abs(px.iloc[0])))
    cum_amp = float(px.diff().abs().sum())
    strength = float(abs(px.iloc[-1] - px.iloc[0]) / max(1e-12, cum_amp))
    return SwingFeats(hh, ll, mean_vol, length, atr_val, speed, roc, strength)

def compare_swings(s1_df: pd.DataFrame, s2_df: pd.DataFrame,
                   price_col="close", vol_col="volume") -> Dict[str, Any]:

    f1 = _feats_of_window(s1_df, price_col, vol_col).__dict__
    f2 = _feats_of_window(s2_df, price_col, vol_col).__dict__
    ratios = dict(
        volume_ratio=(f2["mean_vol"] / f1["mean_vol"]) if (f1["mean_vol"] and not math.isnan(f1["mean_vol"])) else np.nan,
        atr_ratio=f2["atr"] / max(1e-12, f1["atr"]),
        speed_ratio=f2["speed"] / max(1e-12, f1["speed"]),
        strength_ratio=f2["strength"] / max(1e-12, f1["strength"]),
    )
    return {"s1": f1, "s2": f2, "ratios": ratios}


def beichi_volume_price(s1: Dict[str, float], s2: Dict[str, float], mode: Mode,
                        vol_weight: float = 1.0, mom_weight: float = 1.0) -> Tuple[bool, Dict[str, Any]]:

    if mode == "up":
        price_new = s2["high"] > s1["high"]
    else:
        price_new = s2["low"] < s1["low"]

    vol_weaker = (not math.isnan(s1["mean_vol"]) and not math.isnan(s2["mean_vol"]) and (s2["mean_vol"] <= s1["mean_vol"]))
    mom_weaker = (s2["atr"] <= s1["atr"]) or (s2["speed"] <= s1["speed"]) or (s2["strength"] <= s1["strength"])
    ok = bool(price_new and (vol_weight * vol_weaker + mom_weight * mom_weaker > 0))
    ev = dict(type="volume_price", price_new=bool(price_new), vol_weaker=bool(vol_weaker),
              mom_weaker=bool(mom_weaker))
    return ok, ev

def beichi_momentum(s1: Dict[str, float], s2: Dict[str, float], mode: Mode) -> Tuple[bool, Dict[str, Any]]:

    weaken_flags = [
        s2["atr"] < s1["atr"],
        s2["speed"] < s1["speed"],
        abs(s2["roc"]) < abs(s1["roc"]),
        s2["strength"] < s1["strength"],
    ]
    price_new = (s2["high"] > s1["high"]) if mode == "up" else (s2["low"] < s1["low"])
    ok = bool(sum(map(bool, weaken_flags)) >= 2 and price_new)
    return ok, dict(type="momentum", weaken_cnt=int(sum(weaken_flags)), price_new=bool(price_new))

def beichi_macd_between(macd_df: pd.DataFrame,
                        win1: Tuple[pd.Timestamp, pd.Timestamp],
                        win2: Tuple[pd.Timestamp, pd.Timestamp],
                        mode: Mode,
                        col: str = "macd_hist") -> Tuple[bool, Dict[str, Any]]:

    a0, a1 = _to_utc(win1[0]), _to_utc(win1[1])
    b0, b1 = _to_utc(win2[0]), _to_utc(win2[1])
    m1 = macd_df[(macd_df.index >= a0) & (macd_df.index <= a1)][col]
    m2 = macd_df[(macd_df.index >= b0) & (macd_df.index <= b1)][col]
    if len(m1) == 0 or len(m2) == 0:
        return False, dict(type="macd", reason="empty_window")
    peak1 = float(m1.max() if mode == "up" else m1.min())
    peak2 = float(m2.max() if mode == "up" else m2.min())
    weaker = (peak2 < peak1) if mode == "up" else (peak2 > peak1)
    return bool(weaker), dict(type="macd", peak1=peak1, peak2=peak2, mode=mode)


def detect_beichi_for_leg(leg1_df: pd.DataFrame, leg2_df: pd.DataFrame, mode: Mode,
                          enable_macd: bool = False,
                          kline_for_macd: Optional[pd.DataFrame] = None) -> Dict[str, Any]:

    feats = compare_swings(leg1_df, leg2_df)
    s1, s2, ratios = feats["s1"], feats["s2"], feats["ratios"]

    ok_vp, ev_vp = beichi_volume_price(s1, s2, mode)
    ok_mo, ev_mo = beichi_momentum(s1, s2, mode)

    evidences: Dict[str, Any] = {
        "volume_price": ev_vp, "momentum": ev_mo, "ratios": ratios
    }
    ok = ok_vp or ok_mo
    score = (1.0 if ok_vp else 0.0) + (0.8 if ok_mo else 0.0)

    if enable_macd and kline_for_macd is not None:
        m = macd(kline_for_macd)
        m.index = pd.to_datetime(kline_for_macd["timestamp"], utc=True, errors="coerce")
        win1 = (_to_utc(leg1_df["timestamp"].iloc[0]), _to_utc(leg1_df["timestamp"].iloc[-1]))
        win2 = (_to_utc(leg2_df["timestamp"].iloc[0]), _to_utc(leg2_df["timestamp"].iloc[-1]))
        ok_md, ev_md = beichi_macd_between(m, win1, win2, mode)
        evidences["macd"] = ev_md
        if ok_md:
            score += 0.6
            ok = True

    return dict(is_beichi=bool(ok), score=float(score), evidences=evidences)


def beichi_strength_score(evidences: Dict[str, Any],
                          context: Optional[Dict[str, Any]] = None,
                          weights: Optional[Dict[str, float]] = None) -> float:

    w = dict(vp=1.0, mo=0.8, md=0.6, prox=0.6, rej=0.6, span=0.4)
    if weights: w.update(weights)

    s = 0.0
    vp = evidences.get("volume_price", {})
    mo = evidences.get("momentum", {})
    md = evidences.get("macd", {})

    if vp and vp.get("price_new") and (vp.get("vol_weaker") or vp.get("mom_weaker")):
        s += w["vp"]
    if mo and mo.get("price_new") and mo.get("weaken_cnt", 0) >= 2:
        s += w["mo"]
    if md and ("peak1" in md) and ("peak2" in md):
        s += w["md"]

    if context:
        prox = float(context.get("boundary_proximity", np.nan))
        rej  = float(context.get("rejection_speed", np.nan))
        span = float(context.get("window_span_norm", np.nan))
        if not np.isnan(prox): s += w["prox"] * max(0.0, min(1.0, prox))
        if not np.isnan(rej):  s += w["rej"]  * max(0.0, min(1.0, rej))
        if not np.isnan(span): s += w["span"] * max(0.0, min(1.0, span))

    return float(s)


def _slice_by_time(df: pd.DataFrame, t0: pd.Timestamp, t1: pd.Timestamp) -> pd.DataFrame:
    ts = pd.to_datetime(df["timestamp"], utc=True, errors="coerce")
    t0u, t1u = _to_utc(t0), _to_utc(t1)
    m = (ts >= t0u) & (ts <= t1u)
    return df.loc[m].reset_index(drop=True)

def detect_beichi_over_segments(kline: pd.DataFrame,
                                segments: pd.DataFrame,
                                direction_col: str = "direction",
                                ts_cols: Tuple[str, str] = ("timestamp_start", "timestamp_end"),
                                enable_macd: bool = False) -> List[Dict[str, Any]]:

    seg = segments.sort_values(ts_cols[0]).reset_index(drop=True)
    events: List[Dict[str, Any]] = []
    for i in range(len(seg) - 2):
        a, b, c = seg.iloc[i], seg.iloc[i + 1], seg.iloc[i + 2]
        same_up = (a[direction_col] == "up") and (c[direction_col] == "up")
        same_dn = (a[direction_col] == "down") and (c[direction_col] == "down")
        if not (same_up or same_dn):
            continue
        mode: Mode = "up" if same_up else "down"

        a_df = _slice_by_time(kline, a[ts_cols[0]], a[ts_cols[1]])
        c_df = _slice_by_time(kline, c[ts_cols[0]], c[ts_cols[1]])
        if len(a_df) == 0 or len(c_df) == 0:
            continue

        bc = detect_beichi_for_leg(a_df, c_df, mode=mode,
                                   enable_macd=enable_macd,
                                   kline_for_macd=(kline if enable_macd else None))
        if not bc["is_beichi"]:
            continue

        ts_event = _to_utc(c[ts_cols[1]])
        ts_all = pd.to_datetime(kline["timestamp"], utc=True, errors="coerce")
        px_series = kline.loc[ts_all <= ts_event, "close"]
        px = float(px_series.iloc[-1]) if len(px_series) > 0 else float("nan")

        try:
            _atr = atr(c_df).iloc[-1]
            rej_speed = abs(c_df["close"].iloc[-1] - c_df["close"].iloc[-3]) / max(1e-9, _atr)
        except Exception:
            rej_speed = np.nan

        context = dict(boundary_proximity=np.nan,
                       rejection_speed=rej_speed,
                       window_span_norm=min(1.0, len(a_df)/100.0 + len(c_df)/100.0))
        score = beichi_strength_score(bc["evidences"], context)

        events.append(dict(
            ts=ts_event,
            price=px,
            etype=f"SIG.BEICHI.TREND.{('UP' if mode=='up' else 'DOWN')}",
            payload=dict(seg_idx=(int(a.name), int(b.name), int(c.name)),
                         score=score, evidences=bc["evidences"], context=context)
        ))
    return events


def _touch_windows_near_boundary(kline: pd.DataFrame,
                                 t0: pd.Timestamp, t1: pd.Timestamp,
                                 side: Literal["upper","lower"],
                                 level_low: float, level_high: float,
                                 band_ratio: float = 0.002,
                                 min_bars: int = 6) -> List[pd.DataFrame]:

    ts_all = pd.to_datetime(kline["timestamp"], utc=True, errors="coerce")
    t0u, t1u = _to_utc(t0), _to_utc(t1)
    sub = kline[(ts_all >= t0u) & (ts_all <= t1u)].reset_index(drop=True)
    if sub.empty:
        return []

    px = pd.to_numeric(sub["close"], errors="coerce")
    mid = 0.5 * (level_low + level_high)
    band = band_ratio * mid

    mask = (px >= (level_high - band)) if side == "upper" else (px <= (level_low + band))

    wins, cur = [], []
    for idx, m in enumerate(mask):
        if m:
            cur.append(idx)
        else:
            if len(cur) >= min_bars:
                wins.append(sub.iloc[cur[0]:cur[-1]+1].reset_index(drop=True))
            cur = []
    if len(cur) >= min_bars:
        wins.append(sub.iloc[cur[0]:cur[-1]+1].reset_index(drop=True))
    return wins

def detect_beichi_over_ranges(kline: pd.DataFrame,
                              zs_l1: pd.DataFrame,
                              enable_macd: bool = False,
                              band_ratio: float = 0.002) -> List[Dict[str, Any]]:

    zs = zs_l1.sort_values("timestamp_start").reset_index(drop=True)
    evts: List[Dict[str, Any]] = []
    for _, z in zs.iterrows():
        t0, t1 = _to_utc(z["timestamp_start"]), _to_utc(z["timestamp_end"])
        low, high = float(z["zs_low"]), float(z["zs_high"])

        for side in ("upper", "lower"):
            wins = _touch_windows_near_boundary(kline, t0, t1, side, low, high, band_ratio=band_ratio)
            if len(wins) < 2:
                continue
            w1, w2 = wins[-2], wins[-1]
            mode = "up" if side == "upper" else "down"
            bc = detect_beichi_for_leg(w1, w2, mode=mode, enable_macd=enable_macd,
                                       kline_for_macd=(kline if enable_macd else None))
            if not bc["is_beichi"]:
                continue

            last_px = float(w2["close"].iloc[-1])
            mid = 0.5 * (low + high); band = band_ratio * mid
            if side == "upper":
                prox = max(0.0, 1.0 - max(0.0, (high - last_px)) / max(1e-9, band))
            else:
                prox = max(0.0, 1.0 - max(0.0, (last_px - low)) / max(1e-9, band))

            try:
                _atr = atr(w2).iloc[-1]
                rej_speed = abs(w2["close"].iloc[-1] - w2["close"].iloc[-3]) / max(1e-9, _atr)
            except Exception:
                rej_speed = np.nan

            span_norm = min(1.0, (len(w1) + len(w2)) / 200.0)

            context = dict(boundary_proximity=prox, rejection_speed=rej_speed, window_span_norm=span_norm)
            score = beichi_strength_score(bc["evidences"], context)

            ts_event = _to_utc(w2["timestamp"].iloc[-1])
            etype = "SIG.BEICHI.RANGE.UP" if side == "upper" else "SIG.BEICHI.RANGE.DOWN"
            evts.append(dict(
                ts=ts_event,
                price=float(w2["close"].iloc[-1]),
                etype=etype,
                payload=dict(zs_index=int(z.get("zs_index", _)), score=score,
                             evidences=bc["evidences"], context=context)
            ))
    return evts


def summarize_events(events: List[Dict[str, Any]]) -> pd.DataFrame:
    if not events:
        return pd.DataFrame(columns=["ts","etype","price","score"])
    rows = []
    for e in events:
        rows.append(dict(ts=e["ts"], etype=e["etype"], price=e["price"],
                         score=e.get("payload", {}).get("score", np.nan)))
    return pd.DataFrame(rows).sort_values("ts").reset_index(drop=True)

def merge_beichi_events(*lists: List[Dict[str, Any]]) -> pd.DataFrame:
    all_rows = []
    for L in lists:
        for e in L:
            all_rows.append(dict(ts=e["ts"], etype=e["etype"], price=e["price"],
                                 score=e.get("payload",{}).get("score", np.nan)))
    if not all_rows:
        return pd.DataFrame(columns=["ts","etype","price","score"])
    return pd.DataFrame(all_rows).sort_values("ts").reset_index(drop=True)

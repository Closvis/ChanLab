# -*- coding: utf-8 -*-
"""
chan_kline.py — Entanglement K line contains relationship processing

Core characteristics
- Strictly argue the direction: rise → take high; fall → take low; neutral → break through the bottom (the closing price is preferred)
- Accurate state machine: update the direction only when "no inclusion"; follow the nearest effective direction when there is inclusion
- Complete tracking: orig_start / orig_end interval mapping
- Engineering quality: linear O(n), tolerance EPS, complete type annotation, pure function without side effects
- Verification: Volume conservation and price envelope integrity check

Input requirements:
DataFrame must contain columns: ['timestamp','open','high','low','close','volume']
"""

from __future__ import annotations
from typing import Literal, Optional, Dict, Any
import pandas as pd

# Definition of constants

REQ_COLS = ['timestamp', 'open', 'high', 'low', 'close', 'volume']
EPS: float = 1e-6
Direction = Optional[Literal['up', 'down']]  # None 表示未定/中性


# Processor class

class ChanKLineProcessor:
    """Entanglement of the K line contains the relational processor"""

    def __init__(self, eps: float = EPS):
        self.eps = eps

    def _assert_schema(self, df: pd.DataFrame) -> None:
        """Verify the integrity of the data pattern"""
        missing = [c for c in REQ_COLS if c not in df.columns]
        if missing:
            raise ValueError(f"Missing necessary columns: {missing}")
        if len(df) == 0:
            return
        if df[['open', 'high', 'low', 'close']].isna().any().any():
            raise ValueError("OHLC The data contains empty values.")
        if (df['low'] > df['high'] + self.eps).any():
            raise ValueError("Find the abnormal line of low > high")

    def _contains(self, a_high: float, a_low: float, b_high: float, b_low: float) -> bool:
        """Judge whether A completely contains B (with tolerance）"""
        return (a_high >= b_high - self.eps) and (a_low <= b_low + self.eps)

    def _geom_relation(self, prev: Dict[str, Any], cur: Dict[str, Any]) -> Literal['up', 'down', 'neutral']:
        """Get the geometric position relationship of two independent K lines"""
        """Geometric relationship when there is no inclusion"""
        if cur['high'] > prev['high'] + self.eps and cur['low'] > prev['low'] + self.eps:
            return 'up'
        if cur['high'] < prev['high'] - self.eps and cur['low'] < prev['low'] - self.eps:
            return 'down'
        return 'neutral'

    def _breakout_direction(self, prev: Dict[str, Any], cur: Dict[str, Any]) -> Direction:
        """Breakthrough at the bottom of neutral: closing breakout is given priority, followed by high/low breakout"""
        """
            Breakthrough direction judgment

            Priority: Closing Price Breakthrough > High Breakthrough > Low Breakthrough
        """
        # 1. The closing price breakthrough is the most reliable.
        if cur['close'] > prev['high'] + self.eps:
            return 'up'
        if cur['close'] < prev['low'] - self.eps:
            return 'down'
        # 2. Break through the high and low points
        if cur['high'] > prev['high'] + self.eps:
            return 'up'
        if cur['low'] < prev['low'] - self.eps:
            return 'down'
        return None

    # Merger and direction

    def _merge_bars(
        self,
        prev: Dict[str, Any],
        cur: Dict[str, Any],
        direction: Direction,
        method: Literal["forward", "backward"],
    ) -> Dict[str, Any]:
        """Combine two K lines according to the direction and merger method."""
        if direction == 'up':
            # Upward trend: take high
            merged_high = max(prev['high'], cur['high'])
            merged_low  = max(prev['low'],  cur['low'])
        elif direction == 'down':
            # Downward trend: take low
            merged_high = min(prev['high'], cur['high'])
            merged_low  = min(prev['low'],  cur['low'])
        else:
            # Undecided direction: conservative, do not widen the range, take high (experience is more stable)
            # Undecided direction: conservative merger (take high to avoid interval expansion)
            merged_high = max(prev['high'], cur['high'])
            merged_low  = max(prev['low'],  cur['low'])

        out = dict(prev)
        if method == "forward":
            # Block tail semantics: open=block head open, close=block tail close, ts=block tail
            # Forward merge: open=block head, close=block tail, timestamp=block tail
            out.update({
                'timestamp': cur['timestamp'],
                'open': prev['open'],
                'high': merged_high,
                'low':  merged_low,
                'close': cur['close'],
                'volume': prev['volume'] + cur['volume'],
                'orig_end': cur['orig_end'],
            })
        else:  # backward
            # Block head semantics: timestamp/close both use block head
            # Merge backwards: open/close/timestamp all use block heads
            out.update({
                'timestamp': prev['timestamp'],
                'open': prev['open'],
                'high': merged_high,
                'low':  merged_low,
                'close': prev['close'],
                'volume': prev['volume'] + cur['volume'],
                'orig_end': cur['orig_end'],
            })
        return out

    # Process
    def process(
        self,
        df_k: pd.DataFrame,
        *,
        method: Literal["forward", "backward"] = "forward",
        enable_validation: bool = True,
        add_trend_marker: bool = False,
    ) -> pd.DataFrame:
        """
        Entanglement K line contains the main function of relational processing
        Parameters
        ----------
        Df_k: pd.DataFrame
        Original K-line data (must include REQ_COLS)
        Method : {"forward","backward"}
        Merge the semantics of time
        Enable_validation: bool
        Whether to perform the result check before returning (an exception will be thrown)
        Add_trend_marker: bool
        Whether to add the 'trend' column (up/down/neutral) for visual debugging
        Returns
        -------
        Pd.DataFrame
        No including trend K line, with orig_start / orig_end
        """
        self._assert_schema(df_k)
        if df_k.empty:
            return pd.DataFrame(columns=REQ_COLS + ['orig_start', 'orig_end'])

        # Reset the index and initialize the tracking interval
        df = df_k.reset_index(drop=False).rename(columns={'index': 'orig_start'}).copy()
        df['orig_end'] = df['orig_start']

        # Core processing logic
        rows: list[Dict[str, Any]] = [df.loc[0].to_dict()]
        last_dir: Direction = None

        for i in range(1, len(df)):
            prev = rows[-1]
            cur = df.loc[i].to_dict()

            prev_contains = self._contains(prev['high'], prev['low'], cur['high'], cur['low'])
            cur_contains  = self._contains(cur['high'], cur['low'], prev['high'], prev['low'])

            if prev_contains or cur_contains:
                if last_dir is None:
                    last_dir = self._breakout_direction(prev, cur)
                merged = self._merge_bars(prev, cur, last_dir, method)
                rows[-1] = merged
            else:
                geom = self._geom_relation(prev, cur)
                if geom == 'up':
                    last_dir = 'up'
                elif geom == 'down':
                    last_dir = 'down'
                rows.append(cur)

        out = pd.DataFrame(rows, columns=REQ_COLS + ['orig_start', 'orig_end'])
        if add_trend_marker:
            out = self._add_trend_markers(out)

        if enable_validation:
            self._validate_result(df_k, out)
        return out

    # Verification and debugging

    def _add_trend_markers(self, df: pd.DataFrame) -> pd.DataFrame:
        if len(df) == 0:
            return df.assign(trend=pd.Series(dtype='object'))
        trends = ['neutral']
        for i in range(1, len(df)):
            prev, cur = df.iloc[i-1], df.iloc[i]
            if cur['high'] > prev['high'] + self.eps and cur['low'] > prev['low'] + self.eps:
                trends.append('up')
            elif cur['high'] < prev['high'] - self.eps and cur['low'] < prev['low'] - self.eps:
                trends.append('down')
            else:
                trends.append('neutral')
        return df.assign(trend=trends)

    def _validate_result(self, original: pd.DataFrame, processed: pd.DataFrame) -> None:
        stats = self.get_validation_stats(original, processed)
        if not stats['price_integrity']:
            raise ValueError("Price envelope integrity verification failed")
        if not stats['volume_preserved']:
            raise ValueError("Volume conservation verification failed")
        if not stats['timestamp_monotonic']:
            raise ValueError("Time stamp monotony verification failed")

    def get_validation_stats(self, original_df: pd.DataFrame, processed_df: pd.DataFrame) -> Dict[str, Any]:
        """Return the verification indicator dictionary r"""
        stats = {
            'original_bars': int(len(original_df)),
            'processed_bars': int(len(processed_df)),
            'reduction_ratio': 1 - (len(processed_df) / max(1, len(original_df))),
            'timestamp_monotonic': bool(processed_df['timestamp'].is_monotonic_increasing) if len(processed_df) else True,
            'price_integrity': True,
            'volume_preserved': True,
        }
        if len(processed_df) == 0 or len(original_df) == 0:
            return stats

        # Volume conservation
        vol_orig = float(original_df['volume'].sum())
        vol_proc = float(processed_df['volume'].sum())
        stats['volume_preserved'] = abs(vol_orig - vol_proc) < 1e-6

        # Price envelope integrity
        for _, row in processed_df.iterrows():
            s = int(row['orig_start']); e = int(row['orig_end'])
            seg = original_df.iloc[s:e+1]
            if seg.empty:
                stats['price_integrity'] = False
                break
            lo_ok = row['low']  >= float(seg['low'].min())  - self.eps
            hi_ok = row['high'] <= float(seg['high'].max()) + self.eps
            order_ok = row['low'] <= row['high'] + self.eps
            if not (lo_ok and hi_ok and order_ok):
                stats['price_integrity'] = False
                break
        return stats


def resolve_inclusion(df_k: pd.DataFrame, **kwargs) -> pd.DataFrame:
    return ChanKLineProcessor().process(df_k, **kwargs)

def validate_processing(original_df: pd.DataFrame, processed_df: pd.DataFrame) -> Dict[str, Any]:
    return ChanKLineProcessor().get_validation_stats(original_df, processed_df)

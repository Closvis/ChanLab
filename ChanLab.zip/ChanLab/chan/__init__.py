# chan/__init__.py

from .chan_kline import (
    ChanKLineProcessor,
    resolve_inclusion,
    validate_processing,
)

from .chan_fractal import (
    detect_fractals,
)

from .chan_bi import (
    detect_bi,
    analyze_bi_characteristics,
    filter_quality_bi,
    find_bi_at_time,
)

from .chan_segment import (
    detect_segments,
    analyze_segments_characteristics,
    filter_quality_segments,
    find_segment_at_time,
)

from .chan_zhongshu import (
    detect_zhongshu,
    analyze_zhongshu,
    find_active_zhongshu,
    detect_zhongshu_by_level,
    validate_chan_zhongshu,
)

from chan.chan_trend import (
    label_trend_practical,
    label_trend_types,
)

from .zhongshu_hierarchy import (
    build_zhongshu_hierarchy,
    summarize_hierarchy,
    score_combo,
    UP_PARAMS_DISCOVERY,
    UP_ENH_DISCOVERY,
    UP_PARAMS_CLEAN,
    UP_ENH_CLEAN,
)

from chan.signals.beichi import (
    macd, atr,
    compare_swings,
    beichi_volume_price, beichi_momentum, beichi_macd_between,
    detect_beichi_for_leg, detect_beichi_over_segments, summarize_events
)

from .signals import (
    DEFAULT_POLICY,
    _map_beichi_to_1st, generate_mmd2_from_mmd1, generate_mmd3_from_zs, merge_mmd_signals,
    DEFAULT_MERGE_CONFIG, generate_trading_signals,
)




__all__ = [
    # kline
    "ChanKLineProcessor", "resolve_inclusion", "validate_processing",
    # fractal
    "detect_fractals",
    # bi
    "detect_bi", "analyze_bi_characteristics", "filter_quality_bi", "find_bi_at_time",
    # segment
    "detect_segments", "analyze_segments_characteristics", "filter_quality_segments", "find_segment_at_time",
    # zhongshu
    "detect_zhongshu", "analyze_zhongshu", "find_active_zhongshu",
    "detect_zhongshu_by_level", "validate_chan_zhongshu",
    # trend
    "label_trend_practical", "label_trend_types",
    # hierarchy
    "build_zhongshu_hierarchy", "summarize_hierarchy", "score_combo", "UP_PARAMS_DISCOVERY", "UP_ENH_DISCOVERY", "UP_PARAMS_CLEAN", "UP_ENH_CLEAN",
    # beichi
    "macd", "atr", "compare_swings", "beichi_volume_price", "beichi_momentum", "beichi_macd_between", "detect_beichi_for_leg", "detect_beichi_over_segments",
    # signals
    "DEFAULT_POLICY", "_map_beichi_to_1st", "generate_mmd2_from_mmd1", "generate_mmd3_from_zs", "merge_mmd_signals", "DEFAULT_MERGE_CONFIG", "generate_trading_signals",

]

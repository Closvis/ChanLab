# -*- coding: utf-8 -*-
"""
chan_segment.py
"""

from __future__ import annotations
from typing import Dict, Any, List, Optional
import numpy as np
import pandas as pd

REQ_BI = [
    'bi_index', 'start_idx', 'end_idx',
    'start_type', 'end_type',
    'start_price', 'end_price',
    'low', 'high', 'dir', 'strength',
    'k_bars_span', 'timestamp_start', 'timestamp_end'
]

def detect_segments(
    bi_df: pd.DataFrame,
    *,
    min_bars: int = 2,
    min_rel_move: float = 0.0,
    merge_same_dir: bool = True,
    enable_break_validation: bool = True,
    break_mode: str = "last_block_extreme",   # "segment_extreme" | "last_block_extreme" | "last_block_start"
    enable_quality_markers: bool = True,
) -> pd.DataFrame:

    _validate_bi_input(bi_df)
    bi = bi_df.sort_values('bi_index').reset_index(drop=True)

    # bi -> Direction block
    blocks = _build_direction_blocks(bi) if merge_same_dir else _blocks_from_bi(bi)

    # Block -> Line segment (undestructed in the opposite direction → absorption; opposite destruction → closed segment flip)
    segments = _blocks_to_segments(
        blocks,
        min_bars=min_bars,
        min_rel_move=min_rel_move,
        enable_break_validation=enable_break_validation,
        break_mode=break_mode,
    )

    if not segments:
        return _create_empty_segment_df()

    seg = pd.DataFrame(segments).reset_index(drop=True)
    seg['segment_index'] = np.arange(len(seg), dtype=int)

    if enable_quality_markers:
        seg = _calculate_segment_quality(seg)

    return _format_segment_output(seg)


def analyze_segments_characteristics(segments_df: pd.DataFrame) -> Dict[str, Any]:
    if segments_df.empty:
        return {}
    up = segments_df[segments_df['direction'] == 'up']
    down = segments_df[segments_df['direction'] == 'down']
    return {
        'total_segments': len(segments_df),
        'up_segments': len(up),
        'down_segments': len(down),
        'up_down_ratio': len(up) / max(1, len(down)),
        'avg_bi_count': float(segments_df['bi_count'].mean()),
        'avg_time_hours': float(segments_df['time_span_hours'].mean()),
        'avg_price_range': float(segments_df['price_range'].mean()),
        'avg_overall_strength': float(segments_df.get('overall_strength', 0).mean())
    }


def filter_quality_segments(segments_df: pd.DataFrame, min_quality: str = 'B') -> pd.DataFrame:
    """Filter the line segments by A/B/C level."""
    if segments_df.empty or 'quality_grade' not in segments_df.columns:
        return segments_df
    order = {'A': 3, 'B': 2, 'C': 1}
    thr = order.get(min_quality, 2)
    scores = segments_df['quality_grade'].map(order)
    return segments_df[scores >= thr].reset_index(drop=True)


def find_segment_at_time(segments_df: pd.DataFrame, timestamp: pd.Timestamp) -> Optional[pd.Series]:
    """Find the "active" line segment at a given point in time."""
    if segments_df.empty:
        return None
    ts = pd.to_datetime(timestamp)
    hit = segments_df[
        (pd.to_datetime(segments_df['timestamp_start']) <= ts) &
        (ts <= pd.to_datetime(segments_df['timestamp_end']))
    ]
    return None if hit.empty else hit.iloc[-1]


# Internal: Construct the direction block from the bi

def _blocks_from_bi(bi: pd.DataFrame) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for _, r in bi.iterrows():
        out.append({
            'dir': int(r['dir']),
            'start_bi_index': int(r['bi_index']),
            'end_bi_index': int(r['bi_index']),
            'start_idx': int(r['start_idx']),
            'end_idx': int(r['end_idx']),
            'start_price': float(r['start_price']),
            'end_price': float(r['end_price']),
            'high': float(r['high']),
            'low': float(r['low']),
            'bi_count': 1,
            'k_span_sum': float(r.get('k_bars_span', 1)),
            'timestamp_start': r['timestamp_start'],
            'timestamp_end': r['timestamp_end'],
        })
    return out


def _build_direction_blocks(bi: pd.DataFrame) -> List[Dict[str, Any]]:
    blocks: List[Dict[str, Any]] = []
    if bi.empty:
        return blocks

    i, n = 0, len(bi)
    while i < n:
        run_dir = int(bi.iloc[i]['dir'])
        j = i + 1
        while j < n and int(bi.iloc[j]['dir']) == run_dir:
            j += 1
        chunk = bi.iloc[i:j]

        block = {
            'dir': run_dir,
            'start_bi_index': int(chunk.iloc[0]['bi_index']),
            'end_bi_index': int(chunk.iloc[-1]['bi_index']),
            'start_idx': int(chunk.iloc[0]['start_idx']),
            'end_idx': int(chunk.iloc[-1]['end_idx']),
            'start_price': float(chunk.iloc[0]['start_price']),
            'end_price': float(chunk.iloc[-1]['end_price']),
            'high': float(chunk['high'].max()),
            'low': float(chunk['low'].min()),
            'bi_count': int(len(chunk)),
            'k_span_sum': float(chunk.get('k_bars_span', pd.Series([1]*len(chunk))).sum()),
            'timestamp_start': chunk.iloc[0]['timestamp_start'],
            'timestamp_end': chunk.iloc[-1]['timestamp_end'],
        }
        blocks.append(block)
        i = j
    return blocks

def _blocks_to_segments(
    blocks: List[Dict[str, Any]],
    *,
    min_bars: int,
    min_rel_move: float,
    enable_break_validation: bool,
    break_mode: str,  # "segment_extreme" | "last_block_extreme" | "last_block_start"
) -> List[Dict[str, Any]]:
    segs: List[Dict[str, Any]] = []
    current: Optional[Dict[str, Any]] = None

    def _init_from_block(b: Dict[str, Any]) -> Dict[str, Any]:
        return {
            'direction': 'up' if b['dir'] == 1 else 'down',
            'start_bi_index': b['start_bi_index'],
            'end_bi_index': b['end_bi_index'],
            'start_idx': b['start_idx'],
            'end_idx': b['end_idx'],
            'start_price': b['start_price'],
            'end_price': b['end_price'],
            'high': b['high'],
            'low': b['low'],
            'bi_count': b.get('bi_count', 1),
            'k_span_sum': b.get('k_span_sum', 0.0),
            'timestamp_start': b['timestamp_start'],
            'timestamp_end': b['timestamp_end'],

            '_last_start': b['start_price'],
            '_last_high': b['high'],
            '_last_low':  b['low'],
        }

    def _extend_same_dir(seg: Dict[str, Any], b: Dict[str, Any]) -> None:
        seg['end_bi_index'] = b['end_bi_index']
        seg['end_idx'] = b['end_idx']
        seg['end_price'] = b['end_price']
        seg['timestamp_end'] = b['timestamp_end']
        seg['bi_count'] += b.get('bi_count', 1)
        seg['k_span_sum'] += b.get('k_span_sum', 0.0)
        seg['high'] = max(seg['high'], b['high'])
        seg['low']  = min(seg['low'],  b['low'])
        seg['_last_start'] = b['start_price']
        seg['_last_high']  = b['high']
        seg['_last_low']   = b['low']

    def _absorb_probe(seg: Dict[str, Any], opp: Dict[str, Any]) -> None:
        seg['end_bi_index'] = opp['end_bi_index']
        seg['end_idx'] = opp['end_idx']
        seg['end_price'] = opp['end_price']
        seg['timestamp_end'] = opp['timestamp_end']
        seg['bi_count'] += opp.get('bi_count', 1)
        seg['k_span_sum'] += opp.get('k_span_sum', 0.0)
        seg['high'] = max(seg['high'], opp['high'])
        seg['low']  = min(seg['low'],  opp['low'])

    def _broken(prev_seg: Dict[str, Any], opp_block: Dict[str, Any]) -> bool:
        mode = break_mode.lower()
        if mode not in ("segment_extreme", "last_block_extreme", "last_block_start"):
            raise ValueError(f"invalid break_mode: {break_mode}")

        if prev_seg['direction'] == 'up':
            if mode == "segment_extreme":
                ref = float(prev_seg['low'])
            elif mode == "last_block_extreme":
                ref = float(prev_seg['_last_low'])
            else:  # "last_block_start"
                ref = float(prev_seg['_last_start'])
            return float(opp_block['low']) < ref
        else:
            if mode == "segment_extreme":
                ref = float(prev_seg['high'])
            elif mode == "last_block_extreme":
                ref = float(prev_seg['_last_high'])
            else:  # "last_block_start"
                ref = float(prev_seg['_last_start'])
            return float(opp_block['high']) > ref

    def _ok(seg: Dict[str, Any]) -> bool:
        if seg['bi_count'] < int(min_bars):
            return False
        if seg['direction'] == 'up':
            rel = (seg['high'] - seg['start_price']) / max(1e-12, seg['start_price'])
        else:
            rel = (seg['start_price'] - seg['low']) / max(1e-12, seg['start_price'])
        return rel >= float(min_rel_move)


    for b in blocks:
        if current is None:
            current = _init_from_block(b)
            continue
        same_dir = ((current['direction'] == 'up' and b['dir'] == 1) or
                    (current['direction'] == 'down' and b['dir'] == -1))
        if same_dir:
            _extend_same_dir(current, b)
            continue
        is_broken = (not enable_break_validation) or _broken(current, b)
        if is_broken:
            if _ok(current):
                _finalize_segment(current)
                segs.append(current)
            current = _init_from_block(b)
        else:
            _absorb_probe(current, b)

    if current is not None and _ok(current):
        _finalize_segment(current)
        segs.append(current)

    return segs


def _finalize_segment(seg: Dict[str, Any]) -> None:
    t0 = pd.to_datetime(seg['timestamp_start'])
    t1 = pd.to_datetime(seg['timestamp_end'])
    seg['time_span_hours'] = float((t1 - t0).total_seconds() / 3600.0)
    seg['price_range'] = float(seg['high'] - seg['low'])

def _calculate_segment_quality(seg: pd.DataFrame) -> pd.DataFrame:
    if seg.empty:
        return seg
    res = seg.copy()
    rel_up = (res['high'] - res['start_price']) / res['start_price'].clip(lower=1e-12)
    rel_dn = (res['start_price'] - res['low']) / res['start_price'].clip(lower=1e-12)
    res['price_strength'] = np.where(res['direction'] == 'up', rel_up, rel_dn)

    mean_t = float(res['time_span_hours'].mean()) if res['time_span_hours'].notna().any() else 0.0
    res['time_strength'] = np.where(mean_t > 0, res['time_span_hours'] / mean_t, 1.0)

    mean_bi = float(res['bi_count'].mean()) if res['bi_count'].notna().any() else 0.0
    res['bi_count_strength'] = np.where(mean_bi > 0, res['bi_count'] / max(mean_bi, 1e-12), 1.0)

    w = {'price_strength': 0.5, 'time_strength': 0.25, 'bi_count_strength': 0.25}
    res['overall_strength'] = (
        w['price_strength'] * res['price_strength'] +
        w['time_strength'] * res['time_strength'] +
        w['bi_count_strength'] * res['bi_count_strength']
    ).astype(float)

    res['quality_grade'] = 'C'
    res.loc[res['overall_strength'] >= 0.6, 'quality_grade'] = 'B'
    res.loc[res['overall_strength'] >= 0.8, 'quality_grade'] = 'A'
    return res

def _validate_bi_input(bi_df: pd.DataFrame) -> None:
    miss = [c for c in REQ_BI if c not in bi_df.columns]
    if miss:
        raise ValueError(f"Necessary column: {miss}")
    if len(bi_df) == 0:
        raise ValueError("The data is empty.")


def _format_segment_output(seg: pd.DataFrame) -> pd.DataFrame:
    cols = [
        'segment_index',
        'direction', 'start_bi_index', 'end_bi_index',
        'start_idx', 'end_idx',
        'start_price', 'end_price',
        'high', 'low', 'price_range',
        'bi_count', 'k_span_sum',
        'timestamp_start', 'timestamp_end', 'time_span_hours',
        'price_strength', 'time_strength', 'bi_count_strength',
        'overall_strength', 'quality_grade'
    ]
    for c in cols:
        if c not in seg.columns:
            seg[c] = np.nan
    return seg[cols]


def _create_empty_segment_df() -> pd.DataFrame:
    cols = [
        'segment_index',
        'direction', 'start_bi_index', 'end_bi_index',
        'start_idx', 'end_idx',
        'start_price', 'end_price',
        'high', 'low', 'price_range',
        'bi_count', 'k_span_sum',
        'timestamp_start', 'timestamp_end', 'time_span_hours',
        'price_strength', 'time_strength', 'bi_count_strength',
        'overall_strength', 'quality_grade'
    ]
    return pd.DataFrame(columns=cols)

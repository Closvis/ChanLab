# -*- coding: utf-8 -*-
# chan/mapping.py
from __future__ import annotations
from typing import Optional
import numpy as np
import pandas as pd


def prepare_candles(candles: pd.DataFrame) -> pd.DataFrame:

    need = {"timestamp", "open", "high", "low", "close", "volume"}
    miss = [c for c in need if c not in candles.columns]
    if miss:
        raise ValueError(f"candles Lack of necessary columns: {miss}")

    c = candles.copy()
    c["timestamp"] = pd.to_datetime(c["timestamp"], utc=True, errors="coerce")
    if c["timestamp"].isna().any():
        raise ValueError("There is a timestamp that cannot be resolved in candles.")

    c = c.sort_values("timestamp").reset_index(drop=True)
    c["bar_index"] = np.arange(len(c), dtype=np.int64)
    return c


def map_segments_to_candles(
    segments: pd.DataFrame,
    candles: pd.DataFrame,
    ts_start_col: str = "timestamp_start",
    ts_end_col: str = "timestamp_end",
    seg_index_col: str = "segment_index",
) -> pd.DataFrame:
    """
    Map the entanglement line segment to the real disk K line index:
    - start_bar_index = K-line index of the first >= segment_start
    - end_bar_index = K-line index of the last <= segment_end
    - If start > end (the window is too small or the data is missing), it will degenerate into the same root (end = start)
    - Ensure that end_bar_index is aligned no later than segment_end (avoid future functions)
    Need columns:
    Segments: [ts_start_col, ts_end_col] (+ optional seg_index_col)
    Candles: prepare_candles processed (including timestamp, bar_index)
    """
    if segments is None or segments.empty:
        return segments.copy()


    s = segments.copy()
    for col in (ts_start_col, ts_end_col):
        if col not in s.columns:
            raise ValueError(f"segments Missing columns: {col}")
        s[col] = pd.to_datetime(s[col], utc=True, errors="coerce")
    if s[ts_start_col].isna().any() or s[ts_end_col].isna().any():
        raise ValueError("segments There is a start and end time that cannot be parsed.")


    c = candles.copy()
    if "timestamp" not in c.columns or "bar_index" not in c.columns:
        raise ValueError("Candles need to be processed with prepare_candles first, including timestamp and bar_index.")
    c = c.sort_values("timestamp").reset_index(drop=True)
    c["bar_index"] = np.arange(len(c), dtype=np.int64)  # 确保是连续 int

    ts = c["timestamp"].to_numpy(dtype="datetime64[ns]")
    if ts.size == 0:
        raise ValueError("Candles are empty")

    s_starts = s[ts_start_col].to_numpy(dtype="datetime64[ns]")
    s_ends   = s[ts_end_col].to_numpy(dtype="datetime64[ns]")


    start_idx = np.searchsorted(ts, s_starts, side="left")
    end_idx = np.searchsorted(ts, s_ends, side="right") - 1

    start_idx = np.clip(start_idx, 0, len(ts) - 1)
    end_idx   = np.clip(end_idx,   0, len(ts) - 1)

    bad = start_idx > end_idx
    if np.any(bad):
        end_idx[bad] = start_idx[bad]

    out = s.copy()
    out["start_bar_index"] = start_idx.astype(np.int64)
    out["end_bar_index"]   = end_idx.astype(np.int64)

    end_ts = ts[out["end_bar_index"].to_numpy()]
    too_late = end_ts > s_ends
    if np.any(too_late):
        fixed = out.loc[too_late, "end_bar_index"].to_numpy() - 1
        fixed = np.clip(fixed, 0, len(ts) - 1)
        out.loc[too_late, "end_bar_index"] = fixed.astype(np.int64)

    bad2 = out["start_bar_index"] > out["end_bar_index"]
    if bad2.any():
        out.loc[bad2, "end_bar_index"] = out.loc[bad2, "start_bar_index"]

    return out

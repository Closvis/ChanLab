# -*- coding: utf-8 -*-
"""
chan_trend.py
"""

from __future__ import annotations
import json
from pathlib import Path
from typing import Optional, List, Dict, Any
import numpy as np
import pandas as pd

EPS = 1e-12


def label_trend_practical(
    segments_df: pd.DataFrame,
    *,
    gap_hours: float = 48.0,
    price_change_threshold: float = 0.01,
    min_segments: int = 2,
    enable_quality: bool = True,
) -> pd.DataFrame:
    """

    Practical trend identification based on "time continuous grouping + initial and final returns in the group".
    - Group the adjacent line segments according to the time interval <= gap_hours;
    - If the first and last income in the group |ΔP/P0| >= price_change_threshold -> is recorded as the trend segment;
    Otherwise, it will be disassembled into several single-segment range
"""
    if segments_df is None or len(segments_df) == 0:
        return _empty_trend_df()
    seg = segments_df.sort_values("segment_index").reset_index(drop=True).copy()
    _check_cols(seg, [
        "segment_index", "timestamp_start", "timestamp_end",
        "start_price", "end_price", "low", "high"
    ])

    groups: List[pd.DataFrame] = []
    group: List[pd.Series] = [seg.iloc[0]]
    for j in range(1, len(seg)):
        t_end_prev = pd.to_datetime(seg.iloc[j-1]["timestamp_end"])
        t_start_now = pd.to_datetime(seg.iloc[j]["timestamp_start"])
        gap = (t_start_now - t_end_prev).total_seconds() / 3600.0
        if gap <= gap_hours:
            group.append(seg.iloc[j])
        else:
            if len(group) >= min_segments:
                groups.append(pd.DataFrame(group))
            group = [seg.iloc[j]]
    if len(group) >= min_segments:
        groups.append(pd.DataFrame(group))

    rows: List[Dict[str, Any]] = []

    for g in groups:
        start_price = float(g.iloc[0]["start_price"])
        end_price = float(g.iloc[-1]["end_price"])
        low_price = float(g["low"].min())
        high_price = float(g["high"].max())
        rr = (end_price - start_price) / max(EPS, start_price)
        abs_rr = abs(rr)

        if abs_rr >= price_change_threshold:
            direction = 1 if rr > 0 else -1
            rows.append(dict(
                trend_index=len(rows),
                type="trend",
                dir=direction,
                timestamp_start=g.iloc[0]["timestamp_start"],
                timestamp_end=g.iloc[-1]["timestamp_end"],
                start_idx=int(g.iloc[0]["segment_index"]),
                end_idx=int(g.iloc[-1]["segment_index"]),
                start_price=start_price, end_price=end_price,
                low=low_price, high=high_price,
                mid=0.5*(low_price+high_price),
                rr=float(abs_rr),
                segment_count=int(len(g)),
                price_change_pct=float(rr*100.0),
                duration_days=int((pd.to_datetime(g.iloc[-1]["timestamp_end"])
                                  - pd.to_datetime(g.iloc[0]["timestamp_start"])).days),
                source="practical_grouping",
            ))
        else:

            for _, s in g.iterrows():
                rows.append(dict(
                    trend_index=len(rows),
                    type="range",
                    dir=0,
                    timestamp_start=s["timestamp_start"],
                    timestamp_end=s["timestamp_end"],
                    start_idx=int(s["segment_index"]),
                    end_idx=int(s["segment_index"]),
                    start_price=float(s["start_price"]),
                    end_price=float(s["end_price"]),
                    low=float(s["low"]),
                    high=float(s["high"]),
                    mid=0.5*(float(s["low"]) + float(s["high"])),
                    rr=0.0,
                    segment_count=1,
                    price_change_pct=0.0,
                    duration_days=int((pd.to_datetime(s["timestamp_end"])
                                      - pd.to_datetime(s["timestamp_start"])).days),
                    source="practical_single",
                ))

    res = pd.DataFrame(rows) if rows else _empty_trend_df()


    if enable_quality and not res.empty:
        res = _score_practical_trends(res)

    return _format_trend_cols(res)


def _score_practical_trends(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out["overall_strength"] = 0.3  # range 的 baseline
    mask_tr = (out["type"] == "trend")
    if mask_tr.any():
        rr_s = (out.loc[mask_tr, "rr"] / 0.20).clip(0, 1)
        dur_s = (out.loc[mask_tr, "duration_days"] / 30.0).clip(0, 1)
        out.loc[mask_tr, "overall_strength"] = (0.7 * rr_s + 0.3 * dur_s).clip(0, 1)

    out["quality_grade"] = "C"
    out.loc[out["overall_strength"] >= 0.6, "quality_grade"] = "B"
    out.loc[out["overall_strength"] >= 0.8, "quality_grade"] = "A"
    return out


def label_trend_types(
    segments_df: pd.DataFrame,
    zhongshu_df: Optional[pd.DataFrame] = None,
    *,
    min_trend_rr: float = 0.005,
    max_pullback_ratio: float = 0.6,
    use_adjacent_as_range: bool = True,
    fallback_min_segments: int = 3,
    enable_quality: bool = True
) -> pd.DataFrame:

    if segments_df is None or len(segments_df) == 0:
        return _empty_trend_df()

    seg = segments_df.sort_values("segment_index").reset_index(drop=True).copy()
    _check_cols(seg, [
        "segment_index", "timestamp_start", "timestamp_end",
        "start_price", "end_price", "low", "high", "direction"
    ])


    if zhongshu_df is None or len(zhongshu_df) == 0:
        return _fallback_window_trend(seg, fallback_min_segments, min_trend_rr, enable_quality)

    zs = zhongshu_df.sort_values("timestamp_start").reset_index(drop=True)
    _check_cols(zs, ["timestamp_start", "timestamp_end", "zs_low", "zs_high"])

    rows: List[Dict[str, Any]] = []

    for _, z in zs.iterrows():
        win_start = pd.to_datetime(z["timestamp_start"])
        win_end = pd.to_datetime(z["timestamp_end"])
        seg_win = seg[(pd.to_datetime(seg["timestamp_start"]) >= win_start) &
                      (pd.to_datetime(seg["timestamp_end"]) <= win_end)]

        if seg_win.empty:
            rows.append(_make_range_row_from_zs(z, win_start, win_end))
            continue

        low = float(seg_win["low"].min())
        high = float(seg_win["high"].max())
        rows.append(dict(
            trend_index=len(rows),
            type="range", dir=0,
            timestamp_start=seg_win.iloc[0]["timestamp_start"],
            timestamp_end=seg_win.iloc[-1]["timestamp_end"],
            start_idx=int(seg_win.iloc[0]["segment_index"]),
            end_idx=int(seg_win.iloc[-1]["segment_index"]),
            start_price=float(seg_win.iloc[0]["start_price"]),
            end_price=float(seg_win.iloc[-1]["end_price"]),
            low=low, high=high, mid=0.5*(low+high),
            rr=0.0, segment_count=int(len(seg_win)),
            price_change_pct=0.0,
            duration_days=int((pd.to_datetime(seg_win.iloc[-1]["timestamp_end"])
                              - pd.to_datetime(seg_win.iloc[0]["timestamp_start"])).days),
            source="zs_window"
        ))

    gaps = _extract_gaps_between_ranges(rows, seg)
    for g in gaps:
        gseg = g["segments"]
        if gseg.empty:
            continue

        s0 = float(gseg.iloc[0]["start_price"])
        s1 = float(gseg.iloc[-1]["end_price"])
        rr = (s1 - s0) / max(EPS, s0)
        abs_rr = abs(rr)

        path_low = float(gseg["low"].min())
        path_high = float(gseg["high"].max())
        if rr >= 0:
            pullback = (path_high - s1) / max(EPS, path_high - s0) if path_high > s0 else 0.0
        else:
            pullback = (s1 - path_low) / max(EPS, s0 - path_low) if path_low < s0 else 0.0

        if abs_rr >= float(min_trend_rr) and pullback <= float(max_pullback_ratio):
            rows.append(dict(
                trend_index=len(rows),
                type="trend", dir=(1 if rr > 0 else -1),
                timestamp_start=gseg.iloc[0]["timestamp_start"],
                timestamp_end=gseg.iloc[-1]["timestamp_end"],
                start_idx=int(gseg.iloc[0]["segment_index"]),
                end_idx=int(gseg.iloc[-1]["segment_index"]),
                start_price=s0, end_price=s1,
                low=float(gseg["low"].min()), high=float(gseg["high"].max()),
                mid=0.5*(float(gseg["low"].min()) + float(gseg["high"].max())),
                rr=float(abs_rr),
                segment_count=int(len(gseg)),
                price_change_pct=float(rr*100.0),
                duration_days=int((pd.to_datetime(gseg.iloc[-1]["timestamp_end"])
                                  - pd.to_datetime(gseg.iloc[0]["timestamp_start"])).days),
                source="gap_trend"
            ))
        elif use_adjacent_as_range:
            rows.append(dict(
                trend_index=len(rows),
                type="range", dir=0,
                timestamp_start=gseg.iloc[0]["timestamp_start"],
                timestamp_end=gseg.iloc[-1]["timestamp_end"],
                start_idx=int(gseg.iloc[0]["segment_index"]),
                end_idx=int(gseg.iloc[-1]["segment_index"]),
                start_price=s0, end_price=s1,
                low=float(gseg["low"].min()), high=float(gseg["high"].max()),
                mid=0.5*(float(gseg["low"].min()) + float(gseg["high"].max())),
                rr=0.0, segment_count=int(len(gseg)),
                price_change_pct=0.0,
                duration_days=int((pd.to_datetime(gseg.iloc[-1]["timestamp_end"])
                                  - pd.to_datetime(gseg.iloc[0]["timestamp_start"])).days),
                source="gap_range"
            ))

    res = pd.DataFrame(rows) if rows else _empty_trend_df()
    if enable_quality and not res.empty:
        res = _score_structured_trends(res)
    return _format_trend_cols(res)

def _fallback_window_trend(seg: pd.DataFrame, K: int, thr: float, enable_quality: bool) -> pd.DataFrame:
    rows: List[Dict[str, Any]] = []
    n = len(seg)
    if n == 0:
        return _empty_trend_df()

    i = 0
    while i < n:
        j = min(n, i + K)
        chunk = seg.iloc[i:j]
        s0 = float(chunk.iloc[0]["start_price"])
        s1 = float(chunk.iloc[-1]["end_price"])
        rr = (s1 - s0) / max(EPS, s0)
        abs_rr = abs(rr)
        if abs_rr >= thr:
            t = "trend"
            d = 1 if rr > 0 else -1
        else:
            t = "range"
            d = 0

        rows.append(dict(
            trend_index=len(rows),
            type=t, dir=d,
            timestamp_start=chunk.iloc[0]["timestamp_start"],
            timestamp_end=chunk.iloc[-1]["timestamp_end"],
            start_idx=int(chunk.iloc[0]["segment_index"]),
            end_idx=int(chunk.iloc[-1]["segment_index"]),
            start_price=s0, end_price=s1,
            low=float(chunk["low"].min()), high=float(chunk["high"].max()),
            mid=0.5*(float(chunk["low"].min()) + float(chunk["high"].max())),
            rr=(abs_rr if t == "trend" else 0.0),
            segment_count=int(len(chunk)),
            price_change_pct=float(rr*100.0 if t == "trend" else 0.0),
            duration_days=int((pd.to_datetime(chunk.iloc[-1]["timestamp_end"])
                              - pd.to_datetime(chunk.iloc[0]["timestamp_start"])).days),
            source="fallback_window"
        ))
        i = j

    res = pd.DataFrame(rows)
    if enable_quality:
        res = _score_practical_trends(res)
    return res


def _make_range_row_from_zs(z: pd.Series, win_start, win_end) -> Dict[str, Any]:
    low = float(z.get("zs_low", np.nan))
    high = float(z.get("zs_high", np.nan))
    return dict(
        trend_index=-1,
        type="range", dir=0,
        timestamp_start=win_start,
        timestamp_end=win_end,
        start_idx=np.nan, end_idx=np.nan,
        start_price=np.nan, end_price=np.nan,
        low=low, high=high, mid=0.5*(low+high) if np.isfinite(low) and np.isfinite(high) else np.nan,
        rr=0.0, segment_count=0,
        price_change_pct=0.0,
        duration_days=int((pd.to_datetime(win_end) - pd.to_datetime(win_start)).days),
        source="zs_empty_window",
    )


def _extract_gaps_between_ranges(range_rows: List[Dict[str, Any]], seg: pd.DataFrame) -> List[Dict[str, Any]]:

    if not range_rows:
        return []
    r = pd.DataFrame(range_rows).sort_values("timestamp_start").reset_index(drop=True)
    gaps = []
    for k in range(len(r) - 1):
        end_t = pd.to_datetime(r.iloc[k]["timestamp_end"])
        start_t = pd.to_datetime(r.iloc[k + 1]["timestamp_start"])
        if start_t <= end_t:
            continue
        gseg = seg[(pd.to_datetime(seg["timestamp_start"]) >= end_t) &
                   (pd.to_datetime(seg["timestamp_end"]) <= start_t)]
        gaps.append(dict(
            start=end_t, end=start_t, segments=gseg.reset_index(drop=True)
        ))
    return gaps


def _score_structured_trends(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out["overall_strength"] = 0.3
    mask_tr = (out["type"] == "trend")
    if mask_tr.any():
        rr_s = (out.loc[mask_tr, "rr"] / 0.20).clip(0, 1)
        seg_s = (out.loc[mask_tr, "segment_count"] / max(1, out.loc[mask_tr, "segment_count"].max())).clip(0, 1)
        out.loc[mask_tr, "overall_strength"] = (0.75 * rr_s + 0.25 * seg_s).clip(0, 1)

    out["quality_grade"] = "C"
    out.loc[out["overall_strength"] >= 0.6, "quality_grade"] = "B"
    out.loc[out["overall_strength"] >= 0.8, "quality_grade"] = "A"

    out = out.reset_index(drop=True)
    out["trend_index"] = out.index.astype(int)
    return out


def _check_cols(df: pd.DataFrame, need: List[str]) -> None:
    miss = [c for c in need if c not in df.columns]
    if miss:
        raise ValueError(f"Lack of necessary columns: {miss}")


def _empty_trend_df() -> pd.DataFrame:
    cols = [
        "trend_index", "type", "dir",
        "timestamp_start", "timestamp_end",
        "start_idx", "end_idx",
        "start_price", "end_price",
        "low", "high", "mid",
        "rr", "segment_count", "price_change_pct", "duration_days",
        "overall_strength", "quality_grade", "source"
    ]
    return pd.DataFrame(columns=cols)


def _format_trend_cols(df: pd.DataFrame) -> pd.DataFrame:
    cols = [
        "trend_index", "type", "dir",
        "timestamp_start", "timestamp_end",
        "start_idx", "end_idx",
        "start_price", "end_price",
        "low", "high", "mid",
        "rr", "segment_count", "price_change_pct", "duration_days",
        "overall_strength", "quality_grade", "source"
    ]
    out = df.copy()
    for c in cols:
        if c not in out.columns:
            out[c] = np.nan
    out = out.reset_index(drop=True)
    out["trend_index"] = out.index.astype(int)
    return out[cols]
